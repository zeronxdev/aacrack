#!/bin/bash
PATH=/www/server/panel/pyenv/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
install_tmp='/tmp/bt_install.pl'

Install_Ftp()
{	

	mkdir -p /www/server/panel/plugin/ftp
  rm -rf /www/server/panel/plugin/ftp/btftplib
  rm -rf /www/server/panel/plugin/ftp/btftplib.zip

}

Uninstall_Ftp()
{
	rm -rf /www/server/panel/data/ftpAS.conf
	rm -rf /www/server/panel/data/ftpAs.conf
	rm -rf /www/server/panel/data/SSHFileTransferProtocolAS.conf
	rm -rf /www/server/panel/data/ftp_settingsAS.conf
	echo '卸载完成' > $install_tmp
}


action=$1
if [ "${1}" == 'install' ];then
	Install_Ftp
else
	Uninstall_Ftp
fi
