#!/bin/bash
PATH=/www/server/panel/pyenv/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
install_tmp='/tmp/bt_install.pl'
public_file=/www/server/panel/install/public.sh

#download_Url=https://node.aapanel.com

Install_ffmpeg()
{
#    mkdir -p /www/server/panel/plugin/frp

    #	#线上用
#    wget --no-check-certificate -O /tmp/ffmpeg.zip $download_Url/install/plugin/ffmpeg_en/ffmpeg.zip -T 5

    #测试用
#  	cp -arpf frp.zip /tmp/frp.zip

#    unzip -o /tmp/ffmpeg.zip -d /www/server/panel/plugin/
#    rm -f /tmp/ffmpeg.zip

    echo 'Successful installation'
}


Uninstall_frp()
{
    rm -rf /www/server/panel/plugin/ffmpeg
}

action=$1
if [ "${1}" == 'install' ];then
    Install_ffmpeg
else
    Uninstall_ffmpeg
fi
