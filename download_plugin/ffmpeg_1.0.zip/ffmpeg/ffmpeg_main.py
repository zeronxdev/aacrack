#!/usr/bin/python
# coding: utf-8
# +------------------------------------------------------------------
# | ffmpeg
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 https://www.aapanel.com All rights reserved.
# +-------------------------------------------------------------------
import json, os, sys
import re
import traceback

BASE_PATH = "/www/server/panel"
os.chdir(BASE_PATH)
sys.path.insert(0, "class/")
import public
import requests


class ffmpeg_main:
    default = {
        "arm": {
            "ffmpeg-3.4.2": "ffmpeg-3.4.2-arm64-64bit-static.tar.xz",
            "ffmpeg-4.4.1": "ffmpeg-4.4.1-arm64-static.tar.xz",
            "ffmpeg-5.1.1": "ffmpeg-5.1.1-arm64-static.tar.xz",
            "ffmpeg-6.1": "ffmpeg-6.1-arm64-static.tar.xz"
        },
        "amd": {
            "ffmpeg-3.4.2": "ffmpeg-3.4.2-64bit-static.tar.xz",
            "ffmpeg-4.4.1": "ffmpeg-4.4.1-amd64-static.tar.xz",
            "ffmpeg-5.1.1": "ffmpeg-5.1.1-amd64-static.tar.xz",
            "ffmpeg-6.1": "ffmpeg-6.1-amd64-static.tar.xz"
        }
    }

    def get_ffmpeg_version(self, get=None):
        url = 'https://node.aapanel.com/src/ffmpeg/version.json'
        res = requests.get(url, timeout=3)
        try:
            version = res.json()
            if version:
                self.default = version
        except:
            pass
        names = list(self.default['amd'].keys())
        data = []
        default_exec = ''
        if os.path.exists('/usr/bin/ffmpeg'):
            default_exec = os.path.realpath('/usr/bin/ffmpeg')
        for i in names:
            install_status = '0'
            if os.path.exists('/www/server/ffmpeg/{}/ffmpeg'.format(i)):
                install_status = '1'
            exec_path = '/www/server/ffmpeg/{}/ffmpeg'.format(i)
            install_path = '/www/server/ffmpeg/{}'.format(i)
            exec = 'ffmpeg{}'.format(re.search(r'\d', i).group())
            data.append({
                'name': i,
                'install_status': install_status,
                'exec_path': exec_path if install_status == '1' else '',
                'install_path': install_path if install_status == '1' else '',
                'exec': exec if install_status == '1' else '',
                'is_default': '1' if default_exec == exec_path else '0'
            })
        data.reverse()
        return data

    def install_ffmpeg(self, get):
        if not hasattr(get, 'version'):
            return public.returnMsg(False, 'Parameter error')
        version = get.version
        self.get_ffmpeg_version()
        Os = 'amd'
        if public.is_aarch():
            Os = 'arm'
        url = 'https://node.aapanel.com/src/ffmpeg/' + self.default[Os][version]
        try:
            public.ExecShell('wget -O /www/server/panel/plugin/ffmpeg/' + self.default[Os][version] + ' ' + url)
            if not os.path.exists('/www/server/panel/plugin/ffmpeg/' + self.default[Os][version]):
                return public.returnMsg(False, 'download failed')
            if not os.path.exists('/www/server/ffmpeg/') and not os.path.isdir('/www/server/ffmpeg/'):
                os.makedirs('/www/server/ffmpeg/')
            public.ExecShell('tar -xf /www/server/panel/plugin/ffmpeg/{} -C /www/server/ffmpeg/'.format(self.default[Os][version]))
            name = self.default[Os][version].split('.tar.xz')[0]
            if not os.path.exists('/www/server/ffmpeg/{}'.format(name)):
                return public.returnMsg(False, 'Unzip failed')
            public.ExecShell('mv /www/server/ffmpeg/{}  /www/server/ffmpeg/{}'.format(name, version))
            if not os.path.exists('/www/server/ffmpeg/{}/ffmpeg'.format(version)):
                public.ExecShell('mv /www/server/ffmpeg/{}/{}  /www/server/ffmpeg/{}/ffmpeg'.format(version, name, version))
                if not os.path.exists('/www/server/ffmpeg/{}/ffmpeg'.format(version)):
                    return public.returnMsg(False, 'Installation failed, please install again!')
            public.ExecShell('chmod +x /www/server/ffmpeg/{}/ffmpeg'.format(version))
            public.ExecShell('ln -s /www/server/ffmpeg/{}/ffmpeg /usr/bin/ffmpeg{}'.format(version, re.search(r'\d', version).group()))
            public.ExecShell('rm -rf /www/server/panel/plugin/ffmpeg/' + self.default[Os][version])
            return public.returnMsg(True, 'Successful installation')
        except:
            public.ExecShell('rm -rf /www/server/panel/plugin/ffmpeg/' + self.default[Os][version])
            public.ExecShell('rm -rf /www/server/ffmpeg/{}'.format(version))
            public.ExecShell('rm -rf /usr/bin/ffmpeg{}'.format(re.search(r'\d', version).group()))
            return public.returnMsg(False, 'Installation failed')

    def uninstall_ffmpeg(self, get):
        if not hasattr(get, 'version'):
            return public.returnMsg(False, 'Parameter error')
        version = get.version
        if os.path.exists('/www/server/panel/plugin/ffmpeg/{}.pl'.format(version)):
            public.ExecShell('rm -rf /www/server/panel/plugin/ffmpeg/{}.pl'.format(version))
        if os.path.exists('/www/server/ffmpeg/{}'.format(version)):
            public.ExecShell('rm -rf /www/server/ffmpeg/{}'.format(version))
        if os.path.exists('/usr/bin/ffmpeg{}'.format(re.search(r'\d', version).group())):
            public.ExecShell('rm -rf /usr/bin/ffmpeg{}'.format(re.search(r'\d', version).group()))
        return public.returnMsg(True, 'Uninstalled successfully')

    def set_default_exec(self, get):
        if not hasattr(get, 'version'):
            return public.returnMsg(False, 'Parameter error')
        version = get.version
        if not os.path.exists('/www/server/ffmpeg/{}/ffmpeg'.format(version)):
            return public.returnMsg(False, 'Setup failed, this ffmpeg version does not exist!')
        if os.path.exists('/usr/bin/ffmpeg'):
            public.ExecShell('rm -rf /usr/bin/ffmpeg')
        if os.path.exists('/usr/bin/ffmpeg'):
            if os.path.realpath('/usr/bin/ffmpeg') != '/www/server/ffmpeg/{}/ffmpeg'.format(version):
                public.ExecShell('rm -rf /usr/bin/ffmpeg')
        public.ExecShell('ln -s /www/server/ffmpeg/{}/ffmpeg /usr/bin/ffmpeg'.format(version))
        return public.returnMsg(True, 'Setup successful')
