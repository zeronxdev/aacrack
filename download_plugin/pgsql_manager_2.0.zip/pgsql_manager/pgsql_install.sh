#!/bin/bash
#pgsql安装脚本
install_dir=/www/server/pgsql
pgsql_version=$1
down_url=$2
#进入软件的制定安装目录
echo "Enter the directory /usr/local, download pgsql package"
cd /usr/local
#判断是否有postgre版本的安装包
if [ -d postgresql* ]
then
        rm -rf /usr/local/postgresql*
        echo "Installation package deleted successfully"
fi

#开始下载pgsql版本10.5并解压
if [ ! -d /usr/local/src ]
then
        mkdir /usr/local/src
fi

cd /usr/local/src
wget $down_url --no-check-certificate
if [ $? == 0 ]
then
tar -zxf $pgsql_version -C /usr/local/
fi

echo "pgsql package decompressed successfully"
#判断用户是否存在
user=postgres
group=postgres

#create group if not exists
egrep "^$group" /etc/group >& /dev/null
if [ $? -ne 0 ]
then
    groupadd $group
fi

#create user if not exists
egrep "^$user" /etc/passwd >& /dev/null
if [ $? -ne 0 ]
then
    useradd -g $group $user -m
fi

echo "Rename postgresql and enter the installation directory"
mv /usr/local/post* /usr/local/pgsql
cd /usr/local/pgsql
#-------------------------------安装pgsql------------------------------------
echo "Install some library files"
yum install -y zlib zlib-devel uuid uuid-devel >& /del/null
apt-get install -y libossp-uuid-dev
echo "Start the configure step"
./configure --prefix=$install_dir --without-readline --with-uuid=ossp
if [ $? == 0 ]
then
        echo "The configure configuration is passed, and the make compilation starts"
        make
        if [ $? == 0 ]
        then
                echo "Make compile passed, start the make install installation steps"
                make install
                if [ $? != 0 ];then
                        echo "make install failed"
                fi
                echo "Successful installation"
        else
                echo "Make compilation failed, check for errors."
        fi
else
        echo "configure failed to check the configuration, please check the error to install the library file"
fi
echo "Start the configuration of pgsql"
echo "Create a data directory for pgsql"
mkdir -p ${install_dir}/data
mkdir -p ${install_dir}/logs
echo "Modify user group"
chown -R postgres:postgres ${install_dir}
chmod -R 700   ${install_dir}/data

echo "/www/server/pgsql/data" >/www/server/pgsql/data_directory
echo "Add environment variables and enter the home directory of the postgres user"
cd /home/postgres
if [ -f .bash_profile ] ;then
        /bin/cp .bash_profile .bash_profile.bak
        echo "export PGHOME=${install_dir}" >> .bash_profile
        echo "export PGDATA=${install_dir}/data" >> .bash_profile
        echo "export PATH=${install_dir}/bin:\$PATH " >> .bash_profile
        echo "MANPATH=$PGHOME/share/man:$MANPATH" >> .bash_profile
        echo "LD_LIBRARY_PATH=$PGHOME/lib:$LD_LIBRARY_PATH" >> .bash_profile
fi
alias pg_start='pg_ctl -D $PGDATA -l ${install_dir}/logs/pgsql.log start'
alias ps_stop='pg_ctl -D $PGDATA -l ${install_dir}logs/pgsql.log stop'
echo "Switch to the postgres user to initialize the database"
su - postgres -c "${install_dir}/bin/initdb -D ${install_dir}/data"

echo "Enable slow query SQL statement tracking"
cat >> ${install_dir}/data/postgresql.conf <<EOF
logging_collector = on
log_destination = 'stderr'
log_directory = '${install_dir}/logs'
log_filename = 'postgresql-%Y-%m-%d.log'
log_statement = all
log_min_duration_statement = 5000
EOF

su - postgres -c "${install_dir}/bin/postgres -D ${install_dir}/data >>${install_dir}/logs/pgsql.log 2>&1 &"
echo "---------------------------------------------------------------------------------------"
echo "---------------------------------------------------------------------------------------"
echo "----------------------------SUCCESS INSTALLATION OF POSTGRESQL-------------------------"


