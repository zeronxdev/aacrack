#!/bin/bash
# chkconfig: 2345 55 25
# description: bt ddns

### BEGIN INIT INFO
# Provides:          bt ddns
# Required-Start:    $all
# Required-Stop:     $all
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: bt ddns
# Description:       bt ddns
### END INIT INFO
nohup /www/server/panel/pyenv/bin/python /www/server/panel/plugin/bt_ddns/bt_ddns_main.py >/dev/null 2>&1 &
