#!/usr/bin/python
#coding: utf-8
# -------------------------------------------------------------------
# 宝塔Linux面板
# -------------------------------------------------------------------
# Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# -------------------------------------------------------------------
# Author: zhwen <zhw@bt.cn>
# -------------------------------------------------------------------

# -------------------------------------------------------------------
# cloudflare DDNS
# -------------------------------------------------------------------
import sys
base_path = '/www/server/panel/'
sys.path.insert(0, base_path+"class/")
import public
import requests
from json import loads,dumps

class ddns:

    def __init__(self):
        self.endpoints = 'https://api.cloudflare.com/client/v4/'
        self.config_file = base_path+'plugin/bt_ddns/config/cloudflare.json'
        self.zone_file = base_path+'plugin/bt_ddns/config/zone/{}.json'

    def _get_auth_config(self,zone):
        """
        获取认证配置信息
[
  {
    "email": "test@example.com",
    "token": "e1321489bc3dacbade5dfdafasface5ffed3a70c",
    "zone":"example.com"
    }
]
        :return:
        """
        conf = public.readFile(self.config_file)
        if not conf:
            return {}
        try:
            for auth_info in loads(conf):
                if zone == auth_info['zone']:
                    return auth_info
        except:pass
        return {}

    def get_headers(self,email,token,zone,limit_token=None):
        if not limit_token:
            limit_token = self._get_auth_config(zone)['limit_token']
        if limit_token == '1':
            headers = {"Authorization": "Bearer "+token,
                       "Content-Type": "application/json"}
        else:
            headers = {"X-Auth-Email": email, "X-Auth-Key": token,
                       "Content-Type": "application/json"}
        return headers

    def get_conf_zone_info(self,zone):
        """
        获取某个域名信息
{
    "zone":"example.com",
    "zone_id":"",
    "records":[
          {
            "record_name": "record_name",
            "ttl": "auto",
            "content": "1.1.1.1",
            "type": "A",
            "proxy": true
          }
    ]
}
        :param zone_name:
        :return:
        """
        zone_info_file = self.zone_file.format(zone)
        conf = public.readFile(zone_info_file)
        if not conf:
            return {"zone":zone,"dns_hosting":"cloudflare"}
        try:
            return loads(conf)
        except:pass
        return {"zone": zone, "dns_hosting": "cloudflare"}

    # 认证状态

    # 服务状态

    # 设置服务状态

    # 获取域名信息
    def get_zone_info(self,zone):
        auth_conf = self._get_auth_config(zone)
        if not auth_conf:
            return False

        url_params = {"status": "active",
                      "name": zone}
        url_headers = self.get_headers(auth_conf['email'],auth_conf['token'],zone)
        url = self.endpoints + "zones"
        resp = requests.get(url, params=url_params, headers=url_headers)
        return resp.json()['result'][0]

    def check_auth_info(self,data):
        url_params = {"status": "active",
                      "name": data['zone']}
        url_headers = self.get_headers(data['email'],data['token'],data['zone'],data['limit_token'])
        url = self.endpoints + "zones"
        resp = requests.get(url, params=url_params, headers=url_headers)
        return resp.json()['success']

    # 获取zoneid
    def get_zone_id(self,zone):
        # 获取域名ID
        zone_conf_info = self.get_conf_zone_info(zone)
        if zone_conf_info.get('zone_id') and zone_conf_info['zone_id']:
            return zone_conf_info['zone_id']
        zone_info = self.get_zone_info(zone)
        if not zone_info:
            return False
        # 设置域名ID更新到配置
        zone_conf_info["zone_id"] = zone_info['id']
        public.writeFile(self.zone_file.format(zone),dumps(zone_conf_info))
        return zone_info['id']

    # 设置域名到配置
    def _set_ddns_to_conf(self,zone,id,record_name=None,content=None,ttl=1,priority=10,proxied=False,type='A',act=None):
        conf = self.get_conf_zone_info(zone)
        if not conf.get('records'):
            conf['records'] = []
        if act == 'update':
            for c in conf['records']:
                if record_name == c['record_name']:
                    c['record_name'] = record_name
                    c["type"]= type
                    c["content"]= content
                    c["ttl"]= ttl
                    c["priority"]= priority
                    c["proxied"]= proxied
                    c['id'] = id
        elif act == 'delete':
            try:
                for n in range(len(conf['records'])):
                    if id == conf['records'][n]['id']:
                        del(conf['records'][n])
            except:
                pass
        else:
            record = {"record_name": record_name,
                      "type": type,
                      "content": content,
                      "ttl": ttl,
                      "priority": priority,
                      "proxied": proxied,
                      "id":id}
            conf['records'].append(record)
        public.writeFile(self.zone_file.format(zone), dumps(conf))

    # 添加ddns记录
    def add_record(self, *args,**kwargs):
        auth_conf = self._get_auth_config(kwargs['zone'])
        try:
            kwargs['priority'] = int(kwargs['priority'])
        except:
            kwargs['priority'] = 10
        try:
            kwargs['ttl'] = int(kwargs['ttl'])
        except:
            kwargs['ttl'] = 600
        if kwargs['proxied'] == 'false':
            kwargs['proxied'] = False
        else:
            kwargs['proxied'] = True
        if not auth_conf:
            return {'status': False, 'msg': '没有找到对应的认证信息 {}'.format(kwargs['zone'])}
        if kwargs['zone'] in kwargs['record_name']:
            kwargs['record_name'] = kwargs['record_name'].replace('.'+kwargs['zone'],'')
        url_data = {"type":kwargs['type'],"name":kwargs['record_name'],"content":kwargs['content'],"ttl":int(kwargs['ttl']),
                    "priority":int(kwargs['priority']),"proxied":kwargs['proxied']}
        url_headers = self.get_headers(auth_conf['email'], auth_conf['token'],kwargs['zone'])
        url = self.endpoints + "zones/{}/dns_records".format(self.get_zone_id(kwargs['zone']))
        resp = requests.post(url, headers=url_headers,data=dumps(url_data))
        if resp.json()['success']:
            self._set_ddns_to_conf(kwargs['zone'],resp.json()['result']['id'],kwargs['record_name'],kwargs['content'],kwargs['ttl'],
                                   kwargs['priority'],kwargs['proxied'],kwargs['type'])
            return {'status': True, 'msg': 'Added record successfully'}
        return {'status': False, 'msg': 'Failed to add record：{}'.format(resp.json()['errors'])}

    # 更新某一条ddns记录
    def update_record(self, *args,**kwargs):
        """
        :param record_name record.expamel.com:
        :param content:
        :param zone:
        :param type:
        :param ttl:
        :param priority:
        :param proxied bool:
        :return:
        """
        auth_conf = self._get_auth_config(kwargs['zone'])
        if not auth_conf:
            return {'status':False,'msg':'CloudFlare API authentication information is not set'}
        if not kwargs['priority'] or not isinstance(kwargs['priority'],int):
            kwargs['priority'] = 10
        if not kwargs['proxied']:
            kwargs['proxied'] = False
        else:
            if kwargs['proxied'] == 'false':
                kwargs['proxied'] = False
            else:
                kwargs['proxied'] = True
        if not kwargs['ttl'] or not isinstance(kwargs['proxied'],int):
            kwargs['ttl'] = 1
        url_data = {"type":kwargs['type'],"name":kwargs['record_name'],"content":kwargs['content'],"ttl":int(kwargs['ttl']),
                    "priority":int(kwargs['priority']),"proxied":kwargs['proxied']}
        url_headers = self.get_headers(auth_conf['email'], auth_conf['token'],kwargs['zone'])
        url = self.endpoints + "zones/{}/dns_records/{}".format(self.get_zone_id(kwargs['zone']),kwargs['id'])
        resp = requests.put(url, headers=url_headers,data=dumps(url_data))
        if resp.json()['success']:
            self._set_ddns_to_conf(kwargs['zone'],kwargs['id'],kwargs['record_name'],kwargs['content'],kwargs['ttl'],
                                   kwargs['priority'],kwargs['proxied'],kwargs['type'],act='update')
            return {'status':True,'msg':'Successfully updated the record'}
        return {'status': False, 'msg': 'Failed to update record：{}'.format(resp.json()['errors'])}

    def del_record(self,*args,**kwargs):
        """
        :param id:
        :param zone:
        :return:
        """
        auth_conf = self._get_auth_config(kwargs['zone'])
        if not auth_conf:
            return False
        url_headers = self.get_headers(auth_conf['email'], auth_conf['token'],kwargs['zone'])
        url = self.endpoints + "zones/{}/dns_records/{}".format(self.get_zone_id(kwargs['zone']),kwargs['id'])
        resp = requests.delete(url, headers=url_headers)
        if resp.json()['success'] or 'Record does not exist' in resp.json()['errors'][0]['message']:
            self._set_ddns_to_conf(kwargs['zone'],kwargs['id'],act='delete')
            return {'status':True,'msg':'Delete record successfully'}
        return {'status': False, 'msg': 'Failed to delete record：{}'.format(resp.json()['errors'])}

    # 获取ddns记录列表
    def get_ddns_record(self,zone):
        zone_info = self.get_conf_zone_info(zone)
        if zone_info.get('records'):
            return  zone_info.get('records')
        return {}
