#!/usr/bin/python
#coding: utf-8
# -------------------------------------------------------------------
# 宝塔Linux面板
# -------------------------------------------------------------------
# Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# -------------------------------------------------------------------
# Author: zhwen <zhw@bt.cn>
# -------------------------------------------------------------------

# -------------------------------------------------------------------
# BT_DDNS
# -------------------------------------------------------------------
import sys,os,logging,re,importlib
from json import loads,dumps
base_path = '/www/server/panel/'

sys.path.insert(0, base_path+"class/")
import public

class bt_ddns_main:

    def __init__(self):
        self.zone_file = base_path + 'plugin/bt_ddns/config/zone/{}.json'
        self.config_path = base_path + 'plugin/bt_ddns/config/'

    def load_dns_module(self,dns_hosting):
        # 加载需要的dns模块
        sys.path.insert(0,base_path+"plugin/bt_ddns/dns")
        # dns_module = getattr(__import__('dns', fromlist=[dns_hosting]), dns_hosting)
        # dns_module = importlib.import_module('dns.cloudflare')
        dns_module = __import__('{}'.format(dns_hosting))
        return eval('dns_module.ddns()')

    def add_record(self,args):
        """
        record_name a.example.com
        zone example.com
        content 192.168.1.1
        type A
        ttl 120
        priority 10
        proxied true/false/null
        dns_hosting cloudflare
        :param args:
        :return:
        """
        values = self.check_args(args)
        return self.load_dns_module(args.dns_hosting).add_record(record_name=args.record_name,
                                                                 zone=values['zone'],
                                                                 type=args.type,
                                                                 ttl=values['ttl'],
                                                                 priority=values['priority'],
                                                                 proxied=args.proxied,
                                                                 content=values['content'])

    def del_record(self,args):
        """
        zone
        record_id
        dns_hosting
        :param args:
        :return:
        """
        values = self.check_args(args)
        return self.load_dns_module(args.dns_hosting).del_record(zone=values['zone'],
                                                                 id=args.record_id)

    def update_record(self,args):
        """
        record_name a.example.com
        zone example.com
        content 192.168.1.1
        type A
        ttl 120
        priority 10
        proxied true/false/null
        dns_hosting
        record_id
        :param args:
        :return:
        """
        values = self.check_args(args)
        return self.load_dns_module(args.dns_hosting).update_record(record_name=args.record_name,
                                                                    zone=values['zone'],
                                                                    type=args.type,
                                                                    ttl=values['ttl'],
                                                                    priority=values['priority'],
                                                                    proxied=args.proxied,
                                                                    content=values['content'],
                                                                    id=args.record_id)

    def log(self):
        logging.basicConfig(level=logging.INFO,
                            filename=base_path+'/plugin/bt_ddns/service.log',
                            format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s: %(message)s'
                            )
        return logging

    def read_config(self,file):
        conf = public.readFile(file)
        if not conf:
            return {}
        try:
            return loads(conf)
        except:pass
        return {}

    def get_config(self,args=None):
        path = base_path+'plugin/bt_ddns/config/zone/'
        data = []
        for file_name in os.listdir(path):
            full_path = path + file_name
            conf = self.read_config(full_path)
            if not conf:
                continue
            if args:
                if 'zone' in args and args.zone == conf['zone']:
                    return conf['records']
            data.append(conf)
        return data

    def set_auth_info(self,args):
        """
        dns_hosting cloudflare 托管商
        token
        limit_token
        email
        zone
        :param args:
        :return:
        """
        values = self.check_args(args)
        config_file = self.config_path+args.dns_hosting+".json"
        conf = public.readFile(config_file)
        data = {"email":values['email'],"zone":values['zone'],"token":args.token,"limit_token":args.limit_token}
        if not self.load_dns_module(args.dns_hosting).check_auth_info(data):
            return public.returnMsg(False,"API authentication failed")
        if not conf:
            conf = [data]
        else:
            conf = loads(conf)
            if data not in conf:
                conf.append(data)
        public.writeFile(config_file,dumps(conf))
        return public.returnMsg(True,"Added successfully")

    def get_auth_info(self,args):
        """
        获取认证信息
        :param args:
        :return:
        """
        data = []
        conf_files = os.listdir(self.config_path)
        for i in conf_files:
            if ".json" not in i:
                continue
            try:
                data.append({"hosting":i.split('.')[0],"content":loads(public.readFile(self.config_path+i))})
            except:
                pass
        return data

    def del_auth_info(self,args):
        """
        dns_hosting
        token
        :param args:
        :return:
        """
        config_file = self.config_path + args.dns_hosting + ".json"
        conf = public.readFile(config_file)
        if not conf:
            return public.returnMsg(False,"No authentication information found")
        try:
            conf = loads(conf)
        except:
            return public.returnMsg(False,"An error occurred while parsing the configuration to json")
        for i in range(len(conf)):
            if conf[i]['token'] != args.token:continue
            args.zone = conf[i]['zone']
            self.del_all_records(args)
            del (conf[i])
            break
        public.writeFile(config_file,dumps(conf))
        return public.returnMsg(True,"Successfully deleted")

    # 删除所有记录
    def del_all_records(self,args):
        zone_file = base_path+'/plugin/bt_ddns/config/zone/{}.json'.format(args.zone)
        conf = public.readFile(zone_file)
        if not conf:
            return False
        conf = loads(conf)
        for i in conf['records']:
            args.record_id = i['id']
            self.del_record(args)
        if os.path.exists(zone_file):os.remove(zone_file)

    # 执行自动更新服务
    def auto_update_record(self,new_ip):
        zones_info = self.get_config()
        for zone in zones_info:
            for record in zone['records']:
                if new_ip == record['content']:
                    continue
                self.log().info('DNS Record Name:[{}], Content:[{}] Updating to Content:[{}]'.format(record['record_name'],
                                                                                               record['content'],
                                                                                               new_ip))
                dns_hosting = zone['dns_hosting']
                # 加载需要的dns模块
                dns = self.load_dns_module(dns_hosting)
                res = dns.update_record(
                    record_name = record['record_name'],
                    id =record['id'],
                    zone = zone['zone'],
                    content = new_ip,
                    type = record['type'],
                    ttl = record['ttl'],
                    priority = record['priority'],
                    proxied = record['proxied']
                )
                if res['status'] == True:
                    self.log().info('Updated successfully!')
                else:
                    self.log().error(res['msg'])
                return True
        # self.log().info('No record need to update!')

    # 设置服务状态
    def set_service_status(self,args):
        if args.act == '1':
            act = "Started"
            public.ExecShell('systemctl start bt_ddns.service')
        else:
            act = "Stopped"
            public.ExecShell('systemctl stop bt_ddns.service')
        return public.returnMsg(True,'The DDNS has been {}'.format(act))

    # 获取服务状态
    def get_service_status(self,args):
        a,e = public.ExecShell('systemctl status bt_ddns |grep running')
        if a:
            return True
        return False

    # 设置开机启动
    def set_auto_start(self,args):
        if args.act == '1':
            act = "Enabled"
            public.ExecShell('systemctl enable bt_ddns.service')
        else:
            act = "Disabled"
            public.ExecShell('systemctl disable bt_ddns.service')
        return public.returnMsg(True,'The DDNS auto-Start has been {}'.format(act))

    # 取网站日志
    def get_logs(self, get):
        logPath = base_path+'/plugin/bt_ddns/service.log'
        if not os.path.exists(logPath): return public.returnMsg(False, 'LOG_EMPTY')
        return public.returnMsg(True, public.GetNumLines(logPath, 1000))

    def check_args(self,args):
        # 检查email格式
        rep_email = r"^\w+([.-]?\w+)*@.*"
        # 检查域名格式
        rep_domain = r"^(?=^.{3,255}$)[a-zA-Z0-9\_\-][a-zA-Z0-9\_\-]{0,62}(\.[a-zA-Z0-9\_\-][a-zA-Z0-9\_\-]{0,62})+$"
        # 检查IP格式
        rep_ip = r"^(25[0-5]|2[0-4]\d|[0-1]?\d?\d)(\.(25[0-5]|2[0-4]\d|[0-1]?\d?\d)){3}$"
        values = {}
        if hasattr(args,'zone'):
            if re.search(rep_domain, args.zone):
                values["zone"] = str(args.zone)
            else:
                return public.ReturnMsg(False, "Please check if the [zone] format is correct For example: example.com")
        if hasattr(args,'content'):
            if re.search(rep_ip, args.content):
                values["content"] = str(args.content)
            else:
                return public.ReturnMsg(False, "Please check if the [Content] format is correct For example: 1.1.1.1")
        if hasattr(args,'ttl'):
            try:
                values['ttl'] = int(args.ttl)
            except:
                values['ttl'] = 600
        if hasattr(args,'priority'):
            try:
                values['priority'] = int(args.priority)
            except:
                values['priority'] = 10
        if hasattr(args,'email'):
            if re.search(rep_email, args.email):
                values["email"] = str(args.email)
            else:
                return public.ReturnMsg(False, "Please check if the [Email] format is correct For example: test@example.com")
        return values

    def main(self):
        import time
        self.log().info('DDNS Task Starting successfully...')
        while True:
            try:
                new_ip = public.GetLocalIp()
                self.auto_update_record(new_ip)
                time.sleep(300)
            except:
                self.log().error(str(public.get_error_info()))

if __name__ == '__main__':
    b=bt_ddns_main()
    b.main()