#!/bin/bash
PATH=/www/server/panel/pyenv/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
install_tmp='/tmp/bt_install.pl'

#public_file=/www/server/panel/install/public.sh
#if [ ! -f $public_file ];then
#	wget -O $public_file http://node.aapanel.com/install/public.sh -T 5;
#fi
#. $public_file
#
#download_Url=$NODE_URL

Install_Ncdu(){
  yum remove ncdu -y
  name=$1
  ncdu_url=https://dev.yorhel.nl/download/$name
  if [ ! -f $name ];then
    wget $ncdu_url -T 5
    echo "Download completed: $ncdu_url"
  else
    echo "Downloaded: $ncdu_url"
  fi

  if [ ! -f $name ];then
    echo "download failed: $name"
    echo "Please download again"
    return
  fi

  echo "unpacking: $name"
  if tar -xzvf $name ;then
    echo "Decompression complete"
    rm $name
    if [ -L "/usr/bin/ncdu" ];then rm /usr/bin/ncdu; fi
    ln -s /www/server/panel/plugin/disk_analysis/ncdu /usr/bin/ncdu
    chmod +x /www/server/panel/plugin/disk_analysis/ncdu
    chmod +x /usr/bin/ncdu
  fi
  echo `ncdu -v`
}
Install_disk_analysis()
{
  echo 'Installing script file...' > $install_tmp
#  wget -O /www/server/panel/plugin/disk_analysis.zip $download_Url/install/plugin/disk_analysis_en/disk_analysis.zip -T 5 --no-check-certificate
#  cd /www/server/panel/plugin/
#  unzip disk_analysis.zip
#  rm -f disk_analysis.zip

  if [ ! -f "/www/server/panel/plugin/disk_analysis/ncdu" ];then
    cd /www/server/panel/plugin/disk_analysis/
    Install_Ncdu ncdu-2.2.1-linux-x86_64.tar.gz
	fi
	if [ -L "/usr/bin/ncdu" ]; then
    rm /usr/bin/ncdu
    ln -s /www/server/panel/plugin/disk_analysis/ncdu /usr/bin/ncdu
  else
    ln -s /www/server/panel/plugin/disk_analysis/ncdu /usr/bin/ncdu
  fi
  chmod +x /usr/bin/ncdu

	echo '安装完成' > $install_tmp
	echo success
}

Uninstall_disk_analysis()
{
 	rm -rf /www/server/panel/plugin/disk_analysis
}


action=$1
if [ "${1}" == 'install' ];then
	Install_disk_analysis
else
	Uninstall_disk_analysis
fi
