# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板 x3
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2017 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: 王佳函 <mr_jia_han@qq.com>
# +-------------------------------------------------------------------
# +--------------------------------------------------------------------
# |   磁盘文件分析
# +--------------------------------------------------------------------
import copy
import os
import re
import sys
import time
import datetime
import shutil

import public

os.chdir(public.get_panel_path())
sys.path.append("class/")

import json
from typing import Union, Tuple


class disk_analysis_main:
    _PLUGIN_DIR = os.path.join(public.get_plugin_path(), "disk_analysis")
    _PLUGIN_INFO = os.path.join(public.get_plugin_path(), "info.json")

    # 扫描结果存放路径
    _SCAN_DATA_DIR = os.path.join(public.get_setup_path(), "disk_analysis/data/")
    _SCAN_LOG_PATH = os.path.join(public.get_setup_path(), "disk_analysis/scan_log.json")
    _SCAN_CONFIG_PATH = os.path.join(public.get_setup_path(), "disk_analysis/scan_config.json")

    __NCDU_BIN = os.path.join(public.get_plugin_path(), "disk_analysis/ncdu")
    __SCAN_CONFIG_DATA = {
        "scan_config": {
            "scan_path": "/www/wwwroot",
            "exclude_path_list": ["/proc/kcore", "/www/server/panel"],
        },
        "file_show": {  # show_type=2
            "exts": "",
            "total_num": "100",
        }
    }

    __EXT_PS = {
        # 压缩文件
        ".zip": "zip Compressed file",
        ".rar": "rar Compressed file",
        ".7z": "7z Compressed file",
        ".gz": "gz Compressed file",
        ".bz2": "bz2 Compressed file",

        ".tar": "tar archive file",

        # 文档文件
        ".doc": "doc Documentation file",
        ".docx": "docx Documentation file",
        ".pdf": "pdf Documentation file",
        ".txt": "txt Documentation file",
        ".rtf": "rtf Documentation file",

        # 图片文件
        ".jpg": "jpg image file",
        ".jpeg": "jpeg image file",
        ".png": "png image file",
        ".gif": "gif image file",
        ".bmp": "bmp image file",
        ".svg": "svg image file",

        # 音频文件
        ".mp3": "mp3 audio file",
        ".wav": "wav audio file",
        ".flac": "flac audio file",
        ".aac": "aac audio file",
        ".wma": "wma audio file",

        # 视频文件
        ".mp4": "mp4 video file",
        ".mov": "mov video file",
        ".avi": "avi video file",
        ".mkv": "mkv video file",
        ".wmv": "wmv video file",

        # 应用程序
        ".exe": "exe APP",
        ".app": "app APP",
        ".apk": "apk APP",

        # 配置文件
        ".ini": "ini Configuration file",
        ".cfg": "cfg Configuration file",
        ".xml": "xml Configuration file",
        ".json": "json Configuration file",

        # 数据库文件
        ".sql": "sql database file",
        ".db": "db database file",
        ".mdb": "mdb database file",

        # 源代码文件
        ".c": "c Source code files",
        ".cpp": "cpp Source code files",
        ".java": "java Source code files",
        ".py": "py Source code files",
        ".html": "html Source code files",
        ".htm": "htm Source code files",
        ".css": "css Source code files",
        ".js": "js Source code files",
        ".class": "class Java bytecode file",

        # 字体文件
        ".ttf": "ttf font file",
        ".otf": "otf font file",
        ".woff": "woff font file",
        ".woff2": "woff2 font file",

        # 日志文件
        ".log": "log file",

        # 备份文件
        ".bak": "bak backup file",
        ".old": "old backup file",

        # 表格文件
        ".xls": "xls form file",
        ".xlsx": "xlsx form file",
        ".csv": "csv form file",

        # 演示文稿
        ".ppt": "ppt presentation",
        ".pptx": "pptx presentation",
        ".key": "key presentation",

        # 字幕文件
        ".srt": "srt subtitle file",
        ".ass": "ass subtitle file",
        ".vtt": "vtt subtitle file",

        # 磁盘映像文件
        ".iso": "iso disk image file",
        ".img": "img disk image file",

        # 安装器文件
        ".msi": "msi installer file",
        ".dmg": "dmg installer file",
        ".deb": "deb installer file",
        ".rpm": "rpm installer file",

        # 其他文件
        ".dat": "dat Other files",
        ".bin": "bin Other files",
        ".dll": "dll Other files",
    }

    __EXT_OPTION = [
        {"name": "Compressed file", "value": ".zip|.rar|.7z|.gz|.tar|.tar.gz|.tar.bz2"},
        {"name": "Documentation file", "value": ".doc|.docx|.pdf|.txt|.rtf"},
        {"name": "image file", "value": ".jpg|.jpeg|.png|.gif|.bmp|.svg"},
        {"name": "audio file", "value": ".mp3|.wav|.flac|.aac|.wma"},
        {"name": "video file", "value": ".mp4|.mov|.avi|.mkv|.wmv"},
        {"name": "APP", "value": ".exe|.app|.apk"},
        {"name": "Configuration file", "value": ".ini|.cfg|.xml|.json"},
        {"name": "database file", "value": ".sql|.db|.mdb"},
        {"name": "Source code files", "value": ".c|.cpp|.java|.py|.html|.htm|.css|.js"},
        # {"name": "font file", "value": ".ttf|.otf|.woff|.woff2"},
        {"name": "log file", "value": ".log"},
        {"name": "backup file", "value": ".bak|.old"},
        {"name": "form file", "value": ".xls|.xlsx|.csv"},
        {"name": "presentation", "value": ".ppt|.pptx|.key"},
        {"name": "subtitle file", "value": ".srt|.ass|.vtt"},
        {"name": "disk image file", "value": ".iso|.img"},
        {"name": "installer file", "value": ".msi|.dmg|.deb|.rpm"},
        {"name": "Other files", "value": ".dat|.bin|.dll|.class"},
    ]

    __EXT_TYPE_MSG = {
        # 压缩文件
        ".zip": "Compressed file",
        ".rar": "Compressed file",
        ".7z": "Compressed file",
        ".gz": "Compressed file",
        ".bz2": "Compressed file",

        ".tar": "archive file",

        # 文档文件
        ".doc": "Documentation file",
        ".docx": "Documentation file",
        ".pdf": "Documentation file",
        ".txt": "Documentation file",
        ".rtf": "Documentation file",

        # 图片文件
        ".jpg": "image file",
        ".jpeg": "image file",
        ".png": "image file",
        ".gif": "image file",
        ".bmp": "image file",
        ".svg": "image file",

        # 音频文件
        ".mp3": "audio file",
        ".wav": "audio file",
        ".flac": "audio file",
        ".aac": "audio file",
        ".wma": "audio file",

        # 视频文件
        ".mp4": "video file",
        ".mov": "video file",
        ".avi": "video file",
        ".mkv": "video file",
        ".wmv": "video file",

        # 应用程序
        ".exe": "APP",
        ".app": "APP",
        ".apk": "APP",

        # 配置文件
        ".ini": "Configuration file",
        ".cfg": "Configuration file",
        ".xml": "Configuration file",
        ".json": "Configuration file",

        # 数据库文件
        ".sql": "database file",
        ".db": "database file",
        ".mdb": "database file",

        # 源代码文件
        ".c": "Source code files",
        ".cpp": "Source code files",
        ".java": "Source code files",
        ".py": "Source code files",
        ".html": "Source code files",
        ".htm": "Source code files",
        ".css": "Source code files",
        ".js": "Source code files",
        ".class": "Java bytecode file",

        # 字体文件
        ".ttf": "font file",
        ".otf": "font file",
        ".woff": "font file",
        ".woff2": "font file",

        # 日志文件
        ".log": "log file",

        # 备份文件
        ".bak": "backup file",
        ".old": "backup file",

        # 表格文件
        ".xls": "form file",
        ".xlsx": "form file",
        ".csv": "form file",

        # 演示文稿
        ".ppt": "presentation",
        ".pptx": "presentation",
        ".key": "presentation",

        # 字幕文件
        ".srt": "subtitle file",
        ".ass": "subtitle file",
        ".vtt": "subtitle file",

        # 磁盘映像文件
        ".iso": "disk image file",
        ".img": "disk image file",

        # 安装器文件
        ".msi": "installer file",
        ".dmg": "installer file",
        ".deb": "installer file",
        ".rpm": "installer file",

        # 无后缀
        "": "No suffix file",
    }

    # 扫描报告
    __REPORT_LIST = [
        {
            "name": "Highest occupancy file",
            "desc": "The top 10 most occupied files in the current scan",
            "total_asize": 0,
            "total_dsize": 0,
            "sort": "total_asize",
            "reverse": True,
            "num": 10,
            "list": [],
            "color": "red",
        },
        {
            "name": "Files not modified for a long time",
            "desc": "10 files not modified for a long time in the current scan",
            "total_asize": 0,
            "total_dsize": 0,
            "sort": "mtime",
            "reverse": False,
            "num": 10,
            "list": [],
            "color": "org",
        },
        {
            "name": "Recently modified files",
            "desc": "10 latest modified files in the current scan",
            "total_asize": 0,
            "total_dsize": 0,
            "sort": "mtime",
            "reverse": True,
            "num": 10,
            "list": [],
        },
        {
            "name": "The most occupied log",
            "desc": "The top 10 most occupied logs in the current scan",
            "total_asize": 0,
            "total_dsize": 0,
            "ext": ".log",
            "sort": "total_asize",
            "reverse": True,
            "num": 10,
            "list": [],
            "color": "red",
        },
        {
            "name": "Logs that have not been modified for a long time",
            "desc": "10 logs not modified for a long time in the current scan",
            "total_asize": 0,
            "total_dsize": 0,
            "ext": ".log",
            "sort": "mtime",
            "reverse": False,
            "num": 10,
            "list": [],
            "color": "org",
        },
        {
            "name": "Recently modified logs",
            "desc": "10 logs most recently modified in the current scan",
            "total_asize": 0,
            "total_dsize": 0,
            "ext": ".log",
            "sort": "mtime",
            "reverse": True,
            "num": 10,
            "list": [],
        }
    ]

    # 立即扫描 类型概览
    __SCAN_TYPE_OVERVIEW = [
        {"name": "Compressed file", "ext": [".zip", ".rar", ".7z", ".gz", ".tar", ".tar.gz", ".tar.bz2"], "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0, },
        {"name": "Documentation file", "ext": [".doc", ".docx", ".pdf", ".txt", ".rtf"], "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0, },
        {"name": "image file", "ext": [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".svg"], "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0, },
        {"name": "audio file", "ext": [".mp3", ".wav", ".flac", ".aac", ".wma"], "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0, },
        {"name": "video file", "ext": [".mp4", ".mov", ".avi", ".mkv", ".wmv"], "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0, },
        {"name": "APP", "ext": [".exe", ".app", ".apk"], "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0, },
        {"name": "Configuration file", "ext": [".ini", ".cfg", ".xml", ".json"], "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0, },
        {"name": "database file", "ext": [".sql", ".db", ".mdb"], "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0, },
        {"name": "Source code files", "ext": [".c", ".cpp", ".java", ".py", ".html", ".htm", ".css", ".js"], "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0, },
        {"name": "font file", "ext": [".ttf", ".otf", ".woff", ".woff2"], "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0, },
        {"name": "log file", "ext": [".log"], "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0, },
        {"name": "backup file", "ext": [".bak", ".old"], "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0, },
        {"name": "form file", "ext": [".xls", ".xlsx", ".csv"], "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0, },
        {"name": "presentation", "ext": [".ppt", ".pptx", ".key"], "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0, },
        {"name": "subtitle file", "ext": [".srt", ".ass", ".vtt"], "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0, },
        {"name": "disk image file", "ext": [".iso", ".img"], "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0, },
        {"name": "installer file", "ext": [".msi", ".dmg", ".deb", ".rpm"], "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0, },
        {"name": "Other files", "ext": [".dat", ".bin", ".dll", ".class"], "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0, },
    ]
    # 文件类型概览
    __EXT_OVERVIEW = [
        # 压缩文件
        {"name": ".zip", "ext": ".zip", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".rar", "ext": ".rar", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".7z", "ext": ".7z", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".gz", "ext": ".gz", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".bz2", "ext": ".bz2", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},

        {"name": ".tar", "ext": ".tar", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},

        # 文档文件
        {"name": ".doc", "ext": ".doc", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".docx", "ext": ".docx", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".pdf", "ext": ".pdf", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".txt", "ext": ".txt", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".rtf", "ext": ".rtf", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},

        # 图像文件
        {"name": ".jpg", "ext": ".jpg", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".jpeg", "ext": ".jpeg", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".png", "ext": ".png", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".gif", "ext": ".gif", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".bmp", "ext": ".bmp", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".svg", "ext": ".svg", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},

        # 音频文件
        {"name": ".mp3", "ext": ".mp3", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".wav", "ext": ".wav", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".flac", "ext": ".flac", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".aac", "ext": ".aac", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".wma", "ext": ".wma", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},

        # 视频文件
        {"name": ".mp4", "ext": ".mp4", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".mov", "ext": ".mov", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".avi", "ext": ".avi", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".mkv", "ext": ".mkv", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".wmv", "ext": ".wmv", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},

        # 应用程序
        {"name": ".exe", "ext": ".exe", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".app", "ext": ".app", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".apk", "ext": ".apk", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},

        # 配置文件
        {"name": ".ini", "ext": ".ini", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".cfg", "ext": ".cfg", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".xml", "ext": ".xml", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".json", "ext": ".json", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},

        # 数据库文件
        {"name": ".sql", "ext": ".sql", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".db", "ext": ".db", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".mdb", "ext": ".mdb", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},

        # 源代码文件
        {"name": ".c", "ext": ".c", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".cpp", "ext": ".cpp", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".java", "ext": ".java", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".py", "ext": ".py", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".html", "ext": ".html", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".htm", "ext": ".htm", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".css", "ext": ".css", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".js", "ext": ".js", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".class", "ext": ".class", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},

        # 字体文件
        {"name": ".ttf", "ext": ".ttf", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".otf", "ext": ".otf", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".woff", "ext": ".woff", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".woff2", "ext": ".woff2", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},

        # 日志文件
        {"name": ".log", "ext": ".log", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},

        # 备份文件
        {"name": ".bak", "ext": ".bak", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".old", "ext": ".old", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},

        # 表格文件
        {"name": ".xls", "ext": ".xls", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".xlsx", "ext": ".xlsx", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".csv", "ext": ".csv", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},

        # 演示文稿
        {"name": ".ppt", "ext": ".ppt", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".pptx", "ext": ".pptx", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".key", "ext": ".key", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},

        # 字幕文件
        {"name": ".srt", "ext": ".srt", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".ass", "ext": ".ass", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".vtt", "ext": ".vtt", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},

        # 磁盘映像文件
        {"name": ".iso", "ext": ".iso", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".img", "ext": ".img", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},

        # 安装器文件
        {"name": ".msi", "ext": ".msi", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".dmg", "ext": ".dmg", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".deb", "ext": ".deb", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
        {"name": ".rpm", "ext": ".rpm", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},

        # 无后缀
        {"name": "No suffix file", "ext": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "percent": 0},
    ]

    def __init__(self):
        if not os.path.exists(self._SCAN_DATA_DIR):
            os.makedirs(self._SCAN_DATA_DIR)
        if os.path.exists(self.__NCDU_BIN):
            result = public.ExecShell("{} -V".format(self.__NCDU_BIN))[1]
            if result.find("Permission denied") != -1:  # 无权限授权
                public.ExecShell("chmod +x {}".format(self.__NCDU_BIN))
        self.update_2_0()

        if not os.path.isfile(self._SCAN_LOG_PATH):
            public.writeFile(self._SCAN_LOG_PATH, json.dumps({}))
        if not os.path.isfile(self._SCAN_CONFIG_PATH):
            public.writeFile(self._SCAN_CONFIG_PATH, json.dumps(self.__SCAN_CONFIG_DATA))

    def update_2_0(self):
        try:
            scan_config = self.__get_scan_config()
            if scan_config.get("version") != "2.0":
                if scan_config.get("scan_show") is not None:
                    del scan_config["scan_show"]
                scan_config["version"] = "2.0"
                self.__set_scan_config(scan_config)

                scan_log = self.__get_scan_log()

                for scan_id, info in scan_log.items():

                    if isinstance(info.get("scan_time"), int):
                        info["scan_time"] = datetime.datetime.fromtimestamp(info["scan_time"]).strftime("%Y-%m-%d %H:%M:%S")
                    path = os.path.join(self._SCAN_DATA_DIR, scan_id)

                    if os.path.isfile(path):
                        temp_name = os.path.join(self._SCAN_DATA_DIR, "scan")
                        os.rename(path, temp_name)

                        os.makedirs(path)
                        shutil.move(temp_name, path)
                public.writeFile(self._SCAN_LOG_PATH, json.dumps(scan_log))
                for name in os.listdir(self._SCAN_DATA_DIR):
                    path = os.path.join(self._SCAN_DATA_DIR, name)
                    if os.path.isfile(path):
                        os.remove(path)

                public.print_log(f"2.0 Update disk scan configuration file!")
        except Exception as err:
            public.print_log(f"update_err:{err}")

    @classmethod
    def __check_disk(cls):
        # 校验磁盘大小
        df_data = public.ExecShell("df -T | grep '/'")[0]
        for data in str(df_data).split("\n"):
            data_list = data.split()
            if not data_list: continue
            use_size = data_list[4]
            size = data_list[5]
            disk_path = data_list[6]
            if int(use_size) < 1024 * 50 and str(size).rstrip("%") == "100" and disk_path in ["/", "/www"]:
                return f"Your disk is full!'{disk_path}' Available: {use_size}K,Please clear some space first! (50MB and above recommended)"
        return True

    # 获取扫描配置
    @classmethod
    def __get_scan_config(cls, config_type: str = None, field: str = None, default=None) -> Union[dict, str, int, None]:
        """
        获取扫描配置
        @param config_type: 配置类型
        @param field: 配置名称
        @param default: 默认值
        @return:
        """
        try:
            scan_config_data = json.loads(public.readFile(cls._SCAN_CONFIG_PATH))
        except:
            scan_config_data = cls.__SCAN_CONFIG_DATA

        if config_type is not None:
            scan_config_data = scan_config_data.get(config_type)
        if field is not None:
            scan_config_data = scan_config_data.get(field, default)
        return scan_config_data

    # 设置扫描配置
    @classmethod
    def __set_scan_config(cls, config: dict) -> None:
        """
        设置扫描配置
        @param config: 扫描配置
        @return:
        """
        public.writeFile(cls._SCAN_CONFIG_PATH, json.dumps(config))

    # 获取上次扫描路径
    def get_last_scan_path(self, get):
        scan_path = self.__get_scan_config("scan_config", "scan_path", "/www/wwwroot")
        return {"status": True, "msg": "ok", "data": scan_path}

    # 获取扫描配置
    def get_scan_config(self, get):
        scan_config = self.__get_scan_config()

        return {"status": True, "msg": "ok", "data": scan_config}

    # 设置扫描配置
    def set_scan_config(self, get):
        exclude_path_list = json.loads(getattr(get, "exclude_path_list", "[]"))
        total_num = getattr(get, "total_num", None)

        scan_config = self.__get_scan_config()

        # 扫描设置
        if exclude_path_list:
            scan_config["scan_config"]["exclude_path_list"] = exclude_path_list
        # 文件展示
        if total_num is not None:
            scan_config["file_show"]["total_num"] = total_num
        self.__set_scan_config(scan_config)

        return {"status": True, "msg": "Set up scan configuration successfully!", "data": scan_config}

    # 获取扫描记录
    @classmethod
    def __get_scan_log(cls, scan_id: Union[str, None] = None, default=None) -> Union[dict, list]:
        """
        获取扫描记录
        @param scan_id:
        @return:
        """
        try:
            scan_log = json.loads(public.readFile(cls._SCAN_LOG_PATH))
        except:
            scan_log = {}

        if scan_id is not None:
            return scan_log.get(scan_id, default)
        return scan_log

    # 设置扫描记录
    @classmethod
    def __set_scan_log(cls, scan_id: str, info: dict) -> None:
        """
        设置扫描记录
        @param scan_id:
        @param info:
        @return:
        """
        try:
            scan_log = json.loads(public.readFile(cls._SCAN_LOG_PATH))
        except:
            scan_log = {}

        scan_log[scan_id] = info
        public.writeFile(cls._SCAN_LOG_PATH, json.dumps(scan_log))

    # 删除扫描记录
    @classmethod
    def __del_scan_log(cls, scan_id: str):
        """
        设置扫描记录
        @param scan_id:
        @param info:
        @return:
        """
        try:
            scan_log = json.loads(public.readFile(cls._SCAN_LOG_PATH))
        except:
            scan_log = {}

        # 删除配置
        if scan_log.get(scan_id) is not None:
            del scan_log[scan_id]
            public.writeFile(cls._SCAN_LOG_PATH, json.dumps(scan_log))

        # 删除文件
        scan_data_dir = os.path.join(cls._SCAN_DATA_DIR, scan_id)
        if os.path.exists(scan_data_dir):
            public.ExecShell("rm -rf {}".format(scan_data_dir))
        public.writeFile(cls._SCAN_LOG_PATH, json.dumps(scan_log))

    # 判断记录是否存在
    @classmethod
    def __exist_scan_log(cls, scan_id: str) -> bool:
        """
        判断记录是否存在
        @param scan_id:
        @return:
        """
        try:
            scan_log = json.loads(public.readFile(cls._SCAN_LOG_PATH))
        except:
            scan_log = {}

        return scan_log.get(scan_id) is not None

    # 获取扫描日志
    def get_scan_log(self, get):
        """
        获取扫描日志
        @param get:
        @return:
        """
        scan_log = self.__get_scan_log()

        scan_log_list = []
        for scan_id, info in scan_log.items():
            info["scan_id"] = scan_id
            info["status"] = False

            scan_dir = os.path.join(self._SCAN_DATA_DIR, scan_id)
            if os.path.exists(scan_dir):
                info["size"] = public.get_path_size(scan_dir)
                info["status"] = True
            if isinstance(info["scan_time"], float):
                info["scan_time"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(info["scan_time"]))
            scan_log_list.append(info)

        scan_log_list = sorted(scan_log_list, key=lambda data: data["scan_time"], reverse=True)
        return {"status": True, "msg": "ok", "data": scan_log_list}

    # 删除指定扫描记录
    def del_scan_log(self, get):
        """
        删除指定扫描记录
        @param get:
        @return:
        """
        if not hasattr(get, "scan_id"):
            return public.returnMsg(False, "Missing parameters! scan_id")

        scan_id = get.scan_id

        self.__del_scan_log(scan_id)
        return public.returnMsg(True, "successfully deleted!")

    # 获取权限状态信息
    @classmethod
    def __get_stat(cls, info) -> None:
        info["ext"] = os.path.splitext(info["name"])[1].lower()
        if not os.path.exists(info["full_path"]):
            info["status"] = 0
            info["accept"] = None
            info["user"] = None
            info["atime"] = None
            info["ctime"] = None
            info["mtime"] = None
            info["ps"] = None
            return

        info["status"] = 1
        # 获取文件信息
        stat_file = os.stat(info["full_path"])

        info["accept"] = oct(stat_file.st_mode)[-3:]
        import pwd
        try:
            info["user"] = pwd.getpwuid(stat_file.st_uid).pw_name
        except:
            info["user"] = str(stat_file.st_uid)
        info["atime"] = datetime.datetime.fromtimestamp(stat_file.st_atime).strftime("%Y-%m-%d %H:%M:%S")
        info["ctime"] = datetime.datetime.fromtimestamp(stat_file.st_ctime).strftime("%Y-%m-%d %H:%M:%S")
        info["mtime"] = datetime.datetime.fromtimestamp(stat_file.st_mtime).strftime("%Y-%m-%d %H:%M:%S")
        info["is_delete"], info["ps"] = cls.get_file_ps(info["full_path"])
        if info["ext"] in ["jpg", "jpeg", "png", "gif", "bmp", "svg"]:
            info["base64"] = cls.get_image_thumbnail(info)

    @classmethod
    def get_file_ps(cls, path: str) -> Tuple[bool, Union[str, None]]:
        '''
            @name 获取文件或目录备注
            @author hwliang<2020-10-22>
            @param path<string> 文件或目录全路径
            @return string
        '''

        ps_path = os.path.join(public.get_panel_path(), "data/files_ps")
        f_key1 = "/".join((ps_path, public.md5(path)))
        if os.path.exists(f_key1):
            return True, public.readFile(f_key1)

        f_key2 = "/".join((ps_path, public.md5(os.path.basename(path))))
        if os.path.exists(f_key2):
            return True, public.readFile(f_key2)

        pss = {
            "/www/backup/database/mysql": "Mysql Database backup",
            "/www/backup/database/redis": "redis Database backup",
            "/www/backup/database/mong odb": "MongoDB Database backup",
            "/www/backup/database/pgsql": "PgSql Database backup",
            "/www/backup/mysql_bin_log": "Mysql incremental backup",
            "/www/backup/database": "Database backup",
            "/www/backup/panel": "Panel data backup",
            "/www/backup/site": "Website backup",
            "/www/.Recycle_bin": "Recycle bin",
            "/www/wwwlogs": "Website log",
            "/www/backup": "Backup directory",
            "/www/wwwroot": "Default website",
            "/www/server/cron": "Scheduled task Path",
            "/www/server/panel": "aaPanel Path",
            "/www/server/pure-ftpd": "FTP Path",
            "/www/server/nginx": "Nginx Path",
            "/www/server/apache": "Apache Path",
            "/www/server/php": "PHP Path",
            "/www/server/nodejs": "nodejs Path",
            "/www/server/mysql": "MySQL Path",
            "/www/server/data": "MySQL default database",
            "/www/server/mongodb": "MongoDB Path",
            "/www/server/redis": "Redis Path",
            "/www/server/pgsql": "PgSql Path",
            "/www/server/phpmyadmin": "PhpMyAdmin Path",
            "/www/server/stop": "Website disabled page",
            "/www/server/rar": "rar Extension library",
            "/www/server/nvm": "PM2/NVM/NPM Path",
            "/www/server/pass": "Website BasicAuth password storage",
            "/www/server/speed": "Website acceleration data",
            "/www/server/docker": "Docker plugin and data",
            "/www/server/btwaf": "Nginx WAF Path",
            "/www/server/tomcat": "Tomcat Path",
            "/www/php_session": "PHP-SESSION quarantine directory",
            "/www/server/binlog_analysis": "Binary log analysis data",
            "/www/server/disk_analysis": "[disk_analysis] data",
            "/www/server/database_master": "[Database Tool] data",
            "/www/server/total/logs": "[Website statistics] Log",
            "/www/server/total": "[Website statistics] data",
            "/proc": "system process directory",
            "/dev": "system device directory",
            "/sys": "system call directory",
            "/tmp": "system temporary file",
            "/var/log": "System log directory",
            "/var/run": "System running log ",
            "/var/spool": "system queue path",
            "/var/lock": "system lock path",
            "/var/mail": "system mail path",
            "/mnt": "System mount path",
            "/media": "System multimedia path",
            "/dev/shm": "system shared memory",
            "/lib": "System library path",
            "/lib64": "System library path",
            "/lib32": "System library path",
            "/usr/lib": "System library path",
            "/usr/lib64": "System library path",
            "/usr/local/lib": "System library path",
            "/usr/local/lib64": "System library path",
            "/usr/local/libexec": "System library path",
            "/usr/local/sbin": "System script directory",
            "/usr/local/bin": "System script directory"

        }
        for t_path, ps in pss.items():
            if path == t_path:  return False, ps
            # if str(path).startswith(t_path):
            #     if os.path.isdir(path):
            #         return False, ps
            # if os.path.isfile(path):
            #     return False, ps

        _, ext = os.path.splitext(path)
        return True, cls.__EXT_PS.get(ext, "")

    # 获取图片缩略图
    @classmethod
    def get_image_thumbnail(cls, info: dict) -> str:
        from PIL import Image
        from base64 import b64encode
        from io import BytesIO
        width = 45
        height = 45

        # 缩略图缓存路径
        image_thumbnail_cache_dir = os.path.join(public.get_panel_path(), "cache/thumbnail")
        if not os.path.exists(image_thumbnail_cache_dir):
            os.makedirs(image_thumbnail_cache_dir, 384)

        cache_file = os.path.join(image_thumbnail_cache_dir, public.md5("{}_{}_{}_{}".format(info["full_path"], width, height, info["asize"])))

        # 有缩略图缓存的使用缓存
        if os.path.exists(cache_file):
            return public.readFile(cache_file)

        try:
            image = Image.open(info["full_path"])
            image.thumbnail((width, height))
            out = BytesIO()
            image.save(out, image.format)
            out.seek(0)
            mimetype = os.path.join("image", image.format.lower())
            b64_data = "data:{};base64,".format(mimetype) + b64encode(out.read()).decode("utf-8")
            out.close()
            # 写缩略图缓存
            public.writeFile(cache_file, b64_data)
            return b64_data
        except:
            return ""

    # 扫描磁盘
    def start_scan(self, get):
        """
        @name 扫描磁盘
        @param path 扫描目录
        """
        # 校验磁盘大小
        resp = self.__check_disk()
        if isinstance(resp, str):
            return public.returnMsg(False, resp)

        if not hasattr(get, "scan_path"):
            return public.returnMsg(False, f"Missing parameters! scan_path")

        scan_path = get.scan_path
        scan_type = getattr(get, "scan_type", 0)
        exclude_path = json.loads(getattr(get, "exclude_path", "[]"))

        exclude_path = [path for path in exclude_path if path]
        # if len(exclude_path) == 0:  # 获取默认排除路径
        #     exclude_path = self.__get_scan_config("scan_config", "exclude_path_list", [])

        exclude_path_list = ["--exclude '{}'".format(os.path.join(scan_path, url)) for url in exclude_path]

        if not os.path.isdir(scan_path):
            return public.returnMsg(False, "Directory does not exist.")

        if scan_type == 0:
            scan_config = self.__get_scan_config()
            scan_config["scan_config"]["scan_path"] = scan_path
            self.__set_scan_config(scan_config)

        # 生成 id
        scan_id = str(int(time.time() * 1000_000))
        while self.__exist_scan_log(scan_id):
            scan_id = str(int(time.time() * 1000_000))

        result_dir = os.path.join(self._SCAN_DATA_DIR, scan_id)
        if not os.path.exists(result_dir):
            os.makedirs(result_dir)
        scan_result_file = os.path.join(result_dir, "scan")

        exec_shell = "'{}' '{}' -o '{}' {} ".format(self.__NCDU_BIN, scan_path, scan_result_file, " ".join(exclude_path_list)).replace("\\", "/").replace("//", "/")
        scan_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        result = public.ExecShell(exec_shell)[1]

        if result.find("Permission denied") != -1:  # 无权限授权
            public.ExecShell("chmod +x /usr/bin/ncdu")
            result = public.ExecShell(exec_shell)[1]
        if result.find("ncdu: command not found") != -1:  # 连接不存在
            public.ExecShell("ln -s /www/server/panel/plugin/disk_analysis/ncdu /usr/bin/ncdu && chmod +x /usr/bin/ncdu")
            public.ExecShell(exec_shell)[1]

        if not os.path.isfile(scan_result_file):
            return public.returnMsg(False, f"Scan error! Please check:<br/>1. Whether the server disk is full, please make sure the / or /www disk has free space!")
            # return public.returnMsg(False, f"扫描错误！请检查：<br/>1. 服务器磁盘是否已满，请确保 / 或 /www 磁盘有可用空间！")

        log_size = os.path.getsize(scan_result_file)

        scan_log_info = {
            "scan_path": scan_path,
            "scan_type": int(scan_type),
            "scan_time": scan_time,
            "size": log_size,
            "exclude_path_list": exclude_path,
        }
        self.__set_scan_log(scan_id, scan_log_info)
        public.set_module_logs("disk_analysis", "Scan now", 1)
        return {"status": True, "msg": "Scan completed!", "data": {"scan_id": scan_id}}

    # 获取概览页面
    def get_scan_overview(self, get):
        if not hasattr(get, "scan_id"):
            return public.returnMsg(False, "Missing parameters! scan_id")

        scan_id = get.scan_id

        scan_info = self.__get_scan_log(scan_id)
        if scan_info is None:
            self.__del_scan_log(scan_id)  # 删除记录
            return public.returnMsg(False, "Scan result does not exist")

        overview_result_file = os.path.join(self._SCAN_DATA_DIR, scan_id, "overview")
        if os.path.exists(overview_result_file):
            overview_data = public.readFile(overview_result_file)
            try:
                overview_data = json.loads(overview_data)
            except:
                os.remove(overview_result_file)
        else:
            scan_result_file = os.path.join(self._SCAN_DATA_DIR, scan_id, "data")
            if os.path.exists(scan_result_file):
                scan_result = public.readFile(scan_result_file)
                scan_result = json.loads(scan_result)
            else:
                # 扫描结果文件
                scan_data_file = os.path.join(self._SCAN_DATA_DIR, scan_id, "scan")

                data = public.readFile(scan_data_file)
                data = json.loads(data)

                scan_result = {}
                for info in data:
                    if not isinstance(info, list): continue
                    full_path = info[0]["name"]
                    info[0]["full_path"] = full_path
                    scan_result = self.__analysis_scan_result(info)
                public.writeFile(scan_result_file, json.dumps(scan_result))

            overview_data = {
                "total_asize": scan_result["total_asize"],
                "total_dsize": scan_result["total_dsize"],
                "file_num": scan_result["file_num"],
                "dir_num": scan_result["dir_num"],
                "scan_time": scan_info.get("scan_time"),
                "type_list": copy.deepcopy(self.__SCAN_TYPE_OVERVIEW),  # 概览列表，默认: 立即扫描
                "ext_list": copy.deepcopy(self.__EXT_OVERVIEW),  # 概览列表
                "report_list": copy.deepcopy(self.__REPORT_LIST),  # 报告列表
            }
            path_dict = None
            ext_dict = {}
            if scan_info.get("scan_type", 0) == 1:  # 宝塔服务
                # public.print_log("解析：宝塔服务")
                backup_path = self.__get_backup_path()
                script_dir, log_dir = self.__get_webhook_dir()
                overview_data["type_list"] = [
                    {"name": "Backup", "path": backup_path, "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "Database Backup", "path": os.path.join(backup_path, "database"), "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "Mysql Database Backup", "path": os.path.join(backup_path, "database/mysql"), "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "redis Database Backup", "path": os.path.join(backup_path, "database/redis"), "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "MongoDB Database Backup", "path": os.path.join(backup_path, "database/mongodb"), "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "PgSql Database Backup", "path": os.path.join(backup_path, "database/pgsql"), "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "Panel data backup", "path": os.path.join(backup_path, "panel"), "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "Mysql Incremental backup", "path": os.path.join(backup_path, "mysql_bin_log"), "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "Website backup", "path": os.path.join(backup_path, "site"), "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "Recycle bin path", "path": "/www/.Recycle_bin", "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "Website log path", "path": "/www/wwwlogs", "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "Default website path", "path": "/www/wwwroot", "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "Scheduled task path", "path": "/www/server/cron", "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "aaPanel Path", "path": "/www/server/panel", "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "FTP Path", "path": "/www/server/pure-ftpd", "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "Nginx Path", "path": "/www/server/nginx", "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "Apache Path", "path": "/www/server/apache", "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "PHP Path", "path": "/www/server/php", "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "nodejs Path", "path": "/www/server/nodejs", "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "MySQL Path", "path": "/www/server/mysql", "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "MongoDB Path", "path": "/www/server/mongodb", "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "Redis Path", "path": "/www/server/redis", "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "PgSql Path", "path": "/www/server/pgsql", "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "PhpMyAdmin Path", "path": "/www/server/phpmyadmin", "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "Mysql default database path", "path": self.__get_mysql_datadir(), "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "Website disabled page", "path": "/www/server/stop", "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "rar Extension library", "path": "/www/server/rar", "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "PM2/NVM/NPM Path", "path": "/www/server/nvm", "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "Website BasicAuth password storage", "path": "/www/server/pass", "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "Website acceleration data", "path": "/www/server/speed", "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "Docker plug-ins and data", "path": "/www/server/docker", "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "Nginx WAF Path", "path": "/www/server/btwaf", "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "Tomcat Path", "path": "/www/server/tomcat", "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "PHP-SESSION Path", "path": "/www/server/php_session", "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "Binary log analysis data", "path": "/www/server/binlog_analysis", "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "[disk_analysis] data", "path": "/www/server/disk_analysis", "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "[Database Tool] data", "path": "/www/server/database_master", "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "[Website statistics] data", "path": "/www/server/total", "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "[Website statistics] log", "path": "/www/server/total/logs", "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "[webhoo] script", "path": script_dir, "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "[webhoo] log", "path": log_dir, "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "[File sync tool] log", "path": "/www/server/bt_sync/logs", "desc": "", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                ]

                path_dict = {}
                for item in overview_data["type_list"]:
                    path_dict[item["path"]] = item
            elif scan_info.get("scan_type", 0) == 2:  # 系统扫描
                # public.print_log("解析：系统扫描")
                overview_data["type_list"] = [
                    {"name": "/bin", "path": "/bin", "desc": "Binary file path", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "/boot", "path": "/boot", "desc": "boot file path", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "/cdrom", "path": "/cdrom", "desc": "Mount a disc or CD-ROM", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "/dev", "path": "/dev", "desc": "Device file", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "/etc", "path": "/etc", "desc": "System configuration file", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "/home", "path": "/home", "desc": "User home directory", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "/lib", "path": "/lib", "desc": "Shared library file ", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "/lib32", "path": "/lib32", "desc": "32-bit shared library file", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "/lib64", "path": "/lib64", "desc": "64-bit shared library file", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "/libx32", "path": "/libx32", "desc": "x32 bit shared library file", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "/media", "path": "/media", "desc": "Removable media device catalog", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "/mnt", "path": "/mnt", "desc": "Temporary mounting directory", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "/opt", "path": "/opt", "desc": "Optional package directory", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "/patch", "path": "/patch", "desc": "System or application patch file", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "/proc", "path": "/proc", "desc": "virtual file system", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "/root", "path": "/root", "desc": "root user's home directory", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "/run", "path": "/run", "desc": "Runtime system directory", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "/sbin", "path": "/sbin", "desc": "System binary file", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "/snap", "path": "/snap", "desc": "Mount directory of Snap package management system", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "/srv", "path": "/srv", "desc": "Storage service-related data", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "/sys", "path": "/sys", "desc": "Kernel and system hardware related file directories", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "/tmp", "path": "/tmp", "desc": "Store temporary file path", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "/usr", "path": "/usr", "desc": "Installation directory for user and system applications, library files, and documents", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                    {"name": "/www", "path": "/www", "desc": "aaPanel Path", "total_asize": 0, "total_dsize": 0, "file_num": 0, "dir_num": 0},
                ]

                path_dict = {}
                for item in overview_data["type_list"]:
                    path_dict[item["path"]] = item

            for item in overview_data["ext_list"]:
                ext_dict[item["ext"]] = item

            self.__analysis_scan_overview(scan_result, overview_data, path_dict, ext_dict)

            num = len(overview_data["ext_list"])
            idx = 0
            while idx < num:
                if overview_data["ext_list"][idx]["total_asize"] == 0:
                    del overview_data["ext_list"][idx]
                    num -= 1
                    continue

                overview_data["ext_list"][idx]["percent"] = round(overview_data["ext_list"][idx]["total_asize"] / overview_data["total_asize"] * 100, 2)

                if scan_info.get("scan_type", 0) == 0:
                    for info in overview_data["type_list"]:
                        if overview_data["ext_list"][idx]["ext"] in info["ext"]:
                            info["total_asize"] += overview_data["ext_list"][idx]["total_asize"]
                            info["total_dsize"] += overview_data["ext_list"][idx]["total_dsize"]
                            info["file_num"] += overview_data["ext_list"][idx]["file_num"]
                idx += 1

            num = len(overview_data["type_list"])
            idx = 0
            while idx < num:
                if overview_data["type_list"][idx]["total_asize"] == 0:
                    del overview_data["type_list"][idx]
                    num -= 1
                    continue

                overview_data["type_list"][idx]["percent"] = round(overview_data["type_list"][idx]["total_asize"] / overview_data["total_asize"] * 100, 2)
                idx += 1

            for item in overview_data["report_list"]:
                for info in item["list"]:
                    self.__get_stat(info)
            public.writeFile(overview_result_file, json.dumps(overview_data))
        return {"status": True, "msg": "ok", "scan_info": scan_info, "overview": overview_data}

    # 获取立即扫描结果概览
    @classmethod
    def __analysis_scan_overview(cls,
                                 scan_result: dict,  # 解析数据
                                 overview_data: dict,  # 解析结果
                                 path_dict: dict,
                                 ext_dict: dict,
                                 ):
        for item in scan_result["list"]:
            if path_dict is not None and item["full_path"] in path_dict:
                path_dict[item["full_path"]]["total_asize"] = item["total_asize"]
                path_dict[item["full_path"]]["total_dsize"] = item["total_dsize"]
                path_dict[item["full_path"]]["file_num"] = item["file_num"]
                path_dict[item["full_path"]]["dir_num"] = item["dir_num"]

            if item["type"] == 0:
                ext = os.path.splitext(item["name"])[1].lower()
                if ext in ext_dict:
                    ext_dict[ext]["total_asize"] = item["total_asize"]
                    ext_dict[ext]["total_dsize"] = item["total_dsize"]
                    ext_dict[ext]["file_num"] += 1

                if os.path.exists(item["full_path"]):
                    for info in overview_data["report_list"]:
                        item["type"] = 0
                        item["mtime"] = int(os.path.getmtime(item["full_path"]))
                        cls.__sort_list_num(data=item, info=info)
            elif len(item.get("list", [])) > 0:
                cls.__analysis_scan_overview(item, overview_data, path_dict, ext_dict)

    # 获取备份目录
    @classmethod
    def __get_backup_path(cls) -> str:
        try:
            backup_path = public.M("config").where("id=?", (1,)).getField("backup_path")
        except:
            backup_path = "/www/backup"
        return backup_path

    # 获取 Mysql 数据目录
    @classmethod
    def __get_mysql_datadir(cls) -> str:
        from panelMysql import panelMysql
        data_dir = None
        try:
            data = panelMysql().query("show variables like 'datadir';")
        except:
            data = []
            # public.print_log("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")

        if data and isinstance(data, list):
            data_dir = data[0][1]

        if data_dir is None:
            myfile = "/etc/my.cnf"
            mycnf = public.readFile(myfile)
            try:
                data_dir = re.search("datadir\s*=\s*(.+)\n", mycnf).groups()[0]
            except:
                data_dir = "/www/server/data"
        return data_dir

    # 获取 webhook 目录
    @classmethod
    def __get_webhook_dir(cls) -> Tuple[str, str]:
        """
        获取 webhook 目录
        @return: 脚本目录，日志目录
        """
        plugin_config = os.path.join(public.get_plugin_path(), "webhook/config.json")
        try:
            if not os.path.exists(plugin_config):
                return "/www/server/panel/plugin/webhook/script", "/www/server/panel/plugin/webhook/log"
            plugin_config = json.loads(public.readFile(plugin_config))
        except:
            plugin_config = {
                "config": {
                    "script_dir": os.path.join(cls._PLUGIN_DIR, "script"),
                    "log_dir": os.path.join(cls._PLUGIN_DIR, "log"),
                }

            }
        script_dir = plugin_config.get("script_dir", "/www/server/panel/plugin/webhook/script")
        log_dir = plugin_config.get("log_dir", "/www/server/panel/plugin/webhook/log")
        return script_dir, log_dir

    @classmethod
    def __sort_list_num(cls, data, info):

        ext = info.get("ext", None)
        sort = info["sort"]
        num = info.get("num", 10)
        reverse = info.get("reverse", False)

        if ext is not None:
            _, file_ext = os.path.splitext(data["name"])
            if file_ext != ext:
                return

        info["list"].append(data)
        info["list"].sort(key=lambda data: (data[sort]), reverse=reverse)
        if len(info["list"]) > num:
            del info["list"][-1]

    # 获取扫描结果
    def get_scan_result(self, get):
        """
        获取扫描结果
        @param get:
        @return:
        """
        if not hasattr(get, "scan_id"):
            return public.returnMsg(False, "Missing parameters! scan_id")

        scan_id = get.scan_id
        sub_path = getattr(get, "sub_path", None)
        file_name = getattr(get, "file_name", None)
        sort = getattr(get, "sort", "total_asize")
        reverse = getattr(get, "reverse", "true")

        if not sort: sort = "total_asize"
        if not reverse: reverse = "true"
        reverse = reverse == "true"
        sub_path = str(sub_path).replace("//", "/").rstrip("/")

        scan_info = self.__get_scan_log(scan_id)
        if scan_info is None:
            self.__del_scan_log(scan_id)  # 删除记录
            return public.returnMsg(False, "Scan result does not exist")

        scan_result_file = os.path.join(self._SCAN_DATA_DIR, scan_id, "data")
        if os.path.exists(scan_result_file):
            scan_result = public.readFile(scan_result_file)
            scan_result = json.loads(scan_result)
        else:
            # 扫描结果文件
            scan_data_file = os.path.join(self._SCAN_DATA_DIR, scan_id, "scan")
            scan_info = self.__get_scan_log(scan_id)
            if not os.path.isfile(scan_data_file):
                self.__del_scan_log(scan_id)  # 删除记录
                return public.returnMsg(False, "Scan result does not exist")

            data = public.readFile(scan_data_file)
            data = json.loads(data)

            scan_result = {}
            for info in data:
                if not isinstance(info, list): continue
                full_path = info[0]["name"]
                info[0]["full_path"] = full_path
                scan_result = self.__analysis_scan_result(info)
            public.writeFile(scan_result_file, json.dumps(scan_result))

        if sub_path and sub_path != scan_result["full_path"]:
            scan_result = self.__get_sub_result(scan_result, sub_path)
            if scan_result is None:
                return public.returnMsg(False, "Scan result does not exist {}！".format(sub_path))

        num = len(scan_result["list"])
        idx = 0
        while idx < num:
            info = scan_result["list"][idx]
            if file_name and file_name not in info["name"]:
                del scan_result["list"][idx]
                num -= 1
                continue

            if info.get("list") is not None:
                del info["list"]
            idx += 1

        total_max = scan_result["total_asize"]
        for info in scan_result["list"]:
            if total_max == 0:
                info["percent"] = 0
            else:
                info["percent"] = round(info["total_asize"] / total_max * 100, 2)
            self.__get_stat(info)

        scan_result["list"].sort(key=lambda data: (data["status"], data[sort]), reverse=reverse)
        if reverse is False:
            scan_result["list"].sort(key=lambda data: (data["status"]), reverse=True)

        scan_result["scan_time"] = scan_info.get("scan_time")
        return {"status": True, "msg": "ok", "scan_info": scan_info, "data": scan_result}

    # 获取子目录数据
    @classmethod
    def __get_sub_result(cls, scan_result: dict, sub_path: str) -> Union[list, None]:
        for item in scan_result["list"]:
            if item["full_path"] == sub_path:
                return item
            elif len(item.get("list", [])) > 0 and sub_path.startswith(item["full_path"]):
                info = cls.__get_sub_result(item, sub_path)
                if info is not None:
                    return info
        return None

    # 解析扫描结果信息
    @classmethod
    def __analysis_scan_result(cls, analysis_data: list) -> dict:
        """
        @name 解析扫描结果信息
        @param analysis_data 扫描结果
        @param result 结果
        """
        scan_result = analysis_data[0]
        scan_result["type"] = 1
        # scan_result["files"] = 0
        # scan_result["dirs"] = 0
        scan_result["dir_num"] = 0
        scan_result["file_num"] = 0
        scan_result["total_asize"] = scan_result.get("asize", 0)
        scan_result["total_dsize"] = scan_result.get("dsize", 0)
        scan_result["list"] = []

        for info in analysis_data[1:]:
            if isinstance(info, list):  # 目录
                # scan_result["dirs"] += 1
                scan_result["dir_num"] += 1
                info[0]["full_path"] = os.path.join(scan_result["full_path"], info[0]["name"])
                cls.__get_dir_size(info)
                info = info[0]
                scan_result["dir_num"] += info["dir_num"]
                scan_result["file_num"] += info["file_num"]
                scan_result["total_asize"] += info["total_asize"]
                scan_result["total_dsize"] += info["total_dsize"]
            else:
                info["full_path"] = os.path.join(scan_result["full_path"], info["name"])
                if info.get("excluded") == "pattern":
                    info["excluded"] = True
                    info["type"] = int(os.path.isdir(info["full_path"]))
                    if info["type"] == 1:  # 排除目录
                        # info["files"] = 0
                        # info["dirs"] = 0
                        info["file_num"] = 0
                        info["dir_num"] = 0
                else:
                    info["excluded"] = False
                    info["type"] = 0
                    # info["files"] = -1
                    # info["dirs"] = -1
                    info["file_num"] = -1
                    info["dir_num"] = -1

                # scan_result["files"] += 1
                scan_result["file_num"] += 1
                info["total_asize"] = info.get("asize", 0)
                info["total_dsize"] = info.get("dsize", 0)
                scan_result["total_asize"] += info["total_asize"]
                scan_result["total_dsize"] += info["total_dsize"]
            scan_result["list"].append(info)
        return scan_result

    # 计算目录大小信息
    @classmethod
    def __get_dir_size(cls, analysis_data):
        """
        @param analysis_data 计算目录大小信息
        """
        dir_info = analysis_data[0]
        dir_info["type"] = 1
        # dir_info["files"] = 0
        # dir_info["dirs"] = 0
        dir_info["dir_num"] = 0
        dir_info["file_num"] = 0
        dir_info["total_asize"] = dir_info.get("asize", 0)
        dir_info["total_dsize"] = dir_info.get("dsize", 0)
        dir_info["list"] = []

        for info in analysis_data[1:]:
            if isinstance(info, list):  # 目录
                # dir_info["dirs"] += 1
                dir_info["dir_num"] += 1
                info[0]["full_path"] = os.path.join(dir_info["full_path"], info[0]["name"])
                cls.__get_dir_size(info)
                info = info[0]
                dir_info["dir_num"] += info["dir_num"]
                dir_info["file_num"] += info["file_num"]
                dir_info["total_asize"] += info["total_asize"]
                dir_info["total_dsize"] += info["total_dsize"]
            else:
                info["full_path"] = os.path.join(dir_info["full_path"], info["name"])
                if info.get("excluded") == "pattern":
                    info["excluded"] = True
                    info["type"] = int(os.path.isdir(info["full_path"]))
                    if info["type"] == 1:  # 排除目录
                        # info["files"] = 0
                        # info["dirs"] = 0
                        info["file_num"] = 0
                        info["dir_num"] = 0
                else:
                    info["excluded"] = False
                    info["type"] = 0
                    # info["files"] = -1
                    # info["dirs"] = -1
                    info["file_num"] = -1
                    info["dir_num"] = -1

                # dir_info["files"] += 1
                dir_info["file_num"] += 1
                info["total_asize"] = info.get("asize", 0)
                info["total_dsize"] = info.get("dsize", 0)
                dir_info["total_asize"] += info["total_asize"]
                dir_info["total_dsize"] += info["total_dsize"]
            dir_info["list"].append(info)

    # 过滤所有文件
    def filter_file(self, get):
        if not hasattr(get, "scan_id"):
            return public.returnMsg(False, "Missing parameters! scan_id")

        scan_id = get.scan_id

        sub_path = getattr(get, "sub_path", None)
        file_name = getattr(get, "file_name", None)
        exts = getattr(get, "exts", "")
        filter_size = getattr(get, "filter_size", "")
        is_exts_exclude = getattr(get, "is_exts_exclude", "true")
        sort = getattr(get, "sort", "total_asize")
        reverse = getattr(get, "reverse", "true")
        total_num = getattr(get, "total_num", self.__get_scan_config("file_show", "total_num"))

        if not sort: sort = "total_asize"
        if not is_exts_exclude: is_exts_exclude = "true"
        if not reverse: reverse = "true"
        is_exts_exclude = is_exts_exclude == "true"
        reverse = reverse == "true"
        sub_path = sub_path.replace("//", "/").rstrip("/")

        from BTPanel import session, cache

        cache_key = "{}_{}_{}_{}_{}_{}_{}_{}_{}".format(scan_id, sub_path, file_name, exts, filter_size, is_exts_exclude, sort, reverse, total_num)
        cache_data = cache.get(cache_key)
        if cache_data is not None:
            for info in cache_data["list"]:
                self.__get_stat(info)
            cache_data["list"].sort(key=lambda data: (data["status"], data[sort]), reverse=reverse)
            if reverse is False:
                cache_data["list"].sort(key=lambda data: (data["status"]), reverse=True)
            cache.set(cache_key, cache_data, 60 * 60 * 24)
            return {"status": True, "msg": "ok", "data": cache_data}

        scan_data_file = os.path.join(self._SCAN_DATA_DIR, scan_id, "scan")
        if not os.path.exists(scan_data_file):
            return public.returnMsg(False, "Scan result does not exist.")

        data = public.readFile(scan_data_file)
        data = json.loads(data)

        ext_list = [ext for ext in str(exts).split(",") if ext]
        scan_result = {}
        for info in data:
            if not isinstance(info, list): continue
            full_path = info[0]["name"]
            if sub_path and sub_path != full_path:
                info = self.__get_sub_path_data(info[1:], full_path, sub_path)
                if info is None: continue
                info[0]["full_path"] = sub_path
            else:
                info[0]["full_path"] = full_path

            scan_result = self.__analysis_filter_data(info, file_name, ext_list, filter_size, is_exts_exclude, int(total_num), sort, reverse)

        for info in scan_result["list"]:
            self.__get_stat(info)
        scan_result["list"].sort(key=lambda data: (data["status"], data[sort]), reverse=reverse)
        if reverse is False:
            scan_result["list"].sort(key=lambda data: (data["status"]), reverse=True)

        scan_result["scan_time"] = self.__get_scan_log(scan_id).get("scan_time")
        cache.set(cache_key, scan_result, 60 * 60 * 24)
        return {"status": True, "msg": "ok", "data": scan_result}

    # 获取子目录数据
    @classmethod
    def __get_sub_path_data(cls, scan_result: dict, root_path: str, sub_path: str) -> Union[list, None]:
        for info in scan_result:
            if not isinstance(info, list): continue
            full_path = os.path.join(root_path, info[0]["name"])
            if full_path == sub_path:
                return info
            elif len(info) > 1:
                info = cls.__get_sub_path_data(info[1:], full_path, sub_path)
                if info is not None:
                    return info
        return None

    # 过滤指定路径下所有文件
    @classmethod
    def __analysis_filter_data(cls, analysis_data: list, file_name: Union[str, None], ext_list: list, filter_size: str, is_exts_exclude: bool, total_num: int, sort: str, reverse: bool) -> dict:
        """
        过滤指定路径下所有文件
        @param analysis_data: 扫描结果信息
        @param file_name: 过滤文件名
        @param ext_list: 过滤文件后缀
        @param is_exts_exclude: 查看/排除 文件后缀
        @param total_num: 过滤文件数量
        @param sort: 排序字段
        @param reverse: 是否降序
        @return: dict
        """
        scan_result = analysis_data[0]
        scan_result["type"] = 1
        scan_result["asize"] = scan_result.get("asize", 0)
        scan_result["dsize"] = scan_result.get("dsize", 0)
        scan_result["dirs"] = 0
        scan_result["files"] = 0
        scan_result["dir_num"] = 0
        scan_result["file_num"] = 0
        scan_result["total_asize"] = scan_result.get("asize", 0)
        scan_result["total_dsize"] = scan_result.get("dsize", 0)
        cls.__get_stat(scan_result)
        scan_result["list"] = []

        for info in analysis_data[1:]:
            if isinstance(info, list):  # 目录
                info[0]["full_path"] = os.path.join(scan_result["full_path"], info[0]["name"])
                cls.__filter_file_data(info, file_name, ext_list, filter_size, is_exts_exclude, total_num, sort, reverse, scan_result)
            else:
                if file_name and file_name not in info["name"]:
                    continue
                if info.get("excluded") == "pattern": continue

                info["full_path"] = os.path.join(scan_result["full_path"], info["name"])
                info["status"] = int(os.path.exists(info["full_path"]))
                info["type"] = 0
                if info.get("asize") is None: info["asize"] = 0
                if info.get("dsize") is None: info["dsize"] = 0
                info["total_asize"] = info["asize"]
                info["total_dsize"] = info["dsize"]
                scan_result["total_asize"] += info["total_asize"]
                scan_result["total_dsize"] += info["total_dsize"]

                if filter_size:
                    gt_lt = filter_size[0]
                    size = int(filter_size[1:])
                    if (gt_lt == ">" and info["total_asize"] < size) or (gt_lt == "<" and info["total_asize"] > size):
                        continue

                if ext_list:
                    file_ext = None
                    if info["name"].find(".") != -1:
                        file_ext = str(info["name"]).split(".")[-1]
                    is_true = False
                    for ext in ext_list:
                        if file_ext == ext:
                            is_true = True
                            break
                    if is_true != is_exts_exclude:
                        continue

                scan_result["list"].append(info)
                scan_result["list"].sort(key=lambda data: (data[sort]), reverse=reverse)
                if len(scan_result["list"]) > total_num:
                    del scan_result["list"][-1]

        return scan_result

    # 过滤文件
    @classmethod
    def __filter_file_data(cls, analysis_data: list, file_name: Union[str, None], ext_list: list, filter_size: str, is_exts_exclude: bool, total_num: int, sort: str, reverse: bool, scan_result: dict) -> None:
        """
        过滤文件
        @param analysis_data: 扫描结果信息
        @param file_name: 过滤文件名
        @param ext_list: 过滤文件后缀
        @param is_exts_exclude: 查看/排除 文件后缀
        @param total_num: 过滤文件数量
        @param sort: 排序字段
        @param reverse: 是否降序
        @param scan_result: 过滤路径信息
        @return:
        """
        full_path = analysis_data[0]["full_path"]
        for info in analysis_data[1:]:
            if isinstance(info, list):  # 目录
                info[0]["full_path"] = os.path.join(full_path, info[0]["name"])
                cls.__filter_file_data(info, file_name, ext_list, filter_size, is_exts_exclude, total_num, sort, reverse, scan_result)
            else:
                if file_name and file_name not in info["name"]:
                    continue
                if info.get("excluded") == "pattern": continue

                info["full_path"] = os.path.join(full_path, info["name"])
                info["status"] = int(os.path.exists(info["full_path"]))
                info["type"] = 0
                if info.get("asize") is None: info["asize"] = 0
                if info.get("dsize") is None: info["dsize"] = 0
                info["total_asize"] = info["asize"]
                info["total_dsize"] = info["dsize"]
                scan_result["total_asize"] += info["total_asize"]
                scan_result["total_dsize"] += info["total_dsize"]

                if filter_size:
                    gt_lt = filter_size[0]
                    size = int(filter_size[1:])
                    if (gt_lt == ">" and info["total_asize"] < size) or (gt_lt == "<" and info["total_asize"] > size):
                        continue

                if ext_list:
                    file_ext = None
                    if info["name"].find(".") != -1:
                        file_ext = str(info["name"]).split(".")[-1]
                    is_true = False
                    for ext in ext_list:
                        if file_ext == ext:
                            is_true = True
                            break
                    if is_true != is_exts_exclude:
                        continue

                scan_result["list"].append(info)
                scan_result["list"].sort(key=lambda data: (data[sort]), reverse=reverse)
                if len(scan_result["list"]) > total_num:
                    del scan_result["list"][-1]

    # 2024/1/10 下午 3:16 返回支持扫描的垃圾分类
    def get_scan_type(self, get):
        """
        返回支持扫描的垃圾分类
        @param get:
        @return:
        """
        return [
            {
                "type": "panel",
                "title": "aaPanel file cleanup",
                "desc": "aaPanel junk includes website logs, monitoring report logs, WAF logs, load balancing logs, file synchronization logs, etc.",
                "status": True
            },
            {
                "type": "system",
                "title": "System junk cleaning",
                "desc": "System junk includes system cache, log files, temporary files, system user recycle bin, package manager cache, etc.",
                "status": False
            },
            {
                "type": "other",
                "title": "Other junk cleaning",
                "desc": "Other junk",
                "status": False
            },
        ]

    # 2024/1/10 下午 3:26 获取支持扫描的垃圾文件
    def get_scan_ext(self):
        """
        获取支持扫描的垃圾文件
        @return:
        """
        return {
            "panel": {
                "web_log": {
                    "name": "Website log",
                    "path": ["/www/wwwlogs"],  # 支持扫描的路劲
                    "ext": [".log", "error_log", "access_log"],  # 需要扫描的文件后缀
                    "exclude_ext": [],  # 排除的扩展名
                    "exclude_prefix": [],
                    "status": True
                },
                "total_log": {
                    "name": "Website statistics log",
                    "path": ["/www/server/total/logs"],  # 支持扫描的路劲
                    "ext": [".db"],  # 需要扫描的文件后缀
                    "exclude_ext": [],  # 排除的扩展名
                    "exclude_prefix": [],
                    "status": True
                },
                "waf_log": {
                    "name": "waf log",
                    "path": ["/www/server/btwaf/totla_db", "/www/wwwlogs/btwaf", "/www/server/btwaf/drop_ip.log",
                             "/www/server/btwaf/total.json"],  # 支持扫描的路劲
                    "ext": [],  # 需要扫描的文件后缀
                    "exclude_ext": [],  # 排除的扩展名
                    "exclude_prefix": [],
                    "status": True
                },
                "load_balance_log": {
                    "name": "load_balance log",
                    "path": ["/www/wwwlogs/load_balancing"],  # 支持扫描的路劲
                    "ext": [],  # 需要扫描的文件后缀
                    "exclude_ext": [],  # 排除的扩展名
                    "exclude_prefix": [],
                    "status": True
                },
                "rsync_log": {
                    "name": "file rsync log",
                    "path": ["/www/server/bt_sync/logs", "/www/server/bt_sync/run_logs.log",
                             "/www/server/bt_sync/exec_logs.log"],  # 支持扫描的路劲
                    "ext": [],  # 需要扫描的文件后缀
                    "exclude_ext": [],  # 排除的扩展名
                    "exclude_prefix": [],  # 排除的前缀
                    "status": True
                },
                "tamper_proof_log": {
                    "name": "网站防篡改日志",
                    "path": ["/www/server/panel/plugin/tamper_proof/service.log"],  # 支持扫描的路劲
                    "ext": [],  # 需要扫描的文件后缀
                    "exclude_ext": [],  # 排除的扩展名
                    "exclude_prefix": [],  # 排除的前缀
                    "status": True
                },
                "tamp_core_log": {
                    "name": "Website tamper-proof log",
                    "path": ["/www/server/panel/plugin/tamper_core/logs"],  # 支持扫描的路劲
                    "ext": [],  # 需要扫描的文件后缀
                    "exclude_ext": [],  # 排除的扩展名
                    "exclude_prefix": [],  # 排除的前缀
                    "status": True
                },
                "fail2ban_log": {
                    "name": "fail2ban log",
                    "path": ["/var/log/fail2ban.log"],  # 支持扫描的路劲
                    "ext": [],  # 需要扫描的文件后缀
                    "exclude_ext": [],  # 排除的扩展名
                    "exclude_prefix": [],  # 排除的前缀
                    "status": True
                },
                "docker_log": {
                    "name": "Docker log",
                    "path": ["/var/lib/docker/containers"],  # 支持扫描的路劲
                    "ext": [".log"],  # 需要扫描的文件后缀
                    "exclude_ext": [],  # 排除的扩展名
                    "exclude_prefix": [],  # 排除的前缀
                    "status": True
                },
                "pm2_log": {
                    "name": "PM2 log",
                    "path": ["/root/.pm2/logs"],  # 支持扫描的路劲
                    "ext": [".log"],  # 需要扫描的文件后缀
                    "exclude_ext": [],  # 排除的扩展名
                    "exclude_prefix": [],  # 排除的前缀
                    "status": True
                },
                "node_log": {
                    "name": "Node log",
                    "path": ["/root/.node-gyp"],  # 支持扫描的路劲
                    "ext": [".log"],  # 需要扫描的文件后缀
                    "exclude_ext": [],  # 排除的扩展名
                    "exclude_prefix": [],  # 排除的前缀
                    "status": True
                },
                "recycle_bin_log": {
                    "name": "aaPanel recycle bin log",
                    "path": ["/.Recycle_bin", "/www/.Recycle_bin"],  # 支持扫描的路劲
                    "ext": [],  # 需要扫描的文件后缀
                    "exclude_ext": [],  # 排除的扩展名
                    "exclude_prefix": [],  # 排除的前缀
                    "status": True
                },
                "panel_install_log": {
                    "name": "aaPanel installation log",
                    "path": ["/www/server/panel/logs/installed"],  # 支持扫描的路劲
                    "ext": [".log"],  # 需要扫描的文件后缀
                    "exclude_ext": [],  # 排除的扩展名
                    "exclude_prefix": [],  # 排除的前缀
                    "status": True
                },
                "panel_cron_log": {
                    "name": "aaPanel scheduled task log",
                    "path": ["/www/server/cron"],  # 支持扫描的路劲
                    "ext": [".log"],  # 需要扫描的文件后缀
                    "exclude_ext": [],  # 排除的扩展名
                    "exclude_prefix": [],  # 排除的前缀
                    "status": True
                },
            },
            "system": {
                "cache": {
                    "name": "User cache",
                    "path": ["/root/.cache"],  # 支持扫描的路劲
                    "ext": [],  # 需要扫描的文件后缀
                    "exclude_ext": [],  # 排除的扩展名
                    "exclude_prefix": [],
                    "status": False
                },
                "log": {
                    "name": "log file",
                    "path": ["/var/log", "/var/spool"],  # 支持扫描的路劲
                    "ext": [],  # 需要扫描的文件后缀
                    "exclude_ext": [],  # 排除的扩展名
                    "exclude_prefix": [],
                    "status": False
                },
                "tmp": {
                    "name": "Temporary Files",
                    "path": ["/tmp", "/var/tmp"],  # 支持扫描的路劲
                    "ext": [],  # 需要扫描的文件后缀
                    "exclude_ext": [".pid", ".sock", ".lock", ".swp"],  # 排除的扩展名
                    "exclude_prefix": ["sess_", "systemd-private", "systemd-resolved", "systemd-timesyncd",
                                       "systemd-networkd", "systemd-logind", "systemd-journald", "systemd-udevd",
                                       "systemd-coredump", "systemd-hostnamed"],  # 排除的前缀
                    "status": False
                },
                "trash": {
                    "name": "System user recycle bin",
                    "path": ["/root/.local/share/Trash", "/root/.Trash"],  # 支持扫描的路劲
                    "ext": [],  # 需要扫描的文件后缀
                    "exclude_ext": [],  # 排除的扩展名
                    "exclude_prefix": [],
                    "status": False
                },
                "package_cache": {
                    "name": "Package manager cache",
                    "path": ["/var/cache/apt/archives", "/var/cache/yum"],  # 支持扫描的路劲
                    "ext": [],  # 需要扫描的文件后缀
                    "exclude_ext": [],  # 排除的扩展名
                    "exclude_prefix": [],
                    "status": False
                },
            },
            "other": {
                "cron_log": {
                    "name": "System scheduled task log",
                    "path": ["/var/spool/cron", "/var/spool/cron/crontabs"],  # 支持扫描的路劲
                    "ext": [".log"],  # 需要扫描的文件后缀
                    "exclude_ext": [".pid", ".sock", ".lock", ".swp"],  # 排除的扩展名
                    "exclude_prefix": ["sess_", "systemd-private", "systemd-resolved", "systemd-timesyncd",
                                       "systemd-networkd", "systemd-logind", "systemd-journald", "systemd-udevd",
                                       "systemd-coredump", "systemd-hostnamed"],  # 排除的前缀
                    "status": False
                },
            },
        }

    def __get_scan_ext(self, scan_ext_tmp: dict, junk_types: list) -> tuple:
        """
        根据用户选择的垃圾类型获取支持扫描的配置
        @param scan_ext_tmp: 扫描配置
        @param junk_types: 用户选择的垃圾类型
        @return: tuple
        """
        scan_ext = {}
        scan_dir_num = 0
        for junk_type in junk_types:
            if junk_type not in scan_ext_tmp: continue
            scan_ext[junk_type] = scan_ext_tmp[junk_type]
            scan_dir_num += len(scan_ext_tmp[junk_type])
        return scan_ext, scan_dir_num

    # 2024/1/10 下午 2:35 扫描指定目录，websocket接口
    def scan_dir(self, get):
        """
        扫描指定目录，websocket接口
        @param get:
        @return:
        """
        if not hasattr(get, "_ws"):
            return public.returnMsg(False, "Missing parameters! _ws object")

        if not hasattr(get, "junk_types"):
            return public.returnMsg(False, "Missing parameters! junk_types")
        junk_types = get.junk_types

        # 2024/1/10 下午 11:04 检查磁盘空间,如果空间不足(低于50MB)则停止扫描
        resp = self.__check_disk()
        if isinstance(resp, str):
            return public.returnMsg(False, resp)

        # 2024/1/10 下午 4:29 根据用户选择的垃圾类型获取支持扫描的配置,计数junk_types中的扫描目录数量,用做进度条百分比
        scan_ext, scan_dir_num = self.__get_scan_ext(self.get_scan_ext(), junk_types)
        scanned_num = 0
        clean_name = None

        public.set_module_logs('disk_analysis', 'scan_dir', 1)

        # 2024/1/10 下午 11:03 扫描指定目录并通过websocket返回扫描结果
        try:
            for junk_type in scan_ext:
                for key in scan_ext[junk_type]:
                    scanned_num += 1
                    for path in scan_ext[junk_type][key]["path"]:
                        if not os.path.exists(path): continue

                        scan_id = str(int(time.time() * 1000_000))
                        while self.__exist_scan_log(scan_id):
                            scan_id = str(int(time.time() * 1000_000))

                        result_dir = os.path.join(self._SCAN_DATA_DIR, scan_id)
                        if not os.path.exists(result_dir):
                            os.makedirs(result_dir)
                        scan_result_file = os.path.join(result_dir, "junk_scan")

                        scan_result = {}
                        # 2024/1/15 下午 3:16 处理扫描文件
                        if not os.path.isdir(path):
                            # 2024/1/16 下午 2:17 如果文件开头在scan_ext[junk_type][key]["exclude_prefix"]里面，就跳过
                            if scan_ext[junk_type][key]["exclude_prefix"]:
                                if os.path.basename(path).startswith(tuple(scan_ext[junk_type][key]["exclude_prefix"])):
                                    continue

                            # 2024/1/16 下午 2:17 如果文件后缀在scan_ext[junk_type][key]["exclude_ext"]里面，就跳过
                            if scan_ext[junk_type][key]["exclude_ext"]:
                                if path.endswith(tuple(scan_ext[junk_type][key]["exclude_ext"])):
                                    continue

                            # 2024/1/17 下午 2:19 如果文件后缀在scan_ext[junk_type][key]["ext"]里面，就扫描
                            if scan_ext[junk_type][key]["ext"]:
                                if not path.endswith(tuple(scan_ext[junk_type][key]["ext"])):
                                    continue

                            scan_result_json = [{
                                "name": "{}".format(path),
                                "full_path": "{}".format(path),
                                "asize": os.path.getsize(path),
                                "dsize": os.path.getsize(path),
                            }]
                            scan_result = self.__analysis_scan_result(scan_result_json)
                            public.writeFile(scan_result_file, json.dumps(scan_result_json))

                        # 2024/1/15 下午 3:16 处理扫描目录
                        else:
                            exclude_path = scan_ext[junk_type][key]["exclude_ext"]
                            exclude_path_list = ["--exclude '{}'".format(os.path.join(path, url)) for url in
                                                 exclude_path]

                            exec_shell = "'{}' '{}' -o '{}' {} ".format(
                                self.__NCDU_BIN, path, scan_result_file,
                                " ".join(exclude_path_list)).replace("\\", "/").replace("//", "/")

                            result = public.ExecShell(exec_shell)[1]

                            if result.find("Permission denied") != -1:  # 无权限授权
                                public.ExecShell("chmod +x /usr/bin/ncdu")
                                result = public.ExecShell(exec_shell)[1]
                            if result.find("ncdu: command not found") != -1:  # 连接不存在
                                public.ExecShell(
                                    "ln -s /www/server/panel/plugin/disk_analysis/ncdu /usr/bin/ncdu && chmod +x /usr/bin/ncdu")
                                public.ExecShell(exec_shell)[1]

                            data = json.loads(public.readFile(scan_result_file))
                            # 2024/1/10 下午 11:21 scan_dir_num是总共要扫描的数量,在scan_result增加一个key,用来记录当前扫描完成的百分比
                            for info in data:
                                if not isinstance(info, list): continue
                                full_path = info[0]["name"]
                                info[0]["full_path"] = full_path
                                scan_result = self.__analysis_scan_result(info)

                        public.writeFile(scan_result_file, json.dumps(scan_result))

                        # 2024/1/17 下午 2:19 只返回scan_ext[junk_type][key]["ext"]里面的结果
                        if len(scan_ext[junk_type][key]["ext"]) > 0:
                            if scan_result["type"] == 1 and len(scan_result["list"]) != 0:
                                scan_result["total_asize"] = 0
                                for info in scan_result["list"]:
                                    if info["type"] == 0:
                                        scan_result["total_asize"] += info["total_asize"]
                                        continue
                                    if len(info["list"]) == 0:
                                        scan_result["total_asize"] += info["total_asize"]
                                        continue

                                    copy_list = []
                                    info["total_asize"] = 0
                                    for info2 in info["list"]:
                                        if info2["full_path"].endswith(tuple(scan_ext[junk_type][key]["ext"])):
                                            copy_list.append(info2)
                                            info["total_asize"] += info2["total_asize"]

                                    info["list"] = copy_list
                                    scan_result["total_asize"] += info["total_asize"]

                        scan_result["percentage"] = int(round(scanned_num / scan_dir_num * 100, 2))
                        scan_result["status"] = scan_ext[junk_type][key]["status"]
                        scan_result["parent_type"] = junk_type

                        # 2024/1/17 下午 4:19 处理扫描结果的名称，有重复的名称则在名称后面加上序号
                        if clean_name is None:
                            clean_name = scan_ext[junk_type][key]["name"]
                            scan_result["clean_name"] = scan_ext[junk_type][key]["name"]
                        else:
                            if scan_ext[junk_type][key]["name"] == clean_name:
                                scan_result["clean_name"] = scan_ext[junk_type][key]["name"] + "other related directories_" + str(
                                    scanned_num)
                            else:
                                clean_name = scan_ext[junk_type][key]["name"]
                                scan_result["clean_name"] = scan_ext[junk_type][key]["name"]

                        get._ws.send(public.getJson(scan_result))

        except Exception as e:
            print(traceback.format_exc())
            return public.returnMsg(False, str(e))
        return True

    # 2024/1/15 上午 9:03 根据用户传入的文件或目录进行清理，如果目录下文件命是.log结尾的则置空
    def clean_file(self, get):
        """
        根据用户传入的文件或目录进行清理，如果目录下文件命是.log结尾的则置空
        @param get:
        @return:
        """
        if not hasattr(get, "_ws"):
            return public.returnMsg(False, "Missing parameters! _ws object")

        if not hasattr(get, "clean_files"):
            return public.returnMsg(False, "Missing parameters! clean_files")

        clean_files = get.clean_files
        clean_dir_num = 0
        cleaned_num = 0
        junk_types = []
        for c_files in clean_files:
            junk_types.append(c_files["type"])
            clean_dir_num += len(c_files["paths"])

        scan_ext, _ = self.__get_scan_ext(self.get_scan_ext(), junk_types)

        public.set_module_logs('disk_analysis', 'clean_file', 1)

        for c_files in clean_files:
            c_files["size"] = 0
            paths = c_files["paths"]

            # 2024/1/15 上午 9:06 遍历path目录下的所有文件，如果文件名是.log结尾的则置空，如果是Other files或者目录则直接删除
            for path in paths:
                time.sleep(0.1)

                # 2024/1/15 下午 2:15 获取文件或目录大小，然后更新到clean_files中
                if os.path.isfile(path):
                    c_files["size"] += os.path.getsize(path)

                prefix_result = {
                    "percentage": int(round(cleaned_num / clean_dir_num * 100, 2)),
                    "status": False,
                    "msg": None,
                }
                if prefix_result["percentage"] >= 100:
                    prefix_result["percentage"] = 99

                if not os.path.exists(path):
                    prefix_result["msg"] = "[{}] does not exist".format(path)
                    get._ws.send(public.getJson(prefix_result))
                    continue

                if not os.access(path, os.W_OK):
                    prefix_result["msg"] = "[{}] No permission".format(path)
                    get._ws.send(public.getJson(prefix_result))
                    continue

                if path in ["/.Recycle_bin", "/www/.Recycle_bin"]:
                    public.ExecShell("rm -rf {}/*".format(path))
                    prefix_result["status"] = True
                    prefix_result["msg"] = "[{}] has been cleared!".format(path)
                    get._ws.send(public.getJson(prefix_result))
                    continue

                # 2024/1/15 上午 10:56 如果path是文件则直接置空或删除
                if os.path.isfile(path):
                    prefix_result["status"] = True
                    if path.endswith(".log"):
                        public.writeFile(path, "")
                        prefix_result["msg"] = "[{}] has been set blank!".format(path)
                        get._ws.send(public.getJson(prefix_result))
                    else:
                        os.remove(path)
                        prefix_result["msg"] = "[{}] deleted!".format(path)
                        get._ws.send(public.getJson(prefix_result))
                    continue

                for root, dirs, files in os.walk(path):
                    clean_result = {
                        "percentage": int(round(cleaned_num / clean_dir_num * 100, 2)),
                        "status": True
                    }
                    if clean_result["percentage"] >= 100:
                        clean_result["percentage"] = 99

                    for file in files:
                        is_continue = False

                        for key in scan_ext[c_files["type"]]:
                            if path in scan_ext[c_files["type"]][key]["path"]:
                                if file.endswith(tuple(scan_ext[c_files["type"]][key]["exclude_ext"])):
                                    is_continue = True
                                    break

                                if file.startswith(tuple(scan_ext[c_files["type"]][key]["exclude_prefix"])):
                                    is_continue = True
                                    break

                                if len(scan_ext[c_files["type"]][key]["ext"]) > 0:
                                    if not file.endswith(tuple(scan_ext[c_files["type"]][key]["ext"])):
                                        is_continue = True
                                        break

                        if is_continue: continue

                        # 2024/1/15 下午 2:15 获取文件或目录大小，然后更新到clean_files中
                        c_files["size"] += os.path.getsize(os.path.join(root, file))

                        if file.endswith(".log") or path in ["/var/log", "/var/spool"] and not file.endswith(
                                (".gz", ".1")):
                            file_path = os.path.join(root, file)
                            public.writeFile(file_path, "")
                            clean_result["msg"] = "[{}] has been set blank!".format(os.path.join(root, file))
                            get._ws.send(public.getJson(clean_result))
                        else:
                            os.remove(os.path.join(root, file))
                            clean_result["msg"] = "[{}] deleted!".format(os.path.join(root, file))
                            get._ws.send(public.getJson(clean_result))

                cleaned_num += 1

        # 2024/1/15 下午 2:17 更新clean_files中的size，并写到文件中
        public.writeFile("{}/clean_files.json".format(self._SCAN_DATA_DIR), json.dumps(clean_files))

        get._ws.send(public.getJson({
            "percentage": 100,
            "status": True,
            "result": True,
            "msg": "Cleanup completed!",
        }))

    # 2024/1/15 下午 2:17 获取清理结果
    def get_clean_result(self, get):
        """
        获取清理结果
        @param get:
        @return:
        """
        try:
            clean_files_body = json.loads(public.readFile("{}/clean_files.json".format(self._SCAN_DATA_DIR)))
            scan_type = self.get_scan_type(get)
            for clean_file in clean_files_body:
                for type in scan_type:
                    if type["type"] == clean_file["type"]:
                        clean_file["title"] = type["title"]
                        clean_file["desc"] = type["desc"]
                        break
            return clean_files_body
        except:
            print(traceback.format_exc())
            return []
