#!/bin/bash
PATH=/www/server/panel/pyenv/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
install_tmp='/tmp/bt_install.pl'

pluginPath=/www/server/panel/plugin/score
rm -f $pluginPath/*cpython-36m*.so
rm -f $pluginPath/*cpython-37m*.so
rm -f $pluginPath/*_main.so

download_Url=https://node.aapanel.com

Install_score()
{

  
	echo 'Installing script file...' > $install_tmp
	gcc /www/server/panel/plugin/score/testcpu.c -o /www/server/panel/plugin/score/testcpu -lpthread
	echo 'The installation is complete' > $install_tmp
}

Uninstall_score()
{
	rm -rf /www/server/panel/plugin/score
	echo 'Uninstall completed' > $install_tmp
}


action=$1
if [ "${1}" == 'install' ];then
	Install_score
else
	Uninstall_score
fi
