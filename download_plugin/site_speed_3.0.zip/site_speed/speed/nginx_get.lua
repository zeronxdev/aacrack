if get_cache == nil then
    dofile('/www/server/speed/speed.lua')
end
get_cache()