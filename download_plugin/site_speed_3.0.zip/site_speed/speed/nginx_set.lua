if set_cache == nil then
    dofile('/www/server/speed/speed.lua')
end
set_cache()