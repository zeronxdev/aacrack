1.9
1.Optimize switching nodejs switching version error reminder

2.1
1.Displays incompatible versions of the current system, but gives an incompatibility prompt