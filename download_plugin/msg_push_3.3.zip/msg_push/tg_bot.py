# coding: utf-8
# +-------------------------------------------------------------------
# | aaPanel
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 aaPanel(www.aapanel.com) All rights reserved.
# +-------------------------------------------------------------------
# | Author: zhw <zhw@bt.com>
# +-------------------------------------------------------------------
import sys
import time
import psutil

sys.path.append('/www/server/panel/class')
import public
import panel_telegram_bot
from telegram.ext import Updater


class tg_bot:

    def __init__(self):
        self.ip = public.GetLocalIp()

    def start(self, update, context):
        print(update.effective_chat.id)
        context.bot.send_message(chat_id=update.effective_chat.id, text="The robot has been turned on")

    # def push_msg(self, update, context, txt=None):
    #     context.bot.send_message(chat_id=update.effective_chat.id, text=txt)

    def help(self, update, context):
        context.bot.send_message(chat_id=update.effective_chat.id, text=self.get_help(), parse_mode="Markdown")

    def cpu(self, update, context):
        context.bot.send_message(chat_id=update.effective_chat.id, text=self.get_cpu(), parse_mode="Markdown")

    def ram(self, update, context):
        context.bot.send_message(chat_id=update.effective_chat.id, text=self.get_ram(), parse_mode="Markdown")

    def disk(self, update, context):
        context.bot.send_message(chat_id=update.effective_chat.id, text=self.get_disk(), parse_mode="Markdown")

    def get_help(self):
        txt = """
/cpu 获取服务器的CPU使用率
/ram 获取服务器的内存使用率
/disk 获取服务器的磁盘挂载信息
"""
        return txt

    def get_ram(self):
        phymen = psutil.virtual_memory()
        # line = "RAM: {} {}M {}M".format(phymen.percent, phymen.used / 1024 / 1024, phymen.total / 1024 / 1024)
        txt = """
*Server*: {}
*Ram Total*: {}M
*Ram Used*: {}M
*Ram utilization*: {}%
""".format(self.ip, int(phymen.total / 1024 / 1024),int(phymen.used / 1024 / 1024), int(phymen.percent))
        return txt
    def get_cpu(self):
        txt="""
*Server*: {}
*CPU logical count*: {}
*CPU utilization*: {}%
""".format(self.ip,int(psutil.cpu_count()),int(psutil.cpu_percent()))
        return txt

    def get_disk(self):
        txt = """
*Server*: {}
*Disk info*:
{}
""".format(self.ip, public.ExecShell("df -h")[0])
        return txt

    # def replace_character(self,data):
    #     character = ['.', ',', '!', ':', '%', '[', ']', '\/', '_', '-']
    #     for c in character:
    #         data = data.replace(c,'\\'+c)
    #     return data


    def start_program(self):
        from telegram.ext import CommandHandler
        token = ''
        while not token:
            token = panel_telegram_bot.panel_telegram_bot().get_tg_conf()['bot_token']
            if not token:
                time.sleep(60)
        updater = Updater(token=token, use_context=True)
        dispatcher = updater.dispatcher
        d = {'start': self.start, 'help': self.help, 'ram': self.ram, 'cpu': self.cpu,'disk':self.disk}
        for i in d:
            start_handler = CommandHandler(i, d[i])
            dispatcher.add_handler(start_handler)
        updater.start_polling()
