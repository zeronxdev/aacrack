#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
pluginPath=/www/server/panel/plugin/msg_push
rm -f $pluginPath/*cpython-36m*.so
rm -f $pluginPath/*cpython-37m*.so
rm -f $pluginPath/*.so
#public_file=/www/server/panel/install/public.sh
#if [ ! -f $public_file ];then
#	wget -O $public_file https://node.aapanel.com/install/public.sh --no-check-certificate -T 5;
#fi
#. $public_file
#download_Url=$NODE_URL

Install_MsgPush()
{
    id=`ps aux|grep "/www/server/panel/plugin/msg_push"|grep -v "grep"|awk '{print $2}'`
    if [ "$id" ];then
	    kill -9 $id
	fi
	btpip install python-telegram-bot
	# btpip install telegram
	mkdir -p $pluginPath
#	echo > /www/server/panel/plugin/msg_push/msg_push_main.py
#	wget -O /www/server/panel/plugin/msg_push/msg_push.zip $download_Url/install/plugin/msg_push_en/msg_push.zip --no-check-certificate -T 5
#	cd $pluginPath
#	unzip msg_push.zip
#	rm -f msg_push.zip
	\cp -a -r /www/server/panel/plugin/msg_push/icon.png /www/server/panel/BTPanel/static/img/soft_ico/ico-msg_push.png
	nohup /usr/bin/python /www/server/panel/plugin/msg_push/main &
	/usr/bin/echo '1' > /www/server/panel/plugin/msg_push/open.txt
	echo 'Successify'
	echo > /www/server/panel/data/restart.pl
}

Uninstall_MsgPush()
{
	rm -rf $pluginPath
	id=`ps aux|grep msg_push|grep -v "grep"|awk '{print $2}'`
	kill -9 $id
	/usr/bin/systemctl restart crond
	echo 'Successify'
}

if [ "${1}" == 'install' ];then
	Install_MsgPush
elif [ "${1}" == 'uninstall' ];then
	Uninstall_MsgPush
fi
