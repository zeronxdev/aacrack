#!/bin/bash
KV=$(uname -r)
KO_NAME="tampercore"
TAMPER_PATH=/www/server/tamper
BACKUP_PATH=${TAMPER_PATH}/backup/$KV
K_NAME=${KO_NAME}_${KV}_amd64


src_ko_file=${TAMPER_PATH}/tampercore.ko
dst_ko_file="${BACKUP_PATH}/${K_NAME}.ko"
dst_sign_file="${BACKUP_PATH}/${K_NAME}.sign"

# 创建备份目录
if [ ! -d $BACKUP_PATH ];then
    mkdir -p $BACKUP_PATH
fi

# 复制文件
\cp -f $src_ko_file $dst_ko_file
# 计算sha256
sha256sum $dst_ko_file | awk '{print $1}' > $dst_sign_file


# 压缩
cd $TAMPER_PATH/backup
tar zcvf ${KV}.tar.gz $KV

# 清理
rm -rf $BACKUP_PATH
