# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: hwliang<hwl@bt.cn>
# +-------------------------------------------------------------------

# +--------------------------------------------------------------------
# |   宝塔防篡改程序(驱动层) - 重构版
# +--------------------------------------------------------------------

import re
import os, sys, json, time, public, datetime, glob, shutil, copy


class tamper_core_main:
    __plugin_path = public.get_plugin_path('tamper_core')
    __tamper_path = "{}/tamper".format(public.get_setup_path())
    __tamper_user_bin = "{}/tamperuser".format(__tamper_path)
    __tamper_cli_bin = "{}/tamper-cli".format(__tamper_path)
    __tamper_cli_bash = "{}/cli.sh".format(__tamper_path)
    __init_file = "{}/init.sh".format(__plugin_path)
    __config_file = "{}/tamper.conf".format(__tamper_path)
    __config_ps_file = "{}/config_ps.json".format(__tamper_path)
    __tips_file = "{}/tips.pl".format(__tamper_path)
    __logs_path = "{}/logs".format(__tamper_path)
    __total_path = "{}/total".format(__tamper_path)
    __rule_group_file = '{}/rule.json'.format(__plugin_path)
    default_black_exts = [".java", ".php", ".html", ".tpl", ".js", ".css", ".jsp", ".do", ".shtml", ".htm", ".go",
                          ".json", ".conf"]
    default_white_dirs = ["runtime/", "cache/", "temp/", "tmp/", "threadcache/", "log/", "logs/", "caches/", "tmps/"]

    ##验证
    __session_name = 'tamper_core' + time.strftime('%Y-%m-%d')

    def __init__(self):
        spush_file = "{}/plugin/tamper_core/tamper_push.py".format(public.get_panel_path())
        dpush_file = "{}/class/push/tamper_push.py".format(public.get_panel_path())
        if not os.path.exists(dpush_file):
            shutil.copyfile(spush_file, dpush_file)
            os.chmod(dpush_file, mode=0o777)

    def rep_config(self):
        '''
            @name 修复配置文件
            @author hwliang
            @return void
        '''

        default_config = {
            "status": 1,
            "ltd": 1,
            "min_pid": 10,
            "is_create": 1,
            "is_modify": 1,
            "is_unlink": 1,
            "is_mkdir": 1,
            "is_rmdir": 1,
            "is_rename": 1,
            "is_chmod": 1,
            "is_chown": 1,
            "is_link": 1,
            "process_names": ["mysqld", "systemctl"],
            "uids": [],
            "gids": [],
            "default_black_exts": [".java", ".php", ".html", ".tpl", ".js", ".css", ".jsp", ".do", ".shtml", ".htm",
                                   ".go", ".json", ".conf"],
            "default_white_files": [],
            "default_white_dirs": ["runtime/", "cache/", "temp/", "tmp/", "threadcache/", "log/", "logs/", "caches/",
                                   "tmps/"],
            "paths": []
        }

        public.writeFile(self.__config_file, json.dumps(default_config, ensure_ascii=False, indent=4))

    def rep_config_ps(self, config):
        '''
            @name 修复配置文件
            @author hwliang
            @return void
        '''
        default_config = {
            "frequent_process": [
                {"name": "BT-Panel", "zh-cn": "aaPanel",
                 "ps": "After enabling this option, Can edit and save files using aaPanel"},
                {"name": "pure-ftpd", "zh-cn": "FTP",
                 "ps": "After enabling this option, Can upload files via FTP technology to update website files and content"},
                {"name": "sftp-server", "zh-cn": "SFTP",
                 "ps": "After enabling this option, Can upload files via SFTP technology to update website files and content"},
                # {"name": "systemctl","ps":"开启后，将允许systemctl命令修改系统服务的配置文件及日志"},
                # {"name": "cp","ps": "开启后，将允许cp命令复制文件到您的保护目录下"},
                # {"name": "vi","ps": "开启后，您可以通过vi命令修改文件(linux系统下的文本编辑器)"},
                # {"name": "vim","ps": "开启后，您可以通过vim命令修改文件(linux系统下的文本编辑器)"},
                # {"name": "mysqld","ps":"如果您的数据库文件在保护目录之内，请确保开启该项从而使数据库服务正常"},
                # {"name": "php-fpm","ps": "如果您的项目依赖PHP运行，您可以开启该项以保证PHP进程管理器正常工作"},
            ],
            "default_dir_ps": {
                "runtime/": {"ps": "ThinkPHP framework Cache and log folders",
                             "tip_msg": "After deleting the whitelist, the files in this directory will be protected, which may also affect the normal writing of the cache and log files of the website. want to continue?"},
                "cache/": {"ps": "Use save the cache information during the running of the website program",
                           "tip_msg": "After deleting the whitelist, the files in this directory will be protected, which may also affect the normal operation of the website on cached information.want to continue?"},
                "temp/": {"ps": "Used save temporary files generated during the running of website programs",
                          "tip_msg": "After deleting the whitelist, the files in this directory will be protected, which may also affect the operation of temporary files on the website. want to continue?"},
                "tmp/": {"ps": "This is usually the folder where temporary files are kept while the website is running",
                         "tip_msg": "After deleting the whitelist, the files in this directory will be protected, which may also affect the operation of temporary files on the website.  want to continue?"},
                "threadcache/": {
                    "ps": "Used save the cache information during the operation of the multi-threaded program of the website",
                    "tip_msg": "After deleting the whitelist, the files in this directory will be protected, which may also affect the normal operation of the website on cached information. want to continue?"},
                "log/": {"ps": "log folder of the website program running",
                         "tip_msg": "After deleting the whitelist, the files in this directory will be protected, which may also affect the normal writing of website log files. want to continue?"},
                "logs/": {"ps": "logs folder of the website program running",
                          "tip_msg": "After deleting the whitelist, the files in this directory will be protected, which may also affect the normal writing of website log files. want to continue?"},
                "caches/": {"ps": "Save the cache information during the running of the website program",
                            "tip_msg": "After deleting the whitelist, the files in this directory will be protected, which may also affect the normal operation of the website on cached information. want to continue?"},
                "tmps/": {"ps": "Used save temporary files generated during the running of website programs",
                          "tip_msg": "After deleting the whitelist, the files in this directory will be protected, which may also affect the operation of temporary files on the website. want to continue?"},
            }
        }
        default_frequent_process = (
        'BT-Panel', 'systemctl', 'pure-ftpd', 'sftp-server', 'cp', 'vi', 'vim', 'bash', 'mysqld', 'php-fpm')
        for i in config["process_names"]:
            if i not in default_frequent_process:
                default_config["frequent_process"].append({"name": i, "ps": i})
        for i in config["paths"]:
            default_config["dir_ps_" + str(i["pid"])] = {}

        public.writeFile(self.__config_ps_file, json.dumps(default_config, ensure_ascii=False, indent=4))

    def read_config_ps(self, config_dict):
        if not os.path.exists(self.__config_ps_file):
            self.rep_config_ps(config_dict)

        config_ps = public.readFile(self.__config_ps_file)
        if not config_ps:  # 配置文件为空？
            self.rep_config_ps(config_dict)
            config_ps = public.readFile(self.__config_file)

        try:
            config_ps_dict = json.loads(config_ps)
        except:
            # 配置文件损坏？
            self.rep_config_ps()
            config_ps_dict = json.loads(public.readFile(self.__config_file))

        return config_ps_dict

    def read_config(self):
        '''
            @name 获取配置信息
            @author hwliang
            @return dict
        '''
        # 配置文件不存在？
        if not os.path.exists(self.__config_file):
            self.rep_config()

        config = public.readFile(self.__config_file)
        if not config:  # 配置文件为空？
            self.rep_config()
            config = public.readFile(self.__config_file)

        try:
            config_dict = json.loads(config)
        except:
            # 配置文件损坏？
            self.rep_config()
            config_dict = json.loads(public.readFile(self.__config_file))

        config_dict.update(**self.read_config_ps(config_dict))

        return config_dict

    def save_config(self, config):
        '''
            @name 保存配置信息
            @author hwliang
            @param dict config
            @return void
        '''
        config = copy.deepcopy(config)
        config_ps_file = {}
        if "frequent_process" in config:
            config_ps_file["frequent_process"] = config.pop("frequent_process")
        if "default_dir_ps" in config:
            config_ps_file["default_dir_ps"] = config.pop("default_dir_ps")
        for i in config["paths"]:
            name = "dir_ps_" + str(i["pid"])
            if name in config:
                config_ps_file[name] = config.pop(name)
            i['path'] = os.path.realpath(i['path'])
            if i['path'][-1] != "/":
                i['path'] += "/"

        public.writeFile(self.__config_file, json.dumps(config, ensure_ascii=False, indent=4))
        public.writeFile(self.__config_ps_file, json.dumps(config_ps_file, ensure_ascii=False, indent=4))
        public.writeFile(self.__tips_file, '1')

    def get_tamper_paths(self, args=None):
        '''
            @name 获取受保护的目录列表
            @author hwliang
            @return list
        '''

        ###验证，放插件入口
        #ret = self.get_tamper_core()
        #if ret == 0:
            #return public.returnMsg(False, 'Expired or authorization terminated')

        config = self.read_config()
        if not config.get("paths"):
            return []

        result = []
        for path_info in config["paths"]:
            path_info['total'] = self.get_path_total(path_id=path_info['pid'])
            result.append(path_info)
        for i in config["paths"]:
            dir_ps = "dir_ps_" + str(i["pid"])
            for j in range(len(i["white_dirs"])):
                if i["white_dirs"][j] in config[dir_ps]:
                    i["white_dirs"][j] = {
                        "dir": i["white_dirs"][j],
                        "ps": config[dir_ps][i["white_dirs"][j]],
                    }
                elif i["white_dirs"][j] in config["default_dir_ps"]:
                    i["white_dirs"][j] = {
                        "dir": i["white_dirs"][j],
                        "ps": config["default_dir_ps"][i["white_dirs"][j]].get("ps"),
                        "tip_msg": config["default_dir_ps"][i["white_dirs"][j]].get("tip_msg", None)
                    }
                else:
                    i["white_dirs"][j] = {
                        "dir": i["white_dirs"][j]
                    }
            if "unused_white_dirs" not in i:
                i["unused_white_dirs"] = []
            for j in range(len(i["unused_white_dirs"])):
                if i['unused_white_dirs'][j] in config[dir_ps]:
                    i["unused_white_dirs"][j] = {
                        "dir": i["unused_white_dirs"][j],
                        "ps": config[dir_ps][i["unused_white_dirs"][j]]
                    }
                elif i["unused_white_dirs"][j] in config["default_dir_ps"]:
                    i["unused_white_dirs"][j] = {
                        "dir": i["unused_white_dirs"][j],
                        "ps": config["default_dir_ps"][i["unused_white_dirs"][j]].get("ps"),
                        "tip_msg": config["default_dir_ps"][i["unused_white_dirs"][j]].get("tip_msg", None)
                    }
                else:
                    i["unused_white_dirs"][j] = {
                        "dir": i["unused_white_dirs"][j]
                    }

        return config["paths"]

    def get_tamper_global_config(self, args=None):
        '''
            @name 获取全局配置
            @author hwliang
            @return dict
        '''
        config = self.read_config()
        return config

    def get_tamper_path_find(self, args=None, path_id=None, path=None):
        '''
            @name 获取指定目录配置
            @author hwliang
            @param args<dict_obj> 外部参数，可以为空
            @param path_id<int> 目录ID [选填]
            @param path<string> 目录路径 [选填]
            @return dict or None
        '''
        if args:  # 参数传递
            if 'path_id' in args:
                path_id = int(args.get("path_id"))
            if 'path' in args:
                path = args.get("path")

        # Parameter error
        if not path_id and not path:
            return None

        # 获取目录配置列表
        path_list = self.get_tamper_paths()

        # 查找目录配置
        for path_info in path_list:
            if path_id and path_info["pid"] == path_id:
                return path_info
            if path and path_info["path"] == path:
                return path_info

        # 没找到？
        return None

    def get_path_id(self, path_list):
        '''
            @name 获取目标ID
            @author hwliang
            @param path_list<list> 目录列表
            @return int
        '''
        if not path_list:
            return 1

        # 获取最大ID
        max_id = 0
        for path_info in path_list:
            if max_id < path_info["pid"]:
                max_id = path_info["pid"]

        # 返回ID
        return max_id + 1

    def create_path_config(self, args=None, path=None, ps=None):
        '''
            @name 创建目录配置
            @author hwliang
            @param args<dict_obj> 外部参数，可以为空
            @param path<string> 目录路径
            @param ps<dict_obj> 备注
            @return dict
        '''
        if args:  # 参数传递
            if 'path' in args:
                path = args.get("path")
            if 'ps' in args:
                ps = args.get("ps")

        # 路径标准化处理
        if path[-1] != "/": path += "/"
        path = path.replace('//', '/')

        # 参数过滤
        if not path: return public.returnMsg(False, "Directory path cannot be empty")
        if not os.path.exists(path) or os.path.isfile(path): return public.returnMsg(False,
                                                                                     "invalid directory: {}".format(
                                                                                         path))
        if self.get_tamper_path_find(path=path): return public.returnMsg(False,
                                                                         "The specified directory has already been added: {}".format(
                                                                             path))

        # 关键路径过滤
        if path in ['/', '/root/', '/boot/', '/www/', '/www/server/', '/www/server/panel/', '/www/server/panel/class/',
                    '/usr/', '/etc/', '/usr/bin/', '/usr/sbin/']:
            return public.returnMsg(False, "Cannot add system directory: {}".format(path))

        config = self.read_config()
        path_info = {
            "pid": self.get_path_id(config["paths"]),
            "path": path,
            "status": 1,
            "mode": 0,
            "is_create": 1,
            "is_modify": 1,
            "is_unlink": 1,
            "is_mkdir": 1,
            "is_rmdir": 1,
            "is_rename": 1,
            "is_chmod": 1,
            "is_chown": 1,
            "is_link": 1,
            "black_exts": config["default_black_exts"],
            "white_files": config["default_white_files"],
            "white_dirs": config["default_white_dirs"],
            "ps": ps
        }

        # 添加到配置列表
        config["paths"].append(path_info)
        config["dir_ps_" + str(path_info["pid"])] = {}
        self.save_config(config)
        public.WriteLog('Tamper-proof for Enterprise', "Add directory config: {}".format(path))
        return public.returnMsg(True, "Added successfully")

    def modify_path_config(self, args=None, path_id=None, path=None, key=None, value=None):
        '''
            @name 修改目录配置
            @author hwliang
            @param args<dict_obj> 外部参数，可以为空
            @param path_id<int> 目录ID
            @param path<string> 目录路径
            @param key<string> 配置项
            @param value<string> 配置值
            @return dict
        '''

        if args:
            if 'path_id' in args:
                path_id = int(args.get("path_id"))
            if 'path' in args:
                path = args.get("path")
            if 'key' in args:
                key = args.get("key")
            if 'value' in args:
                value = args.get("value")
                if not key in ['ps']: value = int(value)
        if not path_id and not path: return public.returnMsg(False, "Parameter error")
        if not key: return public.returnMsg(False, "Parameter error")
        keys = ["status", "mode", "is_create", "is_modify", "is_unlink", "is_mkdir", "is_rmdir", "is_rename",
                "is_chmod", "is_chown", "is_link", "ps"]
        if key not in keys: return public.returnMsg(False, "The specified configuration item does not exist")
        if not self.get_tamper_path_find(path_id=path_id, path=path): return public.returnMsg(False,
                                                                                              "The specified target configuration does not exist")

        # 获取目录配置
        config = self.read_config()
        for path_info in config["paths"]:
            if path_id and path_info["pid"] == path_id:
                path = path_info["path"]
                path_info[key] = value
                break
            if path and path_info["path"] == path:
                path_info[key] = value
                break
        self.save_config(config)

        key_status = {
            "is_modify": "Modify",
            "is_unlink": "Delete file",
            "is_rename": "Rename",
            "is_create": "Create file",
            "is_mkdir": "Create directory",
            "is_chmod": "Modify permissions",
            "is_chown": "Modify owner",
            "is_rmdir": "Delete directory",
            "is_link": "Create soft link",
        }
        value_status = ["Allow", "Disabled"]
        open_status = ['Turn off', 'Turn on']
        if key in ['status', 'ps']:
            if key == 'status':
                public.WriteLog('Tamper-proof for Enterprise',
                                "Modify directory [{}] config: [{}]".format(path, open_status[value]))
            else:
                public.WriteLog('Tamper-proof for Enterprise',
                                "Modify directory [{}] config: Remarks={}".format(path, value))
        else:
            public.WriteLog('Tamper-proof for Enterprise',
                            "Modify directory [{}] config: [{}]{}".format(path, value_status[value], key_status[key]))
        return public.returnMsg(True, "Success modified")

    def modify_path_config_batch(self, args=None, path_id=None, batch=None, value=None):
        '''
            @name 批量修改目录配置
            @param path_id<int> 目录ID
            @param batch<int> 批权限ID
            batch = 1, 禁止创建文件、禁止创建文件夹、禁止创建软链
            batch = 2, 禁止文件重命名、禁止修改所有者、禁止修改文件权限、禁止编辑文件
            batch = 3, 禁止删除文件、禁止删除文件夹
            @param value<int> 开启或关闭 1. 开启 0. 关闭
        '''
        if args:
            if 'path_id' in args:
                path_id = int(args.get("path_id"))
            if 'batch' in args:
                batch = int(args.get("batch"))
        if not path_id: return public.returnMsg(False, "Parameter error")
        keys = ["status", "mode", "is_create", "is_modify", "is_unlink", "is_mkdir", "is_rmdir", "is_rename",
                "is_chmod", "is_chown", "is_link", "ps"]
        if not self.get_tamper_path_find(path_id=path_id): return public.returnMsg(False,
                                                                                   "The specified target configuration does not exist")

        if batch == 1:
            self.modify_path_config(args, path_id, path=None, key='is_create', value=1)
            self.modify_path_config(args, path_id, path=None, key='is_mkdir', value=1)
            self.modify_path_config(args, path_id, path=None, key='is_link', value=1)
        elif batch == 2:
            self.modify_path_config(args, path_id, path=None, key='is_rename', value=1)
            self.modify_path_config(args, path_id, path=None, key='is_chown', value=1)
            self.modify_path_config(args, path_id, path=None, key='is_chmod', value=1)
            self.modify_path_config(args, path_id, path=None, key='is_modify', value=1)
        elif batch == 3:
            self.modify_path_config(args, path_id, path=None, key='is_unlink', value=1)
            self.modify_path_config(args, path_id, path=None, key='is_rmdir', value=1)
        return public.returnMsg(True, "Success modified")

    def remove_path_config(self, args=None, path_id=None, path=None):
        '''
            @name 删除目录配置
            @author hwliang
            @param args<dict_obj> 外部参数，可以为空
            @param path_id<int> 目录ID
            @param path<string> 目录路径
            @return dict
        '''
        if args:
            if 'path_id' in args:
                path_id = int(args.get("path_id"))
            if 'path' in args:
                path = args.get("path")
        if not path_id and not path: return public.returnMsg(False, "Parameter error")
        if not self.get_tamper_path_find(path_id=path_id, path=path): return public.returnMsg(False,
                                                                                              "The specified target configuration does not exist")

        # 获取目录配置
        config = self.read_config()
        for path_info in config["paths"]:
            if path_id and path_info["pid"] == path_id:
                path = path_info["path"]
                config["paths"].remove(path_info)
                break
            if path and path_info["path"] == path:
                path_id = path_info["pid"]
                config["paths"].remove(path_info)
                break
        self.save_config(config)
        # 清理日志和统计文件
        log_file = "{}/{}.log".format(self.__logs_path, path_id)
        if os.path.exists(log_file): os.remove(log_file)
        total_path = "{}/{}".format(self.__total_path, path_id)
        if os.path.exists(total_path): public.ExecShell("rm -rf {}".format(total_path))

        push_conf = "{}/class/push/push.json".format(public.get_panel_path())
        if os.path.exists(push_conf):
            data = json.loads(public.readFile(push_conf))
            if "tamper_push" in data:
                if str(path_id) in data["tamper_push"]: del data["tamper_push"][str(path_id)]
                if path_id in data["tamper_push"]: del data["tamper_push"][path_id]
                public.writeFile(push_conf, json.dumps(data))

        public.WriteLog('Tamper-proof for Enterprise', "Delete directory config: {}".format(path))
        return public.returnMsg(True, "successfully deleted")

    def sync_black_exts(self, get):
        if not hasattr(get, 'exts') or not hasattr(get, 'site_ids'): return public.returnMsg(False, "Parameter error")
        exts = json.loads(get.exts)
        site_ids = json.loads(get.site_ids)
        res = []
        for id in site_ids:
            try:
                site_data = public.M('sites').where('id=?', (id,)).field('name,path').find()
                name = site_data['name']
                if not site_data: continue
                site_path = site_data['path'] + '/'
                details = self.get_glabal_total()['details']
                id = [i for i in details if i['path'] == site_path]
                if not id:
                    args = {'paths': [{'path': site_path, 'ps': name}]}
                    self.multi_create(args)
                    details = self.get_glabal_total()['details']
                    id = [i for i in details if i['path'] == site_path][0]['pid']
                else:
                    id = id[0]['pid']
                if not self.get_tamper_rule_by_path(path=site_path)['status']:
                    self.modify_path_config(path_id=id, path=site_path, key='status', value=1)
                for n, s in exts.items():
                    self.add_black_exts(path_id=id, path=site_path, exts=n)
                    self.release_file_ext(path=site_path, path_id=id, exts=n, release=0 if s else 1)
                res.append({'name': name, 'msg': 'Synchronization is successful'})
            except:
                res.append({'name': name, 'msg': 'Synchronization failure'})
        return public.returnMsg(True, res)

    # def add_black_exts(self, args=None, path_id=None, path=None, exts=None):
    #     try:
    #         '''
    #             @name 添加黑名单扩展名
    #             @author hwliang
    #             @param args<dict_obj> 外部参数，可以为空
    #             @param path_id<int> 目录ID
    #             @param path<string> 目录路径
    #             @param exts<string> 扩展名
    #             @return dict
    #         '''
    #         if args:
    #             if 'path_id' in args:
    #                 path_id = int(args.get("path_id"))
    #             if 'path' in args:
    #                 path = args.get("path")
    #             if 'exts' in args:
    #                 exts = args.get("exts")
    #         if not path_id and not path: return public.returnMsg(False, "Parameter error")
    #         if not exts: return public.returnMsg(False, "保护内容不能是空白")
    #         if not self.get_tamper_path_find(path_id=path_id, path=path): return public.returnMsg(False, "指定目标配置不存在")

    #         # 获取目录配置
    #         config = self.read_config()
    #         for path_info in config["paths"]:
    #             if path_id and path_info["pid"] == path_id:
    #                 # for ext in exts:
    #                 if exts in path_info["black_exts"]: return public.returnMsg(False, "指定后缀名已存在")
    #                 path_info["black_exts"].append(exts)
    #                 path = path_info["path"]
    #                 break
    #             if path and path_info["path"] == path:
    #                 if exts in path_info["black_exts"]: return public.returnMsg(False, "指定后缀名已存在")
    #                 path_info["black_exts"].append(exts)
    #                 break

    #         self.save_config(config)
    #         public.WriteLog("防篡改", "添加指定目录:{},的受保护的后缀名: {}".format(path, exts))
    #         return public.returnMsg(True, "添加成功")
    #     except Exception as e:
    #         return public.returnMsg(False,str(e))

    def add_black_exts(self, args=None, path_id=None, path=None, exts=None):
        '''
            @name 添加黑名单扩展名
            @author hwliang
            @param args<dict_obj> 外部参数，可以为空
            @param path_id<int> 目录ID
            @param path<string> 目录路径
            @param exts<string> 扩展名
            @return dict
        '''
        if args:
            if 'path_id' in args:
                path_id = int(args.get("path_id"))
            if 'path' in args:
                path = args.get("path")
            if 'exts' in args:
                exts = args.get("exts").split(',')
                # 去除exts列表的两边空格
                exts = [ext.strip() for ext in exts]
        if not path_id and not path: return public.returnMsg(False, "Parameter error")
        if not exts: return public.returnMsg(False, "Protected content cannot be blank")
        if not self.get_tamper_path_find(path_id=path_id, path=path): return public.returnMsg(False,
                                                                                              "The specified target configuration does not exist")

        # 获取目录配置
        config = self.read_config()
        skipped_exts = []
        for path_info in config["paths"]:
            if path_id and path_info["pid"] == path_id:
                for ext in exts:
                    if ext in path_info["black_exts"]:
                        skipped_exts.append(ext)
                    path_info["black_exts"].append(ext)
                path = path_info["path"]
                break
            if path and path_info["path"] == path:
                for ext in exts:
                    if ext in path_info["black_exts"]:
                        skipped_exts.append(ext)
                        continue
                    path_info["black_exts"].append(ext)
                break

        self.save_config(config)
        public.WriteLog('Tamper-proof for Enterprise',
                        "Add the specified directory: {}, the protected suffix name: {}".format(path, ','.join(exts)))
        if skipped_exts:  # If there are skipped extensions
            return public.returnMsg(True, "Added successfully,The following suffix names are skipped: {}".format(
                ','.join(skipped_exts)))
        else:
            return public.returnMsg(True, "Added successfully")

    def remove_black_exts(self, args=None, path_id=None, path=None, exts=None):
        '''
            @name 删除黑名单扩展名
            @author hwliang
            @param args<dict_obj> 外部参数，可以为空
            @param path_id<int> 目录ID
            @param path<string> 目录路径
            @param exts<string> 扩展名
            @return dict
        '''
        if args:
            if 'path_id' in args:
                path_id = int(args.get("path_id"))
            if 'path' in args:
                path = args.get("path")
            if 'exts' in args:
                exts = args.get("exts")
        if not path_id and not path: return public.returnMsg(False, "Parameter error")
        if not exts: return public.returnMsg(False, "Excluded content cannot be blank")
        if not self.get_tamper_path_find(path_id=path_id, path=path): return public.returnMsg(False,
                                                                                              "The specified target configuration does not exist")

        # 获取目录配置
        config = self.read_config()
        for path_info in config["paths"]:
            if path_id and path_info["pid"] == path_id:
                path = path_info["path"]
                if exts not in path_info["black_exts"]:
                    if "white_exts" in path_info and exts in path_info["white_exts"]:
                        path_info["white_exts"].remove(exts)
                        break
                    else:
                        return public.returnMsg(False, "The specified suffix does not exist")
                path_info["black_exts"].remove(exts)
                break
            if path and path_info["path"] == path:
                if exts not in path_info["black_exts"]:
                    if "white_exts" in path_info and exts in path_info["white_exts"]:
                        path_info["white_exts"].remove(exts)
                        break
                    else:
                        return public.returnMsg(False, "The specified suffix does not exist")
                path_info["black_exts"].remove(exts)
                break

        self.save_config(config)
        public.WriteLog('Tamper-proof for Enterprise',
                        "Delete directory config: {}, the protected suffix name: {}".format(path, exts))
        return public.returnMsg(True, "successfully deleted")

    def add_white_files(self, args=None, path_id=None, path=None, filename=None):
        '''
            @name 添加文件白名单
            @author hwliang
            @param args<dict_obj> 外部参数，可以为空
            @param path_id<int> 目录ID
            @param path<string> 目录路径
            @param filename<string> 文件名
            @return dict
        '''

        if args:
            if 'path_id' in args:
                path_id = int(args.get("path_id"))
            if 'path' in args:
                path = args.get("path")
            if 'filename' in args:
                filename = args.get("filename")
        if not path_id and not path: return public.returnMsg(False, "Parameter error")
        if not filename: return public.returnMsg(False, "The content to add to the whitelist cannot be blank")
        if not self.get_tamper_path_find(path_id=path_id, path=path): return public.returnMsg(False,
                                                                                              "The specified target configuration does not exist")

        # 获取目录配置
        config = self.read_config()
        for path_info in config["paths"]:
            if path_id and path_info["pid"] == path_id:
                if filename in path_info["white_files"]: return public.returnMsg(False,
                                                                                 "The specified file has already been added")
                path_info["white_files"].append(filename)
                path = path_info["path"]
                break
            if path and path_info["path"] == path:
                if filename in path_info["white_files"]: return public.returnMsg(False,
                                                                                 "The specified file has already been added")
                path_info["white_files"].append(filename)
                break

        self.save_config(config)
        public.WriteLog('Tamper-proof for Enterprise',
                        "Add the specified directory: {}, the file whitelist: {}".format(path, filename))
        return public.returnMsg(True, "Added successfully")

    def remove_white_files(self, args=None, path_id=None, path=None, filename=None):
        '''
            @name 删除文件白名单
            @author hwliang
            @param args<dict_obj> 外部参数，可以为空
            @param path_id<int> 目录ID
            @param path<string> 目录路径
            @param filename<string> 文件名
            @return dict
        '''
        if args:
            if 'path_id' in args:
                path_id = int(args.get("path_id"))
            if 'path' in args:
                path = args.get("path")
            if 'filename' in args:
                filename = args.get("filename")
        if not path_id and not path: return public.returnMsg(False, "Parameter error")
        if not filename: return public.returnMsg(False, "The content of removing the whitelist cannot be blank")
        if not self.get_tamper_path_find(path_id=path_id, path=path): return public.returnMsg(False,
                                                                                              "The specified target configuration does not exist")

        # 获取目录配置
        config = self.read_config()
        for path_info in config["paths"]:
            if path_id and path_info["pid"] == path_id:
                path = path_info["path"]
                if filename not in path_info["white_files"]:
                    if "unused_white_files" in path_info and filename in path_info["unused_white_files"]:
                        path_info["unused_white_files"].remove(filename)
                        break
                    else:
                        return public.returnMsg(False, "The specified file does not exist")
                path_info["white_files"].remove(filename)
                break
            if path and path_info["path"] == path:
                if filename not in path_info["white_files"]:
                    if "unused_white_files" in path_info and filename in path_info["unused_white_files"]:
                        path_info["unused_white_files"].remove(filename)
                        break
                    else:
                        return public.returnMsg(False, "The specified file does not exist")
                path_info["white_files"].remove(filename)
                break

        self.save_config(config)
        public.WriteLog('Tamper-proof for Enterprise',
                        "Delete specified directory:{},File whitelist for: {}".format(path, filename))
        return public.returnMsg(True, "successfully deleted")

    def add_white_dirs(self, args=None, path_id=None, path=None, dirnames=None):
        '''
            @name 添加目录白名单
            @author hwliang
            @param args<dict_obj> 外部参数，可以为空
            @param path_id<int> 目录ID
            @param path<string> 目录路径
            @param dirnames<string> 目录名列表
            @return dict
        '''
        if args:
            if 'path_id' in args:
                path_id = int(args.get("path_id"))
            if 'path' in args:
                path = args.get("path")
            if 'dirnames' in args:
                dirnames = args.get("dirnames").split(',')
        if not path_id and not path:
            return public.returnMsg(False, "Parameter error")
        if not dirnames:
            return public.returnMsg(False, "The content to add to the whitelist cannot be blank")
        if not self.get_tamper_path_find(path_id=path_id, path=path): return public.returnMsg(False,
                                                                                              "The specified target configuration does not exist")

        # 获取目录配置
        config = self.read_config()
        skipped_dirs = []
        for path_info in config["paths"]:
            if path_id and path_info["pid"] == path_id:
                for dirname in dirnames:
                    print(path_info["white_dirs"])
                    if dirname in path_info["white_dirs"]:
                        skipped_dirs.append(dirname)
                        continue
                    path_info["white_dirs"].append(dirname)
                path = path_info["path"]
                break
            if path and path_info["path"] == path:
                for dirname in dirnames:
                    if dirname in path_info["white_dirs"]:
                        skipped_dirs.append(dirname)
                        continue
                    path_info["white_dirs"].append(dirname)
                break

        self.save_config(config)
        public.WriteLog('Tamper-proof for Enterprise',
                        "Add the specified directory: {}, the directory whitelist: {}".format(path, ','.join(dirnames)))
        if skipped_dirs:
            return public.returnMsg(True, "Added successfully, The following directories are skipped: {}".format(
                ','.join(skipped_dirs)))
        else:
            return public.returnMsg(True, "Added successfully")

    def remove_white_dirs(self, args=None, path_id=None, path=None, dirname=None):
        '''
            @name 删除目录白名单
            @author hwliang
            @param args<dict_obj> 外部参数，可以为空
            @param path_id<int> 目录ID
            @param path<string> 目录路径
            @param dirname<string> 目录名
            @return dict
        '''
        if args:
            if 'path_id' in args:
                path_id = int(args.get("path_id"))
            if 'path' in args:
                path = args.get("path")
            if 'dirname' in args:
                dirname = args.get("dirname")
        if not path_id and not path: return public.returnMsg(False, "Parameter error")
        if not dirname: return public.returnMsg(False, "The content of removing the whitelist cannot be blank")
        if not self.get_tamper_path_find(path_id=path_id, path=path): return public.returnMsg(False,
                                                                                              "The specified target configuration does not exist")

        # 获取目录配置
        config = self.read_config()
        for path_info in config["paths"]:
            if path_id and path_info["pid"] == path_id:
                if dirname not in path_info["white_dirs"]:
                    if "unused_white_dirs" in path_info and dirname in path_info["unused_white_dirs"]:
                        path_info["unused_white_dirs"].remove(dirname)
                    else:
                        return public.returnMsg(False, "The specified directory does not exist")
                else:
                    path_info["white_dirs"].remove(dirname)
                if dirname in config["dir_ps_" + str(path_info["pid"])]: config["dir_ps_" + str(path_info["pid"])].pop(
                    dirname)
                path = path_info["path"]
                break
            if path and path_info["path"] == path:
                if dirname not in path_info["white_dirs"]:
                    if "unused_white_dirs" in path_info and dirname in path_info["unused_white_dirs"]:
                        path_info["unused_white_dirs"].remove(dirname)
                    else:
                        return public.returnMsg(False, "The specified directory does not exist")
                else:
                    path_info["white_dirs"].remove(dirname)
                if dirname in config["dir_ps_" + str(path_info["pid"])]: config["dir_ps_" + str(path_info["pid"])].pop(
                    dirname)
                path = path_info["path"]
                break

        self.save_config(config)
        public.WriteLog('Tamper-proof for Enterprise',
                        "Delete the specified directory: {}, the directory whitelist: {}".format(path, dirname))
        return public.returnMsg(True, "successfully deleted")

    def modify_global_config(self, args=None, key=None, value=None):
        '''
            @name 修改全局配置
            @author hwliang<2020-07-01>
            @param args<dict_obj> 外部参数，可以为空
            @param key<string> 全局配置键名
            @param value<string> 全局配置键值
            @return dict
        '''

        # 检测内核是否支持
        glabal = self.get_glabal_total()['glabal_status']
        kernel = glabal.get('kernel_module_status', False)
        if not kernel:
            return public.returnMsg(False, "Sorry, opening failed, please go to the App Store --Tamper-proof for Enterprise to view details")


        if args:
            if 'key' in args: key = args.get("key")
            if 'value' in args: value = int(args.get("value"))

        if not key: return public.returnMsg(False, "Parameter error")
        if key in ['process_names', 'uids', 'gids', 'paths']: return public.returnMsg(False,
                                                                                      'Configuration items that are not allowed to be modified')
        config = self.read_config()

        if key not in config: return public.returnMsg(False, "The specified global configuration does not exist")
        config[key] = value
        self.save_config(config)

        key_status = {
            "is_modify": "Modify",
            "is_unlink": "Delete file",
            "is_rename": "Rename",
            "is_create": "Create file",
            "is_mkdir": "Create directory",
            "is_chmod": "Modify permissions",
            "is_chown": "Modify owner",
            "is_rmdir": "Delete directory",
            "is_link": "Create soft link",
        }
        value_status = ["Allow", "Disabled"]
        open_status = ['Turn off', 'Turn on']
        if key in ['status', 'min_pid']:
            if key == 'status':
                public.WriteLog('Tamper-proof for Enterprise',
                                "Modify the global config: [{}]".format(open_status[value]))
            else:
                public.WriteLog('Tamper-proof for Enterprise',
                                "Modify global config: minimum protected PID={}".format(value))
        else:
            public.WriteLog('Tamper-proof for Enterprise',
                            "Modify global config:[{}]{}".format(value_status[value], key_status[key]))
        return public.returnMsg(True, "Success modified")

    def add_process_names(self, args=None, pname=None):
        '''
            @name 添加进程名
            @author hwliang<2020-07-01>
            @param args<dict_obj> 外部参数，可以为空
            @param name<string> 进程名
            @return dict
        '''
        if args:
            if 'pname' in args: pname = args.get("pname")
        if not pname: return public.returnMsg(False, "Parameter error")
        config = self.read_config()
        if pname in config["process_names"]: return public.returnMsg(False,
                                                                     "The specified process name has already been added")
        config["process_names"].append(pname)
        self.save_config(config)
        public.WriteLog('Tamper-proof for Enterprise', "Add process name whitelist: {}".format(pname))
        return public.returnMsg(True, "Added successfully")

    def remove_process_names(self, args=None, pname=None):
        '''
            @name 删除进程名
            @author hwliang<2020-07-01>
            @param args<dict_obj> 外部参数，可以为空
            @param pname<string> 进程名
            @return dict
        '''
        if args:
            if 'pname' in args: pname = args.get("pname")
        if not pname: return public.returnMsg(False, "Parameter error")
        config = self.read_config()
        if pname not in config["process_names"]: return public.returnMsg(False,
                                                                         "The specified process name does not exist")
        config["process_names"].remove(pname)
        self.save_config(config)
        public.WriteLog('Tamper-proof for Enterprise', "Delete process name whitelist: {}".format(pname))
        return public.returnMsg(True, "successfully deleted")

    def edit_process_name(self, args=None):
        '''
            @name 编辑进程名
            @author hwliang<2024-01-24>
            @param old_pname<string> 旧的进程名
            @param new_pname<string> 新的进程名
            @param args<dict_obj> 外部参数，可以为空
            @return dict
        '''
        # print(args.get("pname"))
        # 删除旧的进程名
        args.pname = args.get("old_pname")
        remove_result = self.remove_process_names(args=args)
        if not remove_result['status']: return remove_result
        args.pname = args.get("new_pname")
        # 添加新的进程名
        add_result = self.add_process_names(args=args)
        return public.returnMsg(True, "Modify successfully")

    def add_uids(self, args=None, uid=None):
        '''
            @name 添加UID
            @author hwliang<2020-07-01>
            @param args<dict_obj> 外部参数，可以为空
            @param uid<int> UID
            @return dict
        '''
        if args:
            if 'uid' in args: uid = int(args.get("uid"))
        if uid == None: return public.returnMsg(False, "Parameter error")
        config = self.read_config()
        if uid in config["uids"]: return public.returnMsg(False, "The specified UID has already been added")
        config["uids"].append(uid)
        self.save_config(config)
        public.WriteLog('Tamper-proof for Enterprise', "Add user whitelist: {}".format(self.get_user_byuid(uid)))
        return public.returnMsg(True, "Added successfully")

    def remove_uids(self, args=None, uid=None):
        '''
            @name 删除UID
            @author hwliang<2020-07-01>
            @param args<dict_obj> 外部参数，可以为空
            @param uid<int> UID
            @return dict
        '''
        if args:
            if 'uid' in args: uid = int(args.get("uid"))
        if uid == None: return public.returnMsg(False, "Parameter error")
        config = self.read_config()
        if uid not in config["uids"]: return public.returnMsg(False, "The specified UID does not exist")
        config["uids"].remove(uid)
        self.save_config(config)
        public.WriteLog('Tamper-proof for Enterprise', "Delete user whitelist: {}".format(self.get_user_byuid(uid)))
        return public.returnMsg(True, "successfully deleted")

    def get_group_bygid(self, gid):
        '''
            @name 获取组名
            @author hwliang
            @param gid<int> 组ID
            @return string
        '''
        gid = int(gid)
        gids = self.get_linux_gids()
        for g in gids:
            if gid == g['gid']:
                return g['group']
        return gid

    def get_user_byuid(self, uid):
        '''
            @name 获取用户名
            @author hwliang
            @param uid<int> 用户ID
            @return string
        '''
        uid = int(uid)
        uids = self.get_linux_uids()
        for u in uids:
            if uid == u['uid']:
                return u['user']
        return uid

    def add_gids(self, args=None, gid=None):
        '''
            @name 添加GID
            @author hwliang<2020-07-01>
            @param args<dict_obj> 外部参数，可以为空
            @param gid<int> GID
            @return dict
        '''
        if args:
            if 'gid' in args: gid = int(args.get("gid"))
        if gid == None: return public.returnMsg(False, "Parameter error")
        config = self.read_config()
        if gid in config["gids"]: return public.returnMsg(False, "The specified user group has been added")
        config["gids"].append(gid)
        self.save_config(config)

        public.WriteLog('Tamper-proof for Enterprise', "Add user group whitelist: {}".format(self.get_group_bygid(gid)))
        return public.returnMsg(True, "Added successfully")

    def remove_gids(self, args=None, gid=None):
        '''
            @name 删除GID
            @author hwliang<2020-07-01>
            @param args<dict_obj> 外部参数，可以为空
            @param gid<int> GID
            @return dict
        '''
        if args:
            if 'gid' in args: gid = int(args.get("gid"))
        if gid == None: return public.returnMsg(False, "Parameter error")
        config = self.read_config()
        if gid not in config["gids"]: return public.returnMsg(False, "The specified user group does not exist")
        config["gids"].remove(gid)
        self.save_config(config)
        public.WriteLog('Tamper-proof for Enterprise',
                        "Delete user group whitelist: {}".format(self.get_group_bygid(gid)))
        return public.returnMsg(True, "successfully deleted")

    def get_user_ps(self, user):
        '''
            @name 获取用户描述
            @author hwliang
            @param user<string> 用户名
            @return string
        '''
        user = str(user)
        user_ps = {
            "root": "System superuser",
            "www": "User used run the website, including php-fpm, nginx, apache, pure-ftpd and other website-related processes",
            "mysql": "user used run the MySQL database",
            "mongo": "user used run the MongoDB database",
            "memcached": "User used run Memcached",
            "redis": "User for running Redis",
            "ftp": "User for running FTP",
            "postfix": "User run Postfix (mail)",
            "sshd": "User used run SSH",
            "springboot": "User used run Java-SpringBoot",
            "tomcat": "User used run Tomcat",
            "postgres": "User used run the PostgreSQL database",
            "named": "User for running DNS",
            "httpd": "User for running Apache",
            "nginx": "User for running Nginx",
            "php-fpm": "User for running PHP-FPM",
            "pure-ftpd": "User for running Pure-FTP",
            "nobody": "Low privilege user",
        }
        if user in user_ps:
            return user_ps[user]
        return user

    def get_linux_uids(self, args=None):
        '''
            @name 获取系统UID
            @author hwliang<2020-07-01>
            @param args<dict_obj> 外部参数，可以为空
            @return list
        '''
        passwd_file = "/etc/passwd"
        if not os.path.exists(passwd_file): return []
        uids = []
        passwd_body = public.readFile(passwd_file)
        for line in passwd_body.split("\n"):
            if not line: continue
            _tmp = line.split(":")
            uid = int(_tmp[2])
            if uid < 1000 and uid > 0: continue
            uid_info = {
                "uid": uid,
                "ps": self.get_user_ps(_tmp[0]),
                "user": _tmp[0]
            }
            uids.append(uid_info)
        return sorted(uids, key=lambda x: x['uid'])

    def get_linux_gids(self, args=None):
        '''
            @name 获取系统GID
            @author hwliang<2020-07-01>
            @param args<dict_obj> 外部参数，可以为空
            @return list
        '''
        group_file = "/etc/group"
        if not os.path.exists(group_file): return []
        gids = []
        group_body = public.readFile(group_file)
        for line in group_body.split("\n"):
            if not line: continue
            _tmp = line.split(":")
            gid = int(_tmp[2])
            if gid < 1000 and gid > 0: continue
            gid_info = {
                "gid": gid,
                "ps": self.get_user_ps(_tmp[0]),
                "group": _tmp[0]
            }
            gids.append(gid_info)
        return sorted(gids, key=lambda x: x['gid'])

    def get_linux_users_or_groups(self, args=None):
        '''
            @name 获取系统用户和组
            @author hwliang<2020-07-01>
            @param args<dict_obj> 外部参数，可以为空
            @return list
        '''

        result = {
            "users": self.get_linux_uids(args),
            "groups": self.get_linux_gids(args)
        }
        return result

    def old_get_logs(self, args=None, path_id=None):
        '''
            @name 获取日志
            @author hwliang<2020-07-01>
            @param path_id<int> 日志路径ID
            @return list
        '''
        rows = 10
        p = 1
        if args:
            if 'path_id' in args: path_id = int(args.get("path_id"))
            if 'p' in args: p = int(args.get("p"))
            if 'rows' in args: rows = int(args.get("rows"))
        if path_id == None: return public.returnMsg(False, "Parameter error")

        path_info = self.get_tamper_path_find(path_id=path_id)
        if not path_info: return public.returnMsg(False, "The specified directory configuration does not exist")

        log_file = "{}/{}.log".format(self.__logs_path, path_id)
        if not os.path.exists(log_file):
            return []

        result = []

        f_size = os.path.getsize(log_file)

        if f_size > 1024 * 1024 * 30:
            page = public.get_page(10000, p, rows)
            tmp_lines = public.GetNumLines(log_file, rows, p)
            if tmp_lines:
                tmp_lines = tmp_lines.split("\n")
            else:
                tmp_lines = []

        else:
            fp = open(log_file, "r", errors="ignore")
            all_lines = fp.readlines()
            fp.close()
            page = public.get_page(len(all_lines), p, rows)
            start = int(page['shift'])
            tmp_lines = []
            all_sort_lines = []
            for line in all_lines:
                all_sort_lines.insert(0, line)
            tmp_lines = all_sort_lines[start:start + rows]

        for _line in tmp_lines:
            _tmp = _line.split("] [")
            if len(_tmp) < 2: continue
            _info = {
                "date": _tmp[0].strip().strip("["),
                "type": _tmp[1],
                "content": _tmp[2].replace(path_info['path'], "./"),
                "user": _tmp[3],
                "process": _tmp[4].strip().strip("]")
            }
            result.append(_info)
        page['data'] = sorted(result, key=lambda x: x['date'], reverse=True)

        return page

    def get_action_logs(self, args=None):
        '''
            @name 获取操作日志
            @author hwliang
            @param p<int> 分页
            @param rows<int> 每页行数
        '''

        num = public.M("logs").where("type=?", "Tamper-proof for Enterprise").count()
        p = 1
        rows = 10
        if args:
            if 'p' in args: p = int(args.get("p"))
            if 'rows' in args: rows = int(args.get("rows"))

        page = public.get_page(num, p, rows)
        limit = "{},{}".format(page["shift"], page['row'])
        page['data'] = public.M("logs").where("type=?", "Tamper-proof for Enterprise").order("id desc").limit(
            limit).field("addtime,type,log").select()
        return page

    def get_action_logs_for_exts(self, args=None):
        '''
            @name 获取相应拓展名的操作日志
            @param p<int> 分页
            @param rows<int> 每页行数
            @param pid<int> 路径ID
            @param exts<string> 受保护拓展名
        '''
        p = 1
        rows = 10
        pid = 0
        exts = None
        if args:
            if 'p' in args: p = int(args.get("p"))
            if 'rows' in args: rows = int(args.get("rows"))
            if 'pid' in args: pid = int(args.get("pid"))
            if 'exts' in args: exts = args.get("exts")

        tamper_paths = self.get_tamper_paths()
        for path_item in tamper_paths:
            if path_item['pid'] == int(pid):
                path = path_item["path"]

        num = public.M("logs").where("type=? AND log LIKE ? AND log LIKE ?",
                                     ("Tamper-proof for Enterprise", "%" + path + "%p", "%" + exts + "%")).count()

        page = public.get_page(num, p, rows)
        limit = "{},{}".format(page["shift"], page['row'])
        page['data'] = public.M("logs").where("type=? AND log LIKE ? AND log LIKE ?", (
        "Tamper-proof for Enterprise", "%" + path + "%p", "%" + exts + "%")).order("id desc").limit(limit).field(
            "addtime,type,log").select()
        return page

    def get_action_logs_for_dirname(self, args=None):
        '''
            @name 获取相应添加到白名单的目录日志
            @param p<int> 分页
            @param rows<int> 每页行数
            @param pid<int> 路径ID
            @param dirname<string> 添加到白名单的子路径
        '''
        p = 1
        rows = 10
        pid = 0
        dirname = None
        if args:
            if 'p' in args: p = int(args.get("p"))
            if 'rows' in args: rows = int(args.get("rows"))
            if 'pid' in args: pid = int(args.get("pid"))
            if 'dirname' in args: dirname = args.get("dirname")

        tamper_paths = self.get_tamper_paths()
        for path_item in tamper_paths:
            if path_item['pid'] == int(pid):
                path = path_item["path"]

        num = public.M("logs").where("type=? AND log LIKE ? AND log LIKE ?",
                                     ("Tamper-proof for Enterprise", "%" + path + "%", "%" + dirname + "%")).count()

        page = public.get_page(num, p, rows)
        limit = "{},{}".format(page["shift"], page['row'])
        page['data'] = public.M("logs").where("type=? AND log LIKE ? AND log LIKE ?", (
        "Tamper-proof for Enterprise", "%" + path + "%", "%" + dirname + "%")).order("id desc").limit(limit).field(
            "addtime,type,log").select()
        return page

    def get_action_logs_for_filename(self, args=None):
        '''
            @name 获取相应添加到白名单的目录日志
            @param p<int> 分页
            @param rows<int> 每页行数
            @param pid<int> 路径ID
            @param filename<string> 添加到白名单的文件名
        '''
        p = 1
        rows = 10
        pid = 0
        filename = None
        if args:
            if 'p' in args: p = int(args.get("p"))
            if 'rows' in args: rows = int(args.get("rows"))
            if 'pid' in args: pid = int(args.get("pid"))
            if 'filename' in args: filename = args.get("filename")

        tamper_paths = self.get_tamper_paths()
        for path_item in tamper_paths:
            if path_item['pid'] == int(pid):
                path = path_item["path"]

        num = public.M("logs").where("type=? AND log LIKE ? AND log LIKE ?",
                                     ("Tamper-proof for Enterprise", "%" + path + "%", "%" + filename + "%")).count()

        page = public.get_page(num, p, rows)
        limit = "{},{}".format(page["shift"], page['row'])
        page['data'] = public.M("logs").where("type=? AND log LIKE ? AND log LIKE ?", (
        "Tamper-proof for Enterprise", "%" + path + "%", "%" + filename + "%")).order("id desc").limit(limit).field(
            "addtime,type,log").select()
        return page

    def get_action_logs_for_pname(self, args=None):
        '''
            @name 获取相应添加到白名单的目录日志
            @param p<int> 分页
            @param rows<int> 每页行数
            @param pid<int> 路径ID
            @param pname<string> 添加到白名单的进程名
        '''
        p = 1
        rows = 10
        pid = 0
        pname = None
        if args:
            if 'p' in args: p = int(args.get("p"))
            if 'rows' in args: rows = int(args.get("rows"))
            if 'pid' in args: pid = int(args.get("pid"))
            if 'pname' in args: pname = args.get("pname")

        tamper_paths = self.get_tamper_paths()
        for path_item in tamper_paths:
            if path_item['pid'] == int(pid):
                path = path_item["path"]

        num = public.M("logs").where("type=? AND log LIKE ? AND log LIKE ?",
                                     ("Tamper-proof for Enterprise", "%" + path + "%", "%" + pname + "%")).count()

        page = public.get_page(num, p, rows)
        limit = "{},{}".format(page["shift"], page['row'])
        page['data'] = public.M("logs").where("type=? AND log LIKE ? AND log LIKE ?", (
        "Tamper-proof for Enterprise", "%" + path + "%", "%" + pname + "%")).order("id desc").limit(limit).field(
            "addtime,type,log").select()

        return page

    def release_file_ext(self, args=None, path_id=None, path=None, exts=None, release=None):
        '''
            @name 添加目录白名单
            @param args<dict_obj> 外部参数，可以为空
            @param path_id<int> 目录ID
            @param path<string> 目录路径
            @param exts<string> 文件后缀
            @return dict
        '''
        if args:
            if 'path_id' in args:
                path_id = int(args.get("path_id"))
            if 'path' in args:
                path = args.get("path")
            if 'exts' in args:
                exts = args.get("exts")
            if 'release' in args:
                release = int(args.get("release"))
        if not path_id and not path: return public.returnMsg(False, "Parameter error")
        if not exts: return public.returnMsg(False, "The content of the modified whitelist cannot be blank")
        if not self.get_tamper_path_find(path_id=path_id, path=path): return public.returnMsg(False,
                                                                                              "The specified target configuration does not exist")

        # 获取目录配置
        config = self.read_config()
        for path_info in config['paths']:
            if "white_exts" not in path_info:
                path_info["white_exts"] = []
            if path_id and path_info['pid'] == path_id:
                if release == 1:
                    if exts not in path_info["white_exts"]:
                        path_info["white_exts"].append(exts)
                    if exts in path_info["black_exts"]:
                        path_info["black_exts"].remove(exts)
                else:
                    if exts in path_info["white_exts"]:
                        path_info["white_exts"].remove(exts)
                    if exts not in path_info["black_exts"]:
                        path_info["black_exts"].append(exts)
            if path and path_info["path"] == path:
                if release == 1:
                    if exts not in path_info["white_exts"]:
                        path_info["white_exts"].append(exts)
                    if exts in path_info["black_exts"]:
                        path_info["black_exts"].remove(exts)
                else:
                    if exts in path_info["white_exts"]:
                        path_info["white_exts"].remove(exts)
                    if exts not in path_info["black_exts"]:
                        path_info["black_exts"].append(exts)

        self.save_config(config)
        if release == 1:
            action = "allow"
        else:
            action = "not allow"
        if not path:
            path = self.get_tamper_path_find(path_id=path_id)["path"]
        public.WriteLog('Tamper-proof for Enterprise',
                        "{}  The specified directory:{}, Whitelist of file types:{}".format(action, path, exts))
        return public.returnMsg(True, "Success modified")

    def release_white_dirname(self, args=None, path_id=None, path=None, dirname=None, release=None):
        '''
            @name 添加目录白名单
            @author hwliang
            @param args<dict_obj> 外部参数，可以为空
            @param path_id<int> 目录ID
            @param path<string> 目录路径
            @param dirname<string> 目录名
            @return dict
        '''
        if args:
            if 'path_id' in args:
                path_id = int(args.get("path_id"))
            if 'path' in args:
                path = args.get("path")
            if 'dirname' in args:
                dirname = args.get("dirname")
            if 'release' in args:
                release = int(args.get("release"))
        if not path_id and not path: return public.returnMsg(False, "Parameter error")
        if not dirname: return public.returnMsg(False, "The content of the modified whitelist cannot be blank")
        if not self.get_tamper_path_find(path_id=path_id, path=path): return public.returnMsg(False,
                                                                                              "The specified target configuration does not exist")

        # 获取目录配置
        config = self.read_config()
        for path_info in config['paths']:
            if "unused_white_dirs" not in path_info:
                path_info["unused_white_dirs"] = []
            if path_id and path_info['pid'] == path_id:
                if release == 1:
                    if dirname not in path_info["white_dirs"]:
                        path_info["white_dirs"].append(dirname)
                    if dirname in path_info["unused_white_dirs"]:
                        path_info["unused_white_dirs"].remove(dirname)
                else:
                    if dirname in path_info["white_dirs"]:
                        path_info["white_dirs"].remove(dirname)
                    if dirname not in path_info["unused_white_dirs"]:
                        path_info["unused_white_dirs"].append(dirname)
            if path and path_info["path"] == path:
                if release == 1:
                    if dirname not in path_info["white_dirs"]:
                        path_info["white_dirs"].append(dirname)
                    if dirname in path_info["unused_white_dirs"]:
                        path_info["unused_white_dirs"].remove(dirname)
                else:
                    if dirname in path_info["white_dirs"]:
                        path_info["white_dirs"].remove(dirname)
                    if dirname not in path_info["unused_white_dirs"]:
                        path_info["unused_white_dirs"].append(dirname)

        self.save_config(config)
        if release == 1:
            action = "allow"
        else:
            action = "not allow"
        if not path:
            path = self.get_tamper_path_find(path_id=path_id)["path"]
        public.WriteLog('Tamper-proof for Enterprise',
                        "{}The specified directory:{}, Whitelist of file types:{}".format(action, path, dirname))
        return public.returnMsg(True, "Success modified")

    def release_white_files(self, args=None, path_id=None, path=None, filename=None, release=None):
        '''
            @name 添加目录白名单
            @author hwliang
            @param args<dict_obj> 外部参数，可以为空
            @param path_id<int> 目录ID
            @param path<string> 目录路径
            @param filename<string> 文件名
            @return dict
        '''
        if args:
            if 'path_id' in args:
                path_id = int(args.get("path_id"))
            if 'path' in args:
                path = args.get("path")
            if 'filename' in args:
                filename = args.get("filename")
            if 'release' in args:
                release = int(args.get("release"))
        if not path_id and not path: return public.returnMsg(False, "Parameter error")
        if not filename: return public.returnMsg(False, "The content of the modified whitelist cannot be blank")
        if not self.get_tamper_path_find(path_id=path_id, path=path): return public.returnMsg(False,
                                                                                              "The specified target configuration does not exist")

        # 获取目录配置
        config = self.read_config()
        for path_info in config['paths']:
            if "unused_white_files" not in path_info:
                path_info["unused_white_files"] = []
            if path_id and path_info['pid'] == path_id:
                if release == 1:
                    if filename not in path_info["white_files"]:
                        path_info["white_files"].append(filename)
                    if filename in path_info["unused_white_files"]:
                        path_info["unused_white_files"].remove(filename)
                else:
                    if filename in path_info["white_files"]:
                        path_info["white_files"].remove(filename)
                    if filename not in path_info["unused_white_files"]:
                        path_info["unused_white_files"].append(filename)
            if path and path_info["path"] == path:
                if release == 1:
                    if filename not in path_info["white_files"]:
                        path_info["white_files"].append(filename)
                    if filename in path_info["unused_white_files"]:
                        path_info["unused_white_files"].remove(filename)
                else:
                    if filename in path_info["white_files"]:
                        path_info["white_files"].remove(filename)
                    if filename not in path_info["unused_white_files"]:
                        path_info["unused_white_files"].append(filename)

        self.save_config(config)
        if release == 1:
            action = "allow"
        else:
            action = "not allow"
        if not path:
            path = self.get_tamper_path_find(path_id=path_id)["path"]
        public.WriteLog('Tamper-proof for Enterprise',
                        "{}The specified directory:{}, the directory whitelist:{}".format(action, path, filename))
        return public.returnMsg(True, "Success modified")

    def release_white_pname(self, args=None, path_id=None, path=None, pname=None, release=None):
        '''
            @name 添加目录白名单
            @param args<dict_obj> 外部参数，可以为空
            @param path_id<int> 目录ID
            @param path<string> 目录路径
            @param pname<string> 文件名
            @return dict
        '''
        if args:
            if 'path_id' in args:
                path_id = int(args.get("path_id"))
            if 'path' in args:
                path = args.get("path")
            if 'pname' in args:
                pname = args.get("pname")
            if 'release' in args:
                release = int(args.get("release"))
        if not path_id and not path: return public.returnMsg(False, "Parameter error")
        if not pname: return public.returnMsg(False, "The content of the modified whitelist cannot be blank")
        if not self.get_tamper_path_find(path_id=path_id, path=path): return public.returnMsg(False,
                                                                                              "The specified target configuration does not exist")

        # 获取目录配置
        config = self.read_config()
        for path_info in config['paths']:
            if "unused_process_names" not in path_info:
                path_info["unused_process_names"] = []
            if path_id and path_info['pid'] == path_id:
                if release == 1:
                    if pname not in path_info["process_names"]:
                        path_info["process_names"].append(pname)
                    if pname in path_info["unused_process_names"]:
                        path_info["unused_process_names"].remove(pname)
                else:
                    if pname in path_info["process_names"]:
                        path_info["process_names"].remove(pname)
                    if pname not in path_info["unused_process_names"]:
                        path_info["unused_process_names"].append(pname)
            if path and path_info["path"] == path:
                if release == 1:
                    if pname not in path_info["process_names"]:
                        path_info["process_names"].append(pname)
                    if pname in path_info["unused_process_names"]:
                        path_info["unused_process_names"].remove(pname)
                else:
                    if pname in path_info["process_names"]:
                        path_info["process_names"].remove(pname)
                    if pname not in path_info["unused_process_names"]:
                        path_info["unused_process_names"].append(pname)

        self.save_config(config)
        if release == 1:
            action = "allow"
        else:
            action = "not allow"
        if path == None:
            path = self.get_tamper_path_find(path_id=path_id)["path"]
        public.WriteLog('Tamper-proof for Enterprise',
                        "{}The specified directory:{}, process whitelist:{}".format(action, path, pname))
        return public.returnMsg(True, "Success modified")

    def get_tamper_rule_by_path(self, args=None, path=None):
        '''
            @name 设置临时白名单
            @param args<dict_obj> 外部参数，可以为空
            @param path<string> 目录路径
            @return dict
        '''
        if args:
            if 'path' in args:
                path = args.get("path")
        if path[-1] != '/':
            path += '/'
        res = self.get_tamper_path_find(path_id=None, path=path)
        if res is None:
            return {}
        backtrack_config_file = public.get_panel_path() + "/data/tamper_backtrack.json"
        if not os.path.exists(backtrack_config_file):
            backtrack_config = {}
        else:
            backtrack_config = public.readFile(backtrack_config_file)
            if backtrack_config is False:
                backtrack_config = {}
            else:
                try:
                    backtrack_config = json.loads(backtrack_config)
                except json.JSONDecodeError:
                    backtrack_config = {}

        res["temporarily_dirs"] = []
        res["temporarily_files"] = []
        if str(res['pid']) not in backtrack_config:
            return res

        for conf in backtrack_config[str(res['pid'])]:
            if conf['change_type'] == "dir":
                res["temporarily_dirs"].append(conf)
            else:
                res["temporarily_files"].append(conf)

        return res

    def get_path_total(self, args=None, path_id=None):
        '''
            @name 获取目录统计
            @author hwliang
            @param path_id<int> 目录ID
            @return dict
        '''
        if args:
            if 'path_id' in args: path_id = int(args.get("path_id"))

        if path_id == None: return public.returnMsg(False, "Parameter error")
        total_all_file = "{}/{}/total.json".format(self.__total_path, path_id)
        total = {}
        default_total = {
            "create": 0, "modify": 0,
            "unlink": 0, "rename": 0,
            "mkdir": 0, "rmdir": 0,
            "chmod": 0, "chown": 0,
            "link": 0
        }

        total['all'] = default_total

        _all = public.readFile(total_all_file)
        if _all: total['all'] = json.loads(_all)
        total['today'] = default_total
        total_today_file = "{}/{}/{}.json".format(self.__total_path, path_id, public.format_date("%Y-%m-%d"))
        _today = public.readFile(total_today_file)
        if _today:
            _today = json.loads(_today)
            for k in _today.keys():
                total['today']['create'] += _today[k]['create']
                total['today']['modify'] += _today[k]['modify']
                total['today']['unlink'] += _today[k]['unlink']
                total['today']['rename'] += _today[k]['rename']
                total['today']['mkdir'] += _today[k]['mkdir']
                total['today']['rmdir'] += _today[k]['rmdir']
                total['today']['chmod'] += _today[k]['chmod']
                total['today']['chown'] += _today[k]['chown']
                total['today']['link'] += _today[k]['link']
        return total

    def get_path_total_list(self, args=None, path_id=None):
        '''
            @name 获取所有目录统计
            @author hwliang
            @param path_id<int> 目录ID
            @return list
        '''
        if args:
            if 'path_id' in args: path_id = int(args.get("path_id"))
        total_path = "{}/{}".format(self.__total_path, path_id)
        if not os.path.exists(total_path): return []
        total_all = []
        day_files = []
        for day_name in os.listdir(total_path):
            if day_name in ['total.json']: continue
            day_file = "{}/{}".format(total_path, day_name)
            if not os.path.exists(day_file): continue
            day_files.append(day_name.strip('.json'))

        for day_name in sorted(day_files, reverse=False):
            day_file = "{}/{}.json".format(total_path, day_name)
            _day = json.loads(public.readFile(day_file))
            for k in sorted(_day.keys()):
                _tmp = _day[k]
                _tmp['date_hour'] = "{}_{}".format(day_name, k)
                total_all.append(_tmp)

        return total_all

    def get_glabal_total(self, args=None):
        '''
            @name 获取全局统计
            @author hwliang
            @return dict
        '''

        ###验证，放插件入口
        #ret = self.get_tamper_core()
        #if ret == 0:
            #return public.returnMsg(False, 'Expired or authorization terminated')

        result = {}
        total_all_file = "{}/total.json".format(self.__total_path)
        total = {
            "create": 0, "modify": 0, "unlink": 0, "rename": 0, "mkdir": 0,
            "rmdir": 0, "chmod": 0, "chown": 0, "link": 0, "warning_msg": 0
        }
        _all = public.readFile(total_all_file)
        if _all: total = json.loads(_all)
        if "warning_msg" not in total:
            total["warning_msg"] = 0
        result["glabal"] = total
        details = []
        config = self.read_config()
        for i in config["paths"]:
            _tmp = self.get_path_total(path_id=i["pid"])
            _tmp.update(pid=i["pid"], path=i["path"])
            details.append(_tmp)
        result["details"] = details
        glabal_today = {}
        for i in details:
            for k, v in i["today"].items():
                if k not in glabal_today:
                    glabal_today[k] = v
                else:
                    glabal_today[k] += v
        result["glabal_today"] = glabal_today
        glabal_status = self.get_service_status()
        glabal_status.update(settings_status=bool(config["status"]))
        result["glabal_status"] = glabal_status
        result["days"] = self._get_use_day()

        s_time = time.time()
        if self.get_temp_close() < s_time:
            filename = "{}/close_temp.pl".format(self.__tamper_path)
            public.writeFile(filename, '0')

        result['temp_close_time'] = self.get_temp_close()

        return result

    def mod_exists(self):
        '''
            @name 检测内核模块是否加载成功
            @return bool
        '''
        proc_mod_file = "/proc/modules"
        if not os.path.exists(proc_mod_file):
            return not public.ExecShell("lsmod|grep tampercore")[0].strip() == ""
        mod_list = public.readFile(proc_mod_file)
        if not mod_list:
            return not public.ExecShell("lsmod|grep tampercore")[0].strip() == ""
        return mod_list.find("tampercore") != -1

    def tamperuser_process_exists(self):
        '''
            @name 检测控制器是否启动
            @return bool
        '''
        import psutil
        for proc in psutil.process_iter():
            try:
                pinfo = proc.as_dict(attrs=['pid', 'name'])
                if pinfo['name'] == 'tamperuser':
                    return True
            except psutil.NoSuchProcess:
                pass
        return False

    def get_service_status(self, args=None):
        '''
            @name 获取服务状态
            @author hwliang
            @return dict  kernel_module_status=内核驱动加载状态，controller_status=控制器状态
        '''
        result = {}
        result['kernel_module_status'] = self.mod_exists()
        result['controller_status'] = self.tamperuser_process_exists()
        return result

    def service_admin(self, args=None, action=None):
        '''
            @name 服务管理
            @author hwliang
            @param action<str> 动作 start|stop|restart|reload
        '''

        if args:
            if 'action' in args: action = args.get("action")
        if not action in ['stop', 'reload', 'start', 'restart']:
            return public.returnMsg(False, 'Unsupported operation parameter')

        res = public.ExecShell("/etc/init.d/bt-tamper {}".format(action))[0]

        _tip = """The current kernel version is inconsistent, please try to update the system to obtain the kernel version, the specific operation is as follows:<br><b>1</b>.&nbsp Make <b>snapshot or backup</b> for your server to prevent Mistakes in the process of updating the system, resulting in irreparable losses. <br>
<b>2</b>.&nbsp Execute the command to update the server<br>&nbsp&nbsp&nbsp&nbsp If your server system type is Redhat, such as Redhat, Centos, Fedora, etc., you can execute<br> <code>yum update</code > to update.<br>
&nbsp&nbsp&nbsp&nbsp If your server system type is Debian, mainly including Debian, Ubuntu, Mint, etc., you can first execute <code>apt-get update -y</code> to update the management tool, and then execute <code>apt-get upgrade -y</code>update system<br>
<b>3</b>.&nbsp<b>Restart the server</b>, reinstall Tamper-proof for Enterprise
        """

        msg_status = {"stop": "Stop", "reload": "Reload", "start": "Start", "restart": "Restart"}
        if action != 'stop':
            status_msg = self.get_service_status()
            if not status_msg['kernel_module_status']:
                if res.find("Inconsistent kernel version") != -1:
                    return {"status": False, "tip": _tip, "msg": _tip}
                return public.returnMsg(False, _tip)
            if not status_msg['controller_status']:
                return public.returnMsg(False, 'Controller failed to start')
        public.WriteLog('Tamper-proof for Enterprise',
                        'Tamper-proof for Enterprise service has been {}'.format(msg_status[action]))
        return public.returnMsg(True, 'Tamper-proof for Enterprise service has been {}'.format(msg_status[action]))

    # —————————————————————
    #  融合到文件目录系统  |
    # —————————————————————

    def check_dir_safe(self, args=None, file_data=None):
        """ 融合到文件目录系统， 查看文件是否安全
        @author baozi <202-03-1>
        @param:
            file_data ( dict ) : 包含 1.base_path 查询目录的父级目录的绝对路径, 2.dirs 文件夹的名称列表, 3.files 文件的名称列表
        @return ( dict )  是否被保护 (1.dirs 文件夹的名称列表, 2. files 文件的名称列表， 3. rules保护规则
        """
        res = {"this": "", "dirs": [], "files": [], "rules": [], "status": True, "tip": "ok"}
        status = self.get_service_status()
        if not (status["kernel_module_status"] and status["controller_status"]):
            res["status"], res["tip"] = False, "Kernel module loading failed"
            return res
        if args:
            if 'file_data' in args: file_data = args.get("file_data")
        if not file_data:
            res["status"], res["tip"] = False, "No file information"
            return res
        config = self.read_config()
        if config["status"] != 1:
            res["status"], res[
                "tip"] = False, "The global setting is turn off and can only be detected after it is turn on"
            return res

        # 构建查询tree
        root, rules = self._build_dict_tree(config)

        # 移除软链接
        file_data["base_path"] = os.path.realpath(file_data["base_path"])

        # 路径查询
        node = root
        use_rule = set()
        target_pid = 0
        target_status = False
        base_path_list = file_data["base_path"].split("/")[1:]
        for i, p in enumerate(base_path_list):
            if not node["children"]:
                break
            if p not in node["children"]:
                break
            node = node["children"][p]
            if node["pid"] != target_pid:
                target_pid = node["pid"]
                target_status = bool(node["status"])

        # 本层是否已被排除
        this_is_white = False
        if target_pid != 0:
            rule = rules[target_pid]
            if self._check_white_dirs(file_data["base_path"] + "/", rule["white_dirs"], rule_path=rule["path"]):
                this_is_white = True
                res["this"] = "0;" + str(target_pid)
            else:
                res["this"] = "1;" + str(target_pid)
        else:
            res["this"] = "0;0"

        for i in file_data["dirs"]:
            _path = file_data["base_path"] + "/" + i + "/"
            # 本层的下级文件夹是否运用其他规则
            if node["children"] and i in node["children"] and node["children"][i]["pid"] != node["pid"]:
                _rule = rules[node["children"][i]["pid"]]
                safe = not self._check_white_dirs(_path, _rule["white_dirs"], rule_path=_rule["path"]) and bool(
                    _rule["status"])
                res["dirs"].append("{};{}".format(int(safe), node["children"][i]["pid"]))
                use_rule.add(node["children"][i]["pid"])
                continue
            if this_is_white:
                res["dirs"].append("0;{}".format(target_pid))
            else:
                safe = not self._check_white_dirs(_path, rules[target_pid]["white_dirs"],
                                                  rule_path=rules[target_pid]["path"]) if target_pid != 0 else False
                safe = safe and target_status
                res["dirs"].append("{};{}".format(int(safe), target_pid))

        for i in file_data["files"]:
            file_path = file_data["base_path"] + "/" + i
            if target_pid == 0 or this_is_white:
                res["files"].append("0;{}".format(target_pid))
                continue
            if target_pid != 0:
                safe = False
                if self._check_ext(file_path, rules[target_pid]["black_exts"], rule_path=rules[target_pid]["path"]):
                    safe = not self._check_white_files(file_path, rules[target_pid]["white_files"],
                                                       rule_path=rules[target_pid]["path"])

                safe = safe and bool(target_status)
                res["files"].append("{};{}".format(int(safe), target_pid))

        if target_pid != 0:
            use_rule.add(target_pid)

        for i in use_rule:
            res["rules"].append(rules[i])

        return res

    # 构建查询tree
    def _build_dict_tree(self, config):
        rules = {}
        root = {"pid": 0, "status": 0, "children": {}}
        for i in config["paths"]:
            rules[i["pid"]] = i
            path_list = i["path"].strip("/").split("/")
            node = root
            for j in path_list:
                if j not in node["children"]:
                    node["children"][j] = {"pid": node["pid"], "status": node["status"], "children": {}}
                node = node["children"][j]
            node["pid"] = i["pid"]
            node["status"] = i["status"]

        return root, rules

    def _check_white_dirs(self, dir_path, white_dirs, rule_path=None):
        res = []
        for i in white_dirs:
            test = i
            if rule_path is not None:
                if test[0:2] == "./":
                    test = rule_path + test[2:]
            regx = self._get_regx(test)
            if regx.search(dir_path):
                res.append(i)
            # if test[0] != "/" and test[-1] == "/":
            #     if dir_path.find("/" + test) != -1:
            #         res.append(test)
            # else:
            #     if dir_path.find(test) != -1:
            #         res.append(test)
        return res

    def _check_ext(self, file_path, black_exts, rule_path=None):
        res = []
        for i in black_exts:
            test = i
            if rule_path is not None:
                if test[0:2] == "./":
                    test = rule_path + test[2:]
            regx = self._get_regx(test, is_end=True)
            if regx.search(file_path):
                res.append(i)
            # if test[0] == ".":
            #     if file_path.endswith(i):
            #         res.append(i)
            # else:
            #     _black = "/" + test if test[0] != "/" else test
            #     if file_path.endswith(_black):
            #         res.append(i)

        return res

    def _check_white_files(self, file_path, white_files, rule_path=None):
        res = []
        for i in white_files:
            test = i
            if rule_path is not None:
                if test[0:2] == "./":
                    test = rule_path + test[2:]
            regx = self._get_regx(test, is_end=True)
            if regx.search(file_path):
                res.append(i)
            # if test[0] == "/":
            #     if file_path.startswith(i):
            #         res.append(i)
            # else:
            #     if file_path.endswith("/" + i):
            #         res.append(i)
        return res

    @staticmethod
    def _get_regx(r_str: str, is_start=False, is_end=False):
        re_char = ['$', '(', ')', '+', '.', '[', ']', '{', '}', '?', '^', '|', '\\']
        res_list = []
        i, n = 0, len(r_str)
        while i < n:
            if r_str[i] == "*":
                i += 1
                res_list.append(".*")
                while i < n and r_str[i] == "*":
                    i += 1
            elif r_str[i] in re_char:
                res_list.append("\\" + r_str[i])
                i += 1
            else:
                res_list.append(r_str[i])
                i += 1
        p_str = "".join(res_list)
        if is_start:
            p_str = "^" + p_str
        if is_end:
            p_str = p_str + "$"

        return re.compile(p_str)

    def _check_tamper_system(self, res):
        status = self.get_service_status()
        if not status["kernel_module_status"] or not status["controller_status"]:
            res["status"], res["msg"] = False, "The service is not started or there is problem with the kernel"
            res["kernel_module_status"] = status["kernel_module_status"]
            res["controller_status"] = status["controller_status"]
            return False, res
        config = self.read_config()
        if config["status"] != 1:
            res["status"], res["msg"] = False, "The global setting is turn off and can only be detected after it is turn on"
            return False, res

        return True, config

    def _test_bool_parameter(self, pm, default):
        if pm in ("False", "false", 0, "0", None, "null", "FALSE", False):
            return False
        if pm in ("True", "true", 1, "1", "TRUE", True):
            return True
        return default

    def _create_path_config(self, path, **kwargs):
        # 路径标准化处理
        if path[-1] != "/": path += "/"
        path = os.path.realpath(path.replace('//', '/'))

        # 参数过滤
        if not path: return public.returnMsg(False, "Directory path cannot be empty")
        if not os.path.exists(path) or os.path.isfile(path): return public.returnMsg(False,
                                                                                     "invalid directory: {}".format(
                                                                                         path))
        if self.get_tamper_path_find(path=path): return public.returnMsg(False,
                                                                         "The specified directory has already been added: {}".format(
                                                                             path))

        # 关键路径过滤
        if path in ['/', '/root/', '/boot/', '/www/', '/www/server/', '/www/server/panel/', '/www/server/panel/class/',
                    '/usr/', '/etc/', '/usr/bin/', '/usr/sbin/']:
            return public.returnMsg(False, "Cannot add system directory: {}".format(path))

        config = self.read_config()
        path_info = {
            "pid": self.get_path_id(config["paths"]),
            "path": path,
            "status": 1,
            "mode": 0,
            "is_create": 1,
            "is_modify": 1,
            "is_unlink": 1,
            "is_mkdir": 1,
            "is_rmdir": 1,
            "is_rename": 1,
            "is_chmod": 1,
            "is_chown": 1,
            "is_link": 1,
            "black_exts": kwargs["black_exts"] if "black_exts" in kwargs else config["default_black_exts"],
            "white_files": kwargs["white_files"] if "white_files" in kwargs else config["default_white_files"],
            "white_dirs": kwargs["white_dirs"] if "white_dirs" in kwargs else config["default_white_dirs"],
            "ps": ""
        }

        # 添加到配置列表
        config["paths"].append(path_info)
        config["dir_ps_" + str(path_info["pid"])] = {}
        self.save_config(config)
        public.WriteLog('Tamper-proof for Enterprise', "Add directory config: {}".format(path))
        return {"status": True, "msg": "Add directory successfully", "rule": path_info}

    def quick_lock_file(self, args=None, file_path=None, same_type=False, forcible=False):
        """ 融合到文件目录系统， 快速锁定文件
        @author baozi <202-03-6>
        @param:
            file_path ( dict ) : 文件所在位置
        @return ( dict )

        √ : 遇到多重白名单？ 最多两层， 可以同时移除
        """
        res = {"status": True, "tip": "ok"}
        flag, config = self._check_tamper_system(res)
        if not flag:
            return config
        if args:
            if 'file_path' in args: file_path = args.get("file_path")
            if 'forcible' in args: forcible = self._test_bool_parameter(args.get("forcible"), forcible)
            if 'same_type' in args: same_type = self._test_bool_parameter(args.get("same_type"), same_type)

        if not file_path or not os.path.isfile(file_path):
            res["status"], res["tip"] = False, "No file information"
            return res

        # 去除软连接
        file_path = os.path.realpath(file_path)

        # 构建查询tree
        root, rules = self._build_dict_tree(config)

        node = root
        target_pid = 0
        target_status = False
        path_list = file_path.split("/")[1:-1]
        for p in path_list:
            if not node["children"]:
                break
            if p not in node["children"]:
                break
            node = node["children"][p]
            if node["pid"] != target_pid:
                target_pid = node["pid"]
                target_status = bool(node["status"])

        if target_pid == 0:
            # 自身没有规则，创建一个快锁规则
            # 路径标准化处理
            path, file_name = file_path.rsplit("/", 1)
            _ext = "." + file_name.rsplit(".")[1] if "." in file_name else file_name
            black_exts = [file_path, ] if not same_type else [_ext, ]

            return self._create_path_config(path, black_exts=black_exts, white_files=[], white_dirs=[])

        # 规则未开启
        if not target_status:
            return public.returnMsg(False, "Anti-tampering rules already exist under this path, but they are not enabled for use. Please open them and try to modify them again.")
        # 检查这个文件已经被锁定 则无法操作，返回错误
        # 未被锁定
        # 1. 规则已开启，不在保护对象中              ————>     定点添加保护 或 批量添加保护
        # 2. 规则已开启，在保护对象中，但被文件白名单排除 ————>     1.白名单中定点移除，则取消移除   2.白名单规则批量移除的，且用户未选择作用于所有同类文件，则不支持快锁
        # 2. 规则已开启，在保护对象中，但被文件夹白名单排除 ————>     1.规则根目录不在本层，新建一个规则保护， 2.规则根目录在本层，需改这个规则，使之符合要求（这种情况说明原规则未起到任何作用），
        # 3. 规则未开启                            ————>     不支持快锁，请用户手动修改状态

        rule = rules[target_pid]
        path, file_name = file_path.rsplit("/", 1)
        if self._check_white_dirs(path + "/", rule["white_dirs"], rule_path=rule["path"]):
            _ext = "." + file_name.rsplit(".")[1] if "." in file_name else file_name
            black_exts = [file_path, ] if not same_type else [_ext, ]
            if path + "/" == rule["path"]:
                rule["black_exts"] = black_exts
                rule["white_files"] = []
                rule["white_dirs"] = []
                public.WriteLog('Tamper-proof for Enterprise',
                                "Quick lock function to modify the directory: {}, the protected suffix name is: {}, and clears the whitelist files and whitelist directory.".format(
                                    rule["path"], black_exts))

                for i, p in enumerate(config["paths"]):
                    if p["pid"] == target_pid:
                        config["paths"][i] = rule

                self.save_config(config)
                return public.returnMsg(True, "Success modified")
            else:
                return self._create_path_config(path, black_exts=black_exts, white_files=[], white_dirs=[])

        if self._check_ext(file_path, rule["black_exts"], rule_path=rule["path"]) and not self._check_white_files(
                file_path, rule["white_files"], rule_path=rule["path"]):
            return public.returnMsg(False, "This file is protected and does not need to be modified")

        if not self._check_ext(file_path, rule["black_exts"], rule_path=rule["path"]):
            _ext = "." + file_name.rsplit(".")[1] if "." in file_name else file_name
            black_ext = file_path if not same_type else _ext
            rule["black_exts"].append(black_ext)
            public.WriteLog('Tamper-proof for Enterprise',
                            "Quick lock function add directory: {}, the protected suffix name: {}".format(rule["path"],
                                                                                                          black_ext))

        if self._check_white_files(file_path, rule["white_files"], rule_path=rule["path"]):
            if not forcible:
                if not file_path in rule["white_files"]:
                    return {"status": False,
                            "msg": "This file is file unlocked by whitelist rules in batches. Enforcement will remove these whitelist rules, but may affect the status of other files at the same time.",
                            "white_files": self._check_white_files(file_path, rule["white_files"],
                                                                   rule_path=rule["path"])}
            if forcible:
                if file_name in rule["white_files"]:
                    rule["white_files"].remove(file_name)
                    public.WriteLog('Tamper-proof for Enterprise',
                                    "Quick lock function forcibly removes the directory: {}, the file whitelist: {}".format(
                                        rule["path"], file_name))

            if file_path in rule["white_files"]:
                rule["white_files"].remove(file_path)
                public.WriteLog('Tamper-proof for Enterprise',
                                "Quick lock function removes the directory: {}, the file whitelist: {}".format(
                                    rule["path"], file_path))

        for i, p in enumerate(config["paths"]):
            if p["pid"] == target_pid:
                config["paths"][i] = rule

        self.save_config(config)

        return public.returnMsg(True, "Success modified")

    def quick_unlock_file(self, args=None, file_path=None, same_type=False, forcible=False):
        """ 融合到文件目录系统， 快速解锁文件
        @author baozi <202-03-6>
        @param:
            file_path ( dict ) : 文件所在位置
        @return ( dict )
        ? : 遇到多重锁定
        """
        # 检查这个文件未被锁定 则无法操作，返回错误
        # 已被锁定，规则已开启，在保护对象中
        # 1. 属于定点添加保护                       ————>     移除添加的保护
        # 2. 属于规则范围内的保护对象                ————>     通过白名单中定点移除，取消保护
        res = {"status": True, "msg": "ok"}
        flag, config = self._check_tamper_system(res)
        if not flag:
            return config
        if args:
            if 'file_path' in args: file_path = args.get("file_path")
            if 'same_type' in args: same_type = self._test_bool_parameter(args.get("same_type"), same_type)
        if not file_path or not os.path.isfile(file_path):
            res["status"], res["msg"] = False, "No file information"
            return res

        # 去除软连接
        file_path = os.path.realpath(file_path)

        # 构建查询tree
        root, rules = self._build_dict_tree(config)

        node = root
        target_pid = 0
        target_status = False
        path_list = file_path.split("/")[1:-1]
        for p in path_list:
            if not node["children"]:
                break
            if p not in node["children"]:
                break
            node = node["children"][p]
            if node["pid"] != target_pid:
                target_pid = node["pid"]
                target_status = bool(node["status"])

        if target_pid == 0 or not target_status:
            return public.returnMsg(False, "The file is not protected and cannot be unprotected")

        rule = rules[target_pid]
        path, file_name = file_path.rsplit("/", 1)
        if self._check_white_dirs(path + "/", rule["white_dirs"], rule_path=rule["path"]):
            return public.returnMsg(False, "The file is not protected and cannot be unprotected")

        if self._check_ext(file_path, rule["black_exts"], rule_path=rule["path"]) and not self._check_white_files(
                file_path, rule["white_files"], rule_path=rule["path"]):
            if file_path in rule["black_exts"]:
                rule["black_exts"].remove(file_path)
                public.WriteLog('Tamper-proof for Enterprise',
                                "Quick lock function removes the directory: {}, the protected suffix name: {}".format(
                                    rule["path"], file_path))
            else:
                rule["white_files"].append(file_path)
                public.WriteLog('Tamper-proof for Enterprise',
                                "Quick lock function adds the directory: {}, the file whitelist: {}".format(
                                    rule["path"], file_path))
            if same_type:
                file_name = file_path.rsplit("/", 1)[1]
                _ext = "." + file_name.rsplit(".")[1] if "." in file_name else file_name
                if _ext in rule["black_exts"]:
                    rule["black_exts"].remove(_ext)
                    public.WriteLog('Tamper-proof for Enterprise',
                                    "Quick lock function removes the directory: {}, the protected suffix name: {}".format(
                                        rule["path"], _ext))
        else:
            return public.returnMsg(False, "The file is not protected and cannot be unprotected")

        for i, p in enumerate(config["paths"]):
            if p["pid"] == target_pid:
                config["paths"][i] = rule

        self.save_config(config)

        return public.returnMsg(True, "Success modified")

    def quick_lock_dir(self, args=None, dir_path=None, forcible=False):
        """ 融合到文件目录系统， 快速锁定文件夹（目录）
        @author baozi <202-03-6>
        @param:
            file_path ( dict ) : 文件所在位置
        @return ( dict )
        """
        res = {"status": True, "tip": "ok"}
        flag, config = self._check_tamper_system(res)
        if not flag:
            return config
        if args:
            if 'dir_path' in args: dir_path = args.get("dir_path")
            if 'forcible' in args: forcible = self._test_bool_parameter(args.get("forcible"), forcible)

        if not dir_path or not os.path.exists(dir_path):
            res["status"], res["tip"] = False, "No file information"
            return res
        if dir_path[-1] != "/": dir_path += "/"

        # 去除软连接
        dir_path = os.path.realpath(dir_path)

        # 构建查询tree
        root, rules = self._build_dict_tree(config)
        node = root
        target_pid = 0
        target_status = False
        path_list = dir_path.split("/")[1:-1]
        for p in path_list:
            if not node["children"]:
                break
            if p not in node["children"]:
                break
            node = node["children"][p]
            if node["pid"] != target_pid:
                target_pid = node["pid"]
                target_status = bool(node["status"])

        # 自身没有规则 -> 创建一个快锁规则
        # 如果有规则, 规则未开启,且规则根路径为本文件夹路径-> 开启该文件目录锁对应的规则

        # 如果有规则, 规则未开启,但规则根路径不是本文件夹路径-> 创建一个快锁规则

        # 如路径被白名单定点排除，则移除该白名单项
        # 如果路径属于被白名单规则批量移除，则需要用户选择强制执行，移除受限白名单
        if target_pid == 0:
            return self._create_path_config(dir_path)
        rule = rules[target_pid]
        if not target_status:
            if dir_path == rule["path"]:
                rule["status"] = 1
            else:
                return self._create_path_config(dir_path)

        if self._check_white_dirs(dir_path, rule["white_dirs"], rule_path=rule["path"]):
            if dir_path in rule["white_dirs"]:
                rule["white_dirs"].remove(dir_path)
                public.WriteLog('Tamper-proof for Enterprise',
                                "Quick lock function deletes the directory: {}, the directory whitelist: {}".format(
                                    rule["path"], dir_path))

        else:
            return public.returnMsg(False, "The file path is protected and cannot be operated")

        res = self._check_white_dirs(dir_path, rule["white_dirs"], rule_path=rule["path"])
        if res:
            if not forcible:
                return {"status": False,
                        "msg": "The file path is batch unlocked by whitelist batch rules, and enforcement will remove these whitelist tables, which may affect the status of other files!",
                        "white_dirs": res}
            for i in res:
                rule["white_dirs"].remove(i)
                public.WriteLog('Tamper-proof for Enterprise',
                                "Quick lock function forcefully deletes the directory: {}, the directory whitelist: {}".format(
                                    rule["path"], i))

        for i, p in enumerate(config["paths"]):
            if p["pid"] == target_pid:
                config["paths"][i] = rule

        self.save_config(config)

        return public.returnMsg(True, "Success modified")

    def quick_unlock_dir(self, args=None, dir_path=None):
        """ 融合到文件目录系统， 快速解锁定文件夹（目录）
        @author baozi <202-03-6>
        @param:
            file_path ( dict ) : 文件所在位置
        @return ( dict )
        """
        res = {"status": True, "tip": "ok"}
        flag, config = self._check_tamper_system(res)
        if not flag:
            return config
        if args:
            if 'dir_path' in args: dir_path = args.get("dir_path")

        if not dir_path or not os.path.exists(dir_path):
            res["status"], res["tip"] = False, "No file information"
            return res
        if dir_path[-1] != "/": dir_path += "/"

        # 去除软连接
        dir_path = os.path.realpath(dir_path)

        # 构建查询tree
        root, rules = self._build_dict_tree(config)
        node = root
        target_pid = 0
        target_status = False
        path_list = dir_path.split("/")[1:-1]
        for p in path_list:
            if not node["children"]:
                break
            if p not in node["children"]:
                break
            node = node["children"][p]
            if node["pid"] != target_pid:
                target_pid = node["pid"]
                target_status = bool(node["status"])

        # 自身没有规则 或未开启 -> 返回错误
        # 如果有规则, 规则已开启,且规则根路径为本文件夹路径-> 关闭该文件目录锁对应的规则
        # 白名单添加定点排除
        if target_pid == 0:
            return public.returnMsg(False, "The file path is not protected and cannot be operated")
        rule = rules[target_pid]
        if target_status:
            if dir_path == rule["path"]:
                rule["status"] = 0
        else:
            return public.returnMsg(False, "The file path is not protected and cannot be operated")

        if not self._check_white_dirs(dir_path, rule["white_dirs"], rule_path=rule["path"]):
            rule["white_dirs"].append(dir_path)
            public.WriteLog('Tamper-proof for Enterprise',
                            "Quick lock function add directory: {}, the directory whitelist: {}".format(rule["path"],
                                                                                                        dir_path))
        else:
            return public.returnMsg(False, "The file path is not protected and cannot be operated")

        for i, p in enumerate(config["paths"]):
            if p["pid"] == target_pid:
                config["paths"][i] = rule

        self.save_config(config)

        return public.returnMsg(True, "Success modified")

    def get_backtrack_image(self, args=None):
        """获取防篡改任务
        @author baozi <202-03-11>
        @param:
        @return
        """
        backtrack_path = public.get_panel_path() + "/data/crontab"
        file_path = backtrack_path + "/tamper_image.json"
        if os.path.exists(file_path) and os.path.isfile(file_path):
            tasks = json.loads(public.readFile(file_path))
            task_file = tasks["task"]
            if os.path.exists(task_file):
                return {"status": True, "time": tasks["time"]}

        return {"status": False, "tip": "No backtracking tasks"}

    def make_backtrack_image(self, args=None, time_congfig=None, forcible=False):
        """ 设置防篡改任务
        @author baozi <202-03-6>
        @param:
            file_path ( dict ) : 文件所在位置
        @return ( dict )
        """
        backtrack_path = public.get_panel_path() + "/data/crontab"
        file_path = backtrack_path + "/tamper_image.json"
        if args:
            if 'time_congfig' in args: time_congfig = args.get("time_congfig")
            if 'forcible' in args: forcible = self._test_bool_parameter(args.get("forcible"), False)
        if isinstance(time_congfig, str):
            time_congfig = json.loads(time_congfig)
        if not os.path.exists(backtrack_path):
            os.makedirs(backtrack_path, mode=0o600)
        if os.path.exists(file_path) and os.path.isfile(file_path):
            task_file = json.loads(public.readFile(file_path))["task"]
            if os.path.exists(task_file):
                if not forcible:
                    return public.returnMsg(False,
                                            "Only one lookback setting can exist, is it mandatory to replace the previous setting?")
                else:
                    public.WriteLog('Tamper-proof for Enterprise', "Backtracking task removed successfully")
                    os.remove(task_file)

        set_type = "delay" if "type" in time_congfig and time_congfig["type"] in ("delay", "date") else time_congfig[
            "type"]
        if set_type == "delay":
            try:
                h = int(time_congfig.get("hour"))
                m = int(time_congfig.get("minute"))
                if not 0 <= m <= 60: raise ValueError
            except ValueError:
                return public.returnMsg(False, "Wrong time setting")
            _time = (datetime.datetime.now() + datetime.timedelta(hours=h, minutes=m)).timestamp()
        else:
            try:

                _time = datetime.datetime.fromtimestamp(float(time_congfig.get("time"))).timestamp()
            except ValueError:
                return public.returnMsg(False, "Wrong time setting")
            except OSError:
                try:
                    _time = datetime.datetime.fromtimestamp(float(time_congfig.get("time")) / 1000).timestamp()
                except:
                    return public.returnMsg(False, "Wrong time setting")

        config_data = {
            "time": int(_time),
            "type": 2,
            "name": "tamper_core",
            "fun": "task_callback",
            "args": {}
        }

        res = public.set_tasks_run(config_data)
        if not res["status"]:
            return public.returnMsg(False, "Backtrace task setup failed")

        task = res["msg"]
        task_run_data = json.dumps({
            "task": task,
            "config": self.read_config(),
            "time": int(_time)
        })
        public.writeFile(file_path, task_run_data)
        public.WriteLog('Tamper-proof for Enterprise',
                        "Backtracking task is set successfully, and the estimated backtracking time：{}".format(
                            time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(int(_time)))))

        return public.returnMsg(False, "successfully set")

    def remove_backtrack_image(self, args=None):
        """移除防篡改回溯任务
        @author baozi <202-03-11>
        @param:
        @return
        """
        backtrack_path = public.get_panel_path() + "/data/crontab"
        file_path = backtrack_path + "/tamper_image.json"
        if os.path.exists(file_path) and os.path.isfile(file_path):
            tasks = json.loads(public.readFile(file_path))
            task_file = tasks["task"]
            if os.path.exists(task_file):
                os.remove(task_file)
                public.WriteLog('Tamper-proof for Enterprise', "Backtracking task removed successfully")
                return {"status": True, "tip": "Backtracking task removed successfully"}

        return {"status": False, "tip": "No backtracking tasks"}

    def task_callback(self, args):
        """ 用于回调，修改防篡改中的设置
        @author baozi <202-03-6>
        @param:
            file_path ( dict ) : 文件所在位置
        @return ( dict )
        """
        run_time = public.format_date()
        log_msg = "Callback operation (execution time:{}):\n".format(run_time)
        status = self.get_service_status()
        if not (status["kernel_module_status"] and status["controller_status"]):
            log_msg += "\tKernel module loading failed\n"
        config = self.read_config()
        if config["status"] != 1:
            log_msg += "\tThe global setting is turn off, and the setting will take effect only after it is turn on\n"

        backtrack_path = public.get_panel_path() + "/data/crontab"
        file_path = backtrack_path + "/tamper_image.json"
        if not os.path.exists(backtrack_path):
            os.makedirs(backtrack_path, mode=0o600)
            log_msg += "\tThe snapshot file is lost, and the backtracking failed"
            public.WriteLog('Tamper-proof for Enterprise', log_msg)
            return public.returnMsg(False,
                                    "Tamper-proof backtracking: The snapshot file is lost, and the backtracking failed!")

        if not (os.path.exists(file_path) and os.path.isfile(file_path)):
            log_msg += "\tThe snapshot file is lost, and the backtracking failed"
            public.WriteLog('Tamper-proof for Enterprise', log_msg)
            return public.returnMsg(False,
                                    "Tamper-proof for Enterprise backtracking: The snapshot file is lost, and the backtracking failed!")

        try:
            task_run_data = json.loads(public.readFile(file_path))
            conf = task_run_data["config"]
        except:
            log_msg += "\tThe snapshot file is suspected to have been modified and cannot be read, and the backtracking failed"
            public.WriteLog('Tamper-proof for Enterprise', log_msg)
            return public.returnMsg(False,
                                    "Tamper-proof for Enterprise backtracking: The snapshot file is suspected to have been modified and cannot be read, and the backtracking failed")
        self.save_config(conf)
        log_msg += "\tTamper-proof for Enterprise configuration file restored successfully"
        os.remove(file_path)
        public.WriteLog('Tamper-proof for Enterprise', log_msg)
        return public.returnMsg(True,
                                "Tamper-proof for Enterprise backtracking: configuration file restored successfully")

    def get_effective_path(self, args=None, path=None):
        """查询路径生效的方式
        @author baozi <202-03-11>
        @param:
        @return  dict :  状态和生效条件
        """
        res = {"status": True, "tip": "ok"}
        flag, config = self._check_tamper_system(res)
        if not flag:
            config["tip"] = config.pop("msg")
            return config
        if args:
            if 'path' in args: path = args.get("path")
            # if 'next_state' in args: next_state = self._test_bool_parameter(args.get("next_state"))

        # 去除软连接
        path = os.path.realpath(path)

        public.set_module_logs('tamper_core', 'get_effective_path')
        if not path or not os.path.exists(path):
            res["status"], res["tip"] = False, "No file information"
            return res

        if path[-1] == "/": path = path[:-1]
        file, dir_path = None, path
        if os.path.isfile(dir_path):
            dir_path, file = path.rsplit("/", 1)

        # 构建查询tree
        root, rules = self._build_dict_tree(config)

        # 路径查询
        node = root
        target_pid = 0
        target_status = False
        base_path_list = dir_path.split("/")[1:]
        for i, p in enumerate(base_path_list):
            if not node["children"]:
                break
            if p not in node["children"]:
                break
            node = node["children"][p]
            if node["pid"] != target_pid:
                target_pid = node["pid"]
                target_status = bool(node["status"])

        if target_pid == 0:
            res.update(data={
                "lock": False,
                "pid": 0,
                "action": ["create", ]
            })
            return res

        rule = rules[target_pid]
        _white_dir = self._check_white_dirs(dir_path + "/", rule["white_dirs"], rule_path=rule["path"])
        _black_exts = []
        _white_files = []
        if file:
            _black_exts = self._check_ext(os.path.join(dir_path, file), rule["black_exts"], rule_path=rule["path"])
            _white_files = self._check_white_files(os.path.join(dir_path, file), rule["white_files"],
                                                   rule_path=rule["path"])

        state = not bool(_white_dir) and target_status
        act = []
        # if not target_status and dir_path + "/" == rule["path"]:
        if not target_status:
            act.append("open")
        if not state:
            # 当前未锁定状态， 目标：锁定
            # 若不在本层：则添加新的规则
            # 若有白名单保护: 可以移除白名单
            # if dir_path + "/" != rule["path"]:  # 暂时放弃create （不在本层：则添加新的规则）
            #     act.append("create")
            if _white_dir:
                act.append("remove_wd")
        if state and not file:
            # 当前锁定状态， 目标：解除锁定 （选择的不是文件）
            # 若在本层: 可以选择关闭，不在本层则： 添加白名单（决定路径）
            if dir_path + "/" == rule["path"]:
                act.append("close")
            else:
                act.append("add_wd")

        if file:
            state = state and bool(_black_exts) and not bool(_white_files)
            # 当前未锁定状态， 目标：解除文件锁定
            # 若不在本层则：添加新的规则
            # 若有白名单保护：可以移除白名单
            if not state:
                if not _black_exts:
                    act.append("add_bf")
                if _white_files:
                    act.append("remove_wf")
            else:
                # 当前锁定状态， 目标：解除文件锁定
                # 移除黑名单后缀， 添加白名单
                act.append("remove_bf")
                act.append("add_wf")

        res.update(data={
            "lock": state,
            "pid": target_pid,
            "action": act,
            "white_dir": _white_dir,
            "black_exts": _black_exts,
            "white_files": _white_files,
            "rule": rule,
        })
        return res

    def create_path(self, args=None, path=None, exts=[]):
        """创建一个规则，可以指定要保护的内容
        @author baozi <202-03-13>
        @param:
            args ( dict )  (default: None )
                : 请求信息
            path ( str )  (default: None )
                : 添加的路径
            exts ( list )  (default: [] )
                : 待添加的黑名单，为空时则使用默认黑名单
        @return
        """
        if args:
            if 'path' in args:
                path = args.get("path")
            if 'exts' in args:
                exts = args.get("exts")

        if not exts:
            black_exts = None
        else:
            black_exts = exts
            if black_exts[0] == "[":
                black_exts = json.loads(black_exts)
            if isinstance(black_exts, str):
                black_exts = [black_exts, ]

        # 去除软连接
        path = os.path.realpath(path)

        if not os.path.exists(path): return public.returnMsg(False,
                                                             "The specified configuration target file path does not exist")
        if os.path.isfile(path): return public.returnMsg(False,
                                                         "Specifies that the configuration target file path should not be specific file")

        if black_exts:
            return self._create_path_config(path, black_exts=black_exts)
        else:
            return self._create_path_config(path)

    def batch_setting(self, args=None, pid=None, settings=None):
        """对某一个已存在的规则进行批量设置
        @author baozi <202-03-13>
        @param:
            args ( dict )  (default: None )
                : 请求信息
            pid ( int )  (default: None )
                : 目标规则的ID
            settings ( list )  (default: None )
                : 修改内容
        @return  dict : 操作结果
        """
        try:
            if args:
                if 'pid' in args:
                    pid = int(args.get("pid"))
                if 'settings' in args:
                    settings = args.get("settings")
            if isinstance(pid, str):
                pid = int(pid)
            if isinstance(settings, str):
                settings = json.loads(settings)
        except ValueError:
            return {"status": False, "msg": "Parameter error"}
        if not settings:
            return {"status": False, "msg": "parameter missing"}

        if not self.get_tamper_path_find(path_id=pid): return public.returnMsg(False,
                                                                               "The specified target configuration does not exist")

        # 获取目录配置
        config = self.read_config()
        for path_info in config["paths"]:
            if path_info["pid"] == pid:
                rule = path_info
                break

        log_msg = "Make bulk change to rules for directory: {}".format(rule["path"])
        for i in settings:
            key = i.get("key")
            if key not in ("open", "close", "remove_wd", "add_wd", "add_bf", "remove_bf", "add_wf", "remove_wf"):
                return {"status": False, "msg": "unrecognized action item:{}".format(key)}
            if key == "open":
                rule["status"] = 1
                log_msg += "\n open rule"
                continue
            elif key == "close":
                rule["status"] = 0
                log_msg += "\n close rule"
                continue

            values = i.get("values")
            values = [values, ] if isinstance(values, str) else values
            if not values:
                return {"status": False, "msg": "Item: {} has no operation content:".format(key)}
            if key == "remove_wd":
                for i in values:
                    if i in rule["white_dirs"]:
                        rule["white_dirs"].remove(i)
                        log_msg += "\n remove whitelist path:{}".format(i)
            elif key == "add_wd":
                for i in values:
                    if i not in rule["white_dirs"]:
                        rule["white_dirs"].append(i)
                        log_msg += "\n append whitelist path: {}".format(i)
            elif key == "add_bf":
                for i in values:
                    if i not in rule["black_exts"]:
                        rule["black_exts"].append(i)
                        log_msg += "\n append the protected suffix: {}".format(i)
            elif key == "remove_bf":
                for i in values:
                    if i in rule["black_exts"]:
                        rule["black_exts"].remove(i)
                        log_msg += "\n remove protected suffix: {}".format(i)
            elif key == "add_wf":
                for i in values:
                    if i not in rule["white_files"]:
                        rule["white_files"].append(i)
                        log_msg += "\n append whitelist file: {}".format(i)
            elif key == "remove_wf":
                for i in values:
                    if i in rule["white_files"]:
                        rule["white_files"].remove(i)
                        log_msg += "\n remove whitelist file: {}".format(i)
            if key not in ("open", "close", "remove_wd", "add_wd", "add_bf", "remove_bf", "add_wf", "remove_wf"):
                return {"status": False, "msg": "unrecognized action item:{}".format(key)}

        self.save_config(config)
        public.WriteLog('Tamper-proof for Enterprise', log_msg)
        return public.returnMsg(True, "Success modified")

    # ——————————————————————————————
    #        日志切割与查询         |
    # ——————————————————————————————

    def _get_log_content(self, p, row, log_file_paths):
        """创建一个内，用于排序并获取日志内容
        @author baozi <202-03-23>
        @param:
            log_file_paths  ( list ):  日志文件的列表
        @return
        """

        def the_generator(self):
            _buf = b""
            for fp in self._get_fp():
                is_start = True
                while is_start:
                    buf = b''
                    while True:
                        pos = fp.tell()
                        read_size = pos if pos <= 38 else 38
                        fp.seek(-read_size, 1)
                        _buf = fp.read(read_size) + _buf
                        fp.seek(-read_size, 1)
                        nl_idx = _buf.rfind(ord('\n'))
                        if nl_idx == -1:
                            if pos <= 38:
                                buf, _buf = _buf, b''
                                is_start = False
                                break
                        else:
                            buf = _buf[nl_idx + 1:]
                            _buf = _buf[:nl_idx]
                            break
                    res = self._is_use(buf.decode("utf-8"))
                    if self.count > 10000:
                        self.count -= 1
                        return
                    if not (res is False):
                        yield res

        def the_init(self, p, size, log_files):
            self.log_files = log_files
            self.count = 0
            self.t_range = [(p - 1) * size, p * size]
            self.test = [None for _ in range(4)]

        def the__get_fp(self):
            for i in self.log_files:
                if not os.path.exists(i): continue
                with open(i, 'rb') as fp:
                    fp.seek(-1, 2)
                    yield fp

        def the__is_use(self, log: str):
            _test = [i for i in log.split("] [")]
            _test[0] = _test[0].strip().strip("[")
            _test[4] = _test[4].strip().strip("]")
            for i in range(4):
                if self.test[i] is None: continue
                if not self.test[i](_test[i + 1]):
                    return False
            self.count += 1
            if self.t_range[0] <= self.count - 1 < self.t_range[1]:
                return _test
            return False

        def the_set_args(self, target=None, t_type=None, user=None, proc=None):
            if target:
                self.test[1] = lambda x: x.find(target) != -1
            if t_type:
                self.test[0] = lambda x: x == t_type
            if user:
                self.test[2] = lambda x: x == user
            if proc:
                self.test[3] = lambda x: x.find(proc) != -1
            if bool(self.test[0]) or bool(self.test[1]) or bool(self.test[2]) or bool(self.test[3]):
                self._need = True
            else:
                self._need = False

        attr = {
            "__init__": the_init,
            "_get_fp": the__get_fp,
            "__iter__": the_generator,
            "_is_use": the__is_use,
            "set_args": the_set_args
        }
        return type("LogContent", (object,), attr)(p, row, log_file_paths)

    # 获取日志文，并按关系排序
    def _get_log_files(self, log_path, before=None):
        files = glob.glob(log_path + "/*.log")
        files.sort(reverse=True)
        if before:
            try:
                idx = files.index("{}/{}.log".format(log_path, before))
            except:
                return []
            return files[idx:]
        return files

    def _check_query(self, query):
        err, res = "", {}
        if "target" in query and isinstance(query["target"], str):
            tmp = query["target"].strip()
            res["target"] = tmp if bool(tmp) else None

        if "t_type" in query and isinstance(query["t_type"], str):
            if query["t_type"] in ("create", "modify", "unlink", "rename", "mkdir", "rmdir", "chmod", "chown", "link"):
                res["t_type"] = query["t_type"]
            else:
                err += "Query items: trigger mode, setting error\n"
        if not "user" in query:
            pass
        elif query["user"] not in self._get_sys_user():
            err += "Query items: user, setting error\n"
        else:
            res["user"] = query["user"]

        if "proc" in query and query["proc"]:
            tmp = query["proc"].strip()
            res["proc"] = tmp if bool(tmp) else None

        query = res
        return err

    def get_logs(self, args=None, path_id=None):
        '''
            @name 获取日志
            @author baozi<2023-03-22>
            @param path_id<int> 日志路径ID
            @return list
        '''
        rows = 10
        p = 1
        query = None
        date = None
        if args:
            if 'path_id' in args: path_id = int(args.get("path_id"))
            if 'p' in args: p = int(args.get("p"))
            if 'rows' in args: rows = int(args.get("rows"))
            if 'date' in args: date = args.get("date")
            if 'query' in args: query = args.get("query")
        if query and isinstance(query, str):
            query = json.loads(query)
        if not query or not isinstance(query, dict):
            query = {}
        err = self._check_query(query)
        if err:
            return public.returnMsg(False, err)
        if path_id == None: return public.returnMsg(False, "Parameter error")
        path_info = self.get_tamper_path_find(path_id=path_id)
        if not path_info: return public.returnMsg(False, "The specified directory configuration does not exist")

        log_path = "{}/{}".format(self.__logs_path, path_id)
        if not os.path.exists(log_path) or not os.path.isdir(log_path):
            return []
        today = time.strftime('%Y-%m-%d', time.localtime())
        if date == "query":
            log_files = self._get_log_files(log_path)
        elif not date:
            log_files = ["{}/{}.log".format(log_path, today), ]
        else:
            log_files = ["{}/{}.log".format(log_path, date), ]

        result = []
        logcontent = self._get_log_content(p, rows, log_files)
        logcontent.set_args(**query)
        for i in logcontent:
            result.append(i)

        page = public.get_page(logcontent.count, p=p, rows=rows)
        for i in range(len(result)):
            _info = {
                "date": result[i][0],
                "type": result[i][1],
                "content": result[i][2],
                "user": result[i][3],
                "process": result[i][4]
            }
            result[i] = _info
        page["data"] = result
        page["size"] = self._get_log_size(log_path)
        page["dates"] = [i.strip(".log") for i in os.listdir(log_path)]
        page["dates"].sort(reverse=True)
        if page["dates"]:
            if today != page["dates"][0]:
                page["dates"].insert(0, today)
        return page

    def _get_sys_user(self):
        """获取所有用户名
        @author baozi <202-03-23>
        @param:
        @return
        """
        user_set = set()
        with open('/etc/passwd') as fp:
            for line in fp.readlines():
                user_set.add(line.split(':', 1)[0])

        return user_set

    def _get_log_size(self, log_path):
        size = 0
        for i in glob.glob(log_path + "/*.log"):
            size += os.path.getsize(i)
        return public.to_size(size)

    # 获取使用天数记录
    def _get_use_day(self):
        day_file = "{}/date.pl".format(self.__tamper_path)
        if not os.path.exists(day_file):
            public.writeFile(day_file, '{}\n0\n'.format(int(time.time())))
            return 1
        day = 1
        try:
            last, sum = public.readFile(day_file).split("\n")[:2]
            if last.isdecimal():
                sum = int(time.time()) - int(last) + int(sum)
            else:
                sum = int(sum)
            day = int(sum / (60 * 60 * 24)) + 1
            return day
        except:
            return day

    def del_logs(self, args=None, path_id=None, date=None, before=False):
        '''
            @name 删除日志
            @author baozi<2023-03-22>
            @param path_id<int> 日志路径ID
            @return list
        '''
        date = None
        if args:
            if 'path_id' in args: path_id = int(args.get("path_id"))
            if 'date' in args: date = args.get("date")
            if 'before' in args: before = args.get("before")
        if path_id == None: return public.returnMsg(False, "Parameter error")
        path_info = self.get_tamper_path_find(path_id=path_id)
        if not path_info: return public.returnMsg(False, "The specified directory configuration does not exist")
        try:
            date = date.strip()
            time.strptime(date, '%Y-%m-%d')
        except:
            return public.returnMsg(False, "The specified directory configuration does not exist")

        if bool(before):
            files = self._get_log_files(self.__logs_path + '/' + str(path_id), date)
            del_msg = ''
            for i in files:
                os.remove(i)
            if len(files) >= 2:
                del_msg = files[-1][-14:-4] + ' to ' + files[0][-14:-4]
            elif len(files) == 1:
                del_msg = files[0][-14:-4]
            else:
                return {"status": True, "msg": "Logs with no date specified"}
        else:
            files = "{}/{}/{}.log".format(self.__logs_path, path_id, date)
            if os.path.exists(files):
                del_msg = date
                os.remove(files)
            else:
                return {"status": True, "msg": "Logs with no date specified"}

        public.WriteLog('Tamper-proof for Enterprise',
                        "Protected directory: {} deleted {} logs".format(path_info["path"], del_msg))
        return {"status": True, "msg": "successfully deleted"}

    def set_frequent_process(self, args=None, proc_name=None, ps=""):
        '''
         @proc_name 进程名
        '''
        if args:
            if 'proc_name' in args: proc_name = args.get("proc_name")
            if 'ps' in args: ps = args.get("ps")
        config = self.read_config()
        if not proc_name:
            return {"status": False, "msg": "Process name cannot be empty"}
        if not ps:
            ps = ""
        for i in config["frequent_process"]:
            if i["name"] == proc_name:
                i["ps"] = ps
                break
        else:
            if proc_name not in config["process_names"]: config["process_names"].append(proc_name)
            config["frequent_process"].append({"name": proc_name, "ps": ps})

        self.save_config(config)

        return {"status": True, "msg": "successfully set"}

    def del_frequent_process(self, args=None, proc_name=None, ps=""):
        '''
         @proc_name 进程名
        '''
        if args:
            if 'path_id' in args: path_id = int(args.get("path_id"))
            if 'proc_name' in args: proc_name = args.get("proc_name")
            if 'ps' in args: ps = args.get("ps")
        if path_id == None: return public.returnMsg(False, "Parameter error")
        config = self.read_config()
        rule = None
        for i in config["paths"]:
            if i["pid"] == path_id:
                rule = i
        if not rule:
            return public.returnMsg(False, "The specified directory configuration does not exist")
        if not proc_name:
            return {"status": False, "msg": "Process name cannot be empty"}
        if not ps:
            ps = ""
        for i in range(len(config["frequent_process"]) - 1, -1, -1):
            if config["frequent_process"][i]["name"] == proc_name:
                del config["frequent_process"][i]
                if proc_name in config["process_names"]:
                    config["process_names"].remove(proc_name)

        self.save_config(config)

        return {"status": True, "msg": "successfully set"}

    # def attack(self, args=None):
    #     public.set_module_logs('tamper_core', 'attack', 1)
    #     self.clear_attack(None)
    #     service_status = self.get_service_status()
    #     msg_list = ["正在检查保护状态..."]
    #     res = {"status": True, "msg":"未进行模拟攻击", "attack_msg": msg_list}
    #     if not service_status["kernel_module_status"] or not service_status["controller_status"]:
    #         msg_list.append("防篡改内核未开启，无法测试")
    #     config = self.read_config()
    #     if config["status"] != 1:
    #         msg_list.append("全局开关已关闭，无法测试")
    #     # 检查测试方式
    #     # 创建测试保护目录
    #     # 创建测试用户
    #     if len(msg_list) > 1: return res
    #     act = None
    #     for i in ("mkdir", "touch", "bash", "mv", "rm","chown", "chmod", "ln"):
    #         if i in config["process_names"]:
    #             continue
    #         else:
    #             act = i
    #             break
    #     if not act:
    #         msg_list.append('您已将["mkdir", "touch", "bash", "mv", "rm","chown", "chmod", "ln"]等指令加入了进程白名单，无法进行测试，也请注意您的网站安全。')
    #     atk_user = "tmaperatk"
    #     self.attack_pre(atk_user, msg_list, config)
    #     self._do_attack(act, atk_user, msg_list)

    #     config_data = {
    #         "time": int(time.time()) + 60,
    #         "type": 2,
    #         "name":"tamper_core",
    #         "title": "堡塔企业级防篡改 - 重构版",
    #         "fun":"clear_attack",
    #         "args": {}
    #     }
    #     public.set_tasks_run(config_data)
    #     return res

    # def _do_attack(self, act, atk_user, msg_list):
    #     act_dict = {
    #         "mkdir": ("mkdir /www/tamper_core_test/test", "创建文件夹[/www/tamper_core_test/test]"),
    #         "touch": ("touch /www/tamper_core_test/test.html", "创建文件[/www/tamper_core_test/test.html]"),
    #         "bash": ("echo '' > /www/tamper_core_test/test.html","创建文件[/www/tamper_core_test/test.html]"),
    #         "mv": ("mv /www/tamper_core_test/test.txt /www/tamper_core_test/test.html", "重命名[test.txt]为[test.html]"),
    #         "rm": ("rm -rf /www/tamper_core_test/test.txt","删除文件[/www/tamper_core_test/test.txt]"),
    #         "chown": ("chown root:root /www/tamper_core_test/test.txt","修改文件[test.txt]的权限"),
    #         "chmod": ("chmod 644 /www/tamper_core_test/test.txt", "修改文件[test.txt]的所有人" ),
    #         "ln": ("ln -s /tmp/tamper_test /www/tamper_core_test/test.txt", "为文件[test.txt]创建软链接")
    #     }
    #     _act_sh, msg = act_dict[act]
    #     msg_list.append("尝试攻击操作：" + msg)
    #     tmp = public.ExecShell(_act_sh, user=atk_user)
    #     if tmp[1]:
    #         msg_list.append("该次攻击拦截成功，内核防御成功！！")
    #     else:
    #         msg_list.append("该次攻击未拦截成功，请尽快联系官方解决问题")

    #     msg_list.append("注意：<br>" + "|---再次执行模拟攻击时，会移除上次模拟攻击的测试文件和文件夹，然后再次模拟攻击<br>" + "|---模拟攻击的测试文件和文件夹会在一段时间后自然移除，您无需手动操作")

    # def clear_attack(self, args):
    #     from files import files
    #     files().set_file_ps(type("get",(object,),{"filename":"/www/tamper_core_test","ps_type":0, "ps_body":''}))
    #     public.ExecShell('userdel -r {}'.format("tmaperatk"))
    #     self.remove_path_config(path="/www/tamper_core_test/")
    #     if os.path.exists(self.__tips_file):
    #         while True:
    #             time.sleep(0.01)
    #             if not os.path.exists(self.__tips_file):
    #                 time.sleep(0.01)
    #                 break
    #     if os.path.exists("/www/tamper_core_test"):
    #         shutil.rmtree("/www/tamper_core_test")
    #     public.WriteLog("防篡改","模拟攻击相关文件已移除")
    #     return public.returnMsg(True, "防篡改模拟攻击测试文件移除。")

    # def attack_pre(self, user, msg_list, config):
    #     from files import files
    #     from pwd import getpwnam

    #     public.ExecShell('useradd {}'.format(user))
    #     os.makedirs("/www/tamper_core_test", mode=0o777)
    #     with open("/www/tamper_core_test/test.txt", mode="w") as fp:
    #         fp.write("防篡改测试文件")
    #     files().set_file_ps(type("get",(object,),{"filename":"/www/tamper_core_test","ps_type":0, "ps_body":"企业级防篡改模拟攻击文件"}))
    #     user_info = getpwnam(user)
    #     os.chown("/www/tamper_core_test", user_info.pw_uid, user_info.pw_gid)
    #     os.chown("/www/tamper_core_test/test.txt", user_info.pw_uid, user_info.pw_gid)
    #     msg_list.append("准备阶段：创建测试用户[{}],测试文件夹[/www/tamper_core_test],测试文件[test.txt]".format(user))

    #     path_info = {
    #         "pid":self.get_path_id(config["paths"]),
    #         "path":"/www/tamper_core_test/",
    #         "status":1,
    #         "mode":0,
    #         "is_create":1,
    #         "is_modify":1,
    #         "is_unlink":1,
    #         "is_mkdir":1,
    #         "is_rmdir":1,
    #         "is_rename":1,
    #         "is_chmod":1,
    #         "is_chown":1,
    #         "is_link":1,
    #         "black_exts": [".html", ".txt"],
    #         "white_files": [],
    #         "white_dirs": [],
    #         "ps": "模拟攻击测试专用"
    #     }

    #     # 添加到配置列表
    #     config["paths"].append(path_info)
    #     config["dir_ps_" + str(path_info["pid"])] = {}
    #     self.save_config(config)
    #     if os.path.exists(self.__tips_file):
    #         while True:
    #             time.sleep(0.01)
    #             if not os.path.exists(self.__tips_file):
    #                 time.sleep(0.01)
    #                 break

    def test_system(self):
        check_sh = 'lsattr /etc/ | grep -E "^-* ?/etc/(group|gshadow|shadow|passwd)$" |wc -l'
        tmp = int(public.ExecShell(check_sh)[0])
        if tmp == 0:
            return False
        return True

    def get_test_sys_uesr(self, config):
        import pwd

        users = ["root", "www"]
        for i in users:
            user_info = pwd.getpwnam(i)
            if user_info.pw_uid not in config["uids"] and user_info.pw_gid not in config["gids"]:
                return i
        return None

    def attack(self, args=None, path_id=None):
        public.set_module_logs('tamper_core', 'attack', 1)
        if args:
            if 'path_id' in args: path_id = int(args.get("path_id"))
        if path_id == None: return public.returnMsg(False, "Parameter error")
        config = self.read_config()

        rule = None
        for i in config["paths"]:
            if i["pid"] == path_id:
                rule = i
        if not rule:
            return public.returnMsg(False, "The specified directory configuration does not exist")

        # 测试能否添加测试用户
        sys_user = self.get_test_sys_uesr(config)
        sys_test = self.test_system()
        if not sys_test and not sys_user:
            return public.returnMsg(False,
                                    "Unable add test user, please confirm whether the relevant file is locked, and test again after confirming that the user can be added.")
        err_res = {"status": True, "msg": "No simulated attack",
                   "attack_msg": ["Check status of protected directory [%s] ..." % rule["path"], ]}
        if not (bool(rule["status"]) and bool(config["status"])):
            err_res["attack_msg"].append(
                "[Protection List]->[%s] The anti-tampering function is not enabled, so it cannot be tested." % rule[
                    "path"])
            return err_res
        res = self._check_white_dirs(rule["path"], rule["white_dirs"], rule_path=rule["path"])
        if res:
            err_res["attack_msg"].append(
                "The %s in [Protection List]->[%s]->[Config]->[Directory whitelist] matches the current protected directory, which causes all files in this directory to be unprotected and cannot be tested." % (
                rule["path"], str(res)))
            return err_res
        acts = [
            "is_mkdir",  # ---> 所有情况都可以测试
            "is_create",  # ----> 需要有保护的黑名单
            "is_link",  # ----> 需要有保护的黑名单 并且需要启用一个白名单进程生成有个被保护的文件供模拟的攻击者操作
            "is_chmod",
            "is_chown",
            "is_rename",
            "is_modify",
            "is_unlink",
            "is_rmdir"
        ]
        random_name = _random_name()
        attack_config = {"attack_process": random_name, "base_path": rule["path"], "sys_test": sys_test,
                         "sys_user": sys_user}
        for i, act in enumerate(acts):
            if rule[act] == 1:
                attack_config["type"] = act
                if i == 0:
                    attack_config["dir"] = "{}{}".format(rule["path"], random_name)
                    attack_config["file"] = "{}{}".format(rule["path"], random_name + "/random_name")
                    return self._do_attack(attack_config, config)
                else:
                    break
        else:
            err_res["attack_msg"].append(
                "[Protection List]->[%s]->[Config]->[Basic Settings]There is no protection rule enabled, so it cannot be tested." %
                rule["path"])
            return err_res

        ext, file_path = None, []
        for i in rule["black_exts"]:
            if i[0] == "." and i.find("/") == -1:
                ext = i
            else:
                file_path.append(i)

        attack_config["dir"] = "{}{}".format(rule["path"], random_name)
        if ext:
            attack_config["file"] = "{}{}{}".format(rule["path"], random_name, ext)
            return self._do_attack(attack_config, config)

        if not file_path:
            err_res["attack_msg"].append(
                "[Protection List]->[%s]->[Config]->[Protected file suffix] There is no protected suffix set, so it cannot be tested." %
                rule["path"])
            return err_res

        file_path.sort(key=lambda x: len(x))
        ext = file_path[0]
        if ext[0] != "/":
            random_name += "/"
        attack_config["file"] = "{}{}{}".format(rule["path"], random_name, ext)
        return self._do_attack(attack_config, config)

    def _do_attack(self, attack_config, config):
        prep_process = _random_name()
        attack_config.update(prep_process=prep_process)
        perm = self._change_permission(attack_config)
        res = perm()
        if not res:
            return public.returnMsg(False,
                                    "Unable add test user, please confirm whether the relevant file is locked, and test again after confirming that the user can be added.")

        config["process_names"].append(prep_process)
        self.save_config(config)
        if os.path.exists(self.__tips_file):
            while True:
                time.sleep(0.01)
                if not os.path.exists(self.__tips_file):
                    time.sleep(0.1)
                    break

        public.ExecShell(self._set_prep_sh(attack_config), user=attack_config["atk_user"])
        public.ExecShell(self._do_attack_sh(attack_config), user=attack_config["atk_user"])
        res = public.readFile("/tmp/{}.log".format(attack_config["attack_process"]))
        if res.find("攻击失败") != -1:
            flag = True
        elif res.find("文件丢失") != -1 or res == '':
            del perm
            return public.returnMsg(False,
                                    "The test failed. The possible reason is that your system environment is not compatible with the test file, but this does not mean that your Tamper-proof for Enterprise is not effective.")
        else:
            flag = False
        public.ExecShell(self._remove_prep_sh(attack_config), user=attack_config["atk_user"])
        del perm
        config["process_names"].remove(prep_process)
        self.save_config(config)
        self._clean_atk(attack_config)
        return {"status": flag, "msg": "Simulated attack has been carried out",
                "attack_msg": self._show_attack(attack_config, flag)}

    def _show_attack(self, attack_config, flag):
        start = "Checking status of protected directory [%s] " % attack_config["base_path"]
        acts = {
            "is_mkdir": 'Create directory',
            "is_create": 'Create file',
            "is_link": 'Create soft link',
            "is_chmod": 'Modify permissions',
            "is_chown": 'Modify owner',
            "is_rename": 'Rename',
            "is_modify": 'Modify',
            "is_unlink": 'Delete file',
            "is_rmdir": 'Delete directory'
        }
        act_type = "Try attack：{}".format(acts[attack_config["type"]])
        prep = "Prepare：" + (
            "Create test user [{}]".format(attack_config["atk_user"]) if attack_config["atk_user"] not in (
            "www", "root") else "Select test user as [{}]".format(attack_config["atk_user"]))
        if attack_config["type"] not in ("is_mkdir", "is_create"):
            prep += "，Create test directory [{}] and test file [{}]".format(attack_config["dir"], attack_config["file"])
        attack = "Attack content: Use the test user to run the simulated attack program [process name: {}] to execute {} operation".format(
            attack_config["attack_process"], acts[attack_config["type"]])
        end = "Attack result：" + (
            "The attack has been intercepted and the defense is successful" if flag else "The attack was not intercepted successfully, please contact the official as soon as possible to solve the problem")
        return start, act_type, prep, attack, "End: clear all temporary files in this test", end

    def _change_permission(self, attack_config):

        def the_init(this, attack_config):
            this.base_path = attack_config["base_path"]
            this.attack_config = attack_config
            this.mod_data = {}
            this.del_user = True

        def the_call(this):
            if not attack_config["sys_test"]:
                attack_config["atk_user"] = attack_config["sys_user"]
                this.user = attack_config["sys_user"]
                this.del_user = False
            else:
                atk_user = "tmaper" + _random_name()
                res = public.ExecShell('useradd -s /sbin/nologin {}'.format(atk_user))[1]
                if not res:
                    attack_config["atk_user"] = atk_user
                    this.user = atk_user
                elif not attack_config["sys_user"]:
                    return False
                else:
                    attack_config["atk_user"] = attack_config["sys_user"]
                    this.user = attack_config["sys_user"]
                    this.del_user = False

            tmp_path = ''
            for i in this.base_path.split("/")[1:-1]:
                tmp_path += f"/{i}"
                mode = os.stat(tmp_path).st_mode & 0o777
                this.mod_data[tmp_path] = mode
                os.chmod(tmp_path, mode | 0o007)
            return True

        def the_del(this):
            tmp_path = ''
            for i in this.base_path.split("/")[1:-1]:
                tmp_path += f"/{i}"
                os.chmod(tmp_path, this.mod_data[tmp_path])
            if this.del_user:
                public.ExecShell('userdel -r {}'.format(this.user))

        attr = {"__init__": the_init, "__call__": the_call, "__del__": the_del}
        return type("ChangePermission", (object,), attr)(attack_config)

    @staticmethod
    def _do_attack_sh(attack_config):
        atk_file_path = "{}/plugin/tamper_core/attack".format(public.get_panel_path())
        attack_process = attack_config["attack_process"]
        tmp_file = "/tmp/{}".format(attack_process)
        public.ExecShell("\cp -f {} /tmp/{}".format(atk_file_path, attack_process))
        os.chmod(tmp_file, mode=0o777)
        return "{runfile} {atk_type} {atk_dir} {atk_file} &> /tmp/{process}.log".format(
            runfile=tmp_file,
            atk_type=attack_config["type"],
            atk_dir=attack_config["dir"],
            atk_file=attack_config["file"],
            process=attack_process)

    @staticmethod
    def _set_prep_sh(attack_config):
        prep_file_path = "{}/plugin/tamper_core/prep".format(public.get_panel_path())
        prep_process = attack_config["prep_process"]
        tmp_file = "/tmp/{}".format(prep_process)
        os.system("\cp -f {} /tmp/{}".format(prep_file_path, prep_process))
        os.chmod(tmp_file, mode=0o777)
        return "{runfile} {atk_type} {atk_dir} {atk_file} &> /tmp/{process}.log".format(
            runfile=tmp_file,
            atk_type=attack_config["type"],
            atk_dir=attack_config["dir"],
            atk_file=attack_config["file"],
            process=prep_process)

    @staticmethod
    def _remove_prep_sh(attack_config):
        tmp_file = "/tmp/{}".format(attack_config["prep_process"])
        return "{runfile} {atk_type} {atk_dir} {atk_file} {c} &>> /tmp/{process}.log".format(
            runfile=tmp_file,
            atk_type=attack_config["type"],
            atk_dir=attack_config["dir"],
            atk_file=attack_config["file"],
            c="clean", process=attack_config["prep_process"])

    @staticmethod
    def _clean_atk(attack_config):
        clean_files = [
            "/tmp/{}".format(attack_config["prep_process"]), "/tmp/{}.log".format(attack_config["prep_process"]),
            "/tmp/{}".format(attack_config["attack_process"]), "/tmp/{}.log".format(attack_config["attack_process"])
        ]
        for i in clean_files:
            if os.path.exists(i):
                os.remove(i)

    def set_white_dir_with_ps(self, args=None, path_id=None, dir_name=None, ps=""):
        '''
         @dir_name 白名单文件夹
        '''
        if args:
            if 'dir_name' in args: dir_name = args.get("dir_name")
            if 'ps' in args: ps = args.get("ps")
            if 'path_id' in args: path_id = int(args.get("path_id"))
        if path_id == None: return public.returnMsg(False, "Parameter error")
        config = self.read_config()

        rule = None
        for i in config["paths"]:
            if i["pid"] == path_id:
                rule = i
        if not rule:
            return public.returnMsg(False, "The specified directory configuration does not exist")
        if not dir_name:
            return {"status": False, "msg": "The whitelist directory cannot be empty"}
        if not ps:
            ps = ""
        dis_ps_name = "dir_ps_" + str(rule["pid"])
        if dir_name in config[dis_ps_name]:
            config[dis_ps_name][dir_name] = ps
        else:
            if dir_name not in rule["white_dirs"]: rule["white_dirs"].append(dir_name)
            config[dis_ps_name][dir_name] = ps

        self.save_config(config)

        return {"status": True, "msg": "successfully set"}

    def del_white_dir_with_ps(self, args=None, path_id=None, dir_name=None):
        '''
         @dir_name 白名单文件夹
        '''
        if args:
            if 'dir_name' in args: dir_name = args.get("dir_name")
            if 'path_id' in args: path_id = int(args.get("path_id"))
        if path_id == None: return public.returnMsg(False, "Parameter error")
        config = self.read_config()
        rule = None
        for i in config["paths"]:
            if i["pid"] == path_id:
                rule = i
        if not rule:
            return public.returnMsg(False, "The specified directory configuration does not exist")
        if not dir_name:
            return {"status": False, "msg": "The whitelist directory cannot be empty"}

        dis_ps_name = "dir_ps_" + str(rule["pid"])
        if dir_name in config[dis_ps_name]:
            config[dis_ps_name].pop(dir_name)
            if dir_name in rule["white_dirs"]:
                rule["white_dirs"].remove(dir_name)

        self.save_config(config)

        return {"status": True, "msg": "successfully set"}

    def get_sites_path(self, args=None):
        """获取站点的路径
        @author baozi <202-03-23>
        @return
        """

        sites_data = public.M("sites").field("name,path,project_type").select()
        config = self.read_config()
        res = []
        use_path = {i["path"] for i in config["paths"]}
        # modified_paths = {path + '/' if not path.endswith('/') else path for path in use_path}
        for i in sites_data:
            if i["project_type"] in ("Go", "Other"):
                i["path"] = i['path'].rsplit("/", 1)[0]  # Go 和 Other 项目的路径是运行文件的路径
            if i["project_type"] == "Java" and os.path.isfile(i["path"]):
                i["path"] = i['path'].rsplit("/", 1)[0]  # springboot 项目的路径是运行文件的路径

            # 规范路径
            if i["path"][-1] != "/":
                i["path"] += "/"

            if i["path"] not in use_path:
                i["can_create"] = True
            else:
                i["can_create"] = False
            res.append(i)
        res.sort(key=lambda x: int(x["can_create"]), reverse=True)
        return res

    def multi_create(self, args=None, paths=[]):
        """一次性添加多个目录的防篡改
        @author baozi <202-03-23>
        @param:
            args ( _type_ )  (default: None )
                : _description_
            path ( list )  (default: [] )
                : 要添加的目录
        @return
        """

        if args:
            if 'paths' in args:
                paths = args.get("paths")

        if not paths:
            return public.returnMsg(False, "No file path")
        else:
            if isinstance(paths, str) and paths[0] == "[":
                paths = json.loads(paths)
            elif not isinstance(paths, list):
                return public.returnMsg(False, "Wrong file path")

        res = [{
            "pid": None,
            "path": i["path"] if i["path"][-1] == "/" else i["path"] + "/",
            "ps": i["ps"],
            "msg": "Add success",
            "status": True
        } for i in paths]

        config = self.read_config()
        use_path = {i["path"] for i in config["paths"]}
        start_pid = self.get_path_id(config["paths"])
        for i in res:
            i["path"] = i["path"].replace('//', '/')
            if i["path"] in use_path:
                i["status"] = False
                i["msg"] = "The directory already exists and cannot be added repeatedly"
                continue
            flag, msg = self._create_path_for_multi(start_pid + 1, i["path"], config, i["ps"])
            if flag:
                start_pid += 1
                i["pid"] = start_pid
                i["rule"] = msg
            else:
                i["status"] = False
                i["msg"] = msg

        self.save_config(config)

        return res

    def _create_path_for_multi(self, pid, path, config, ps=""):
        # 路径标准化处理
        if path[-1] != "/": path += "/"
        path = path.replace('//', '/')

        # 参数过滤
        if not path: return False, "Directory path cannot be empty"
        if not os.path.exists(path) or os.path.isfile(path): return False, "invalid directory: {}".format(path)

        # 关键路径过滤
        if path in ['/', '/root/', '/boot/', '/www/', '/www/server/', '/www/server/panel/', '/www/server/panel/class/',
                    '/usr/', '/etc/', '/usr/bin/', '/usr/sbin/']:
            return public.returnMsg(False, "Cannot add system directory: {}".format(path))

        path_info = {
            "pid": pid,
            "path": path,
            "status": 1,
            "mode": 0,
            "is_create": 1,
            "is_modify": 1,
            "is_unlink": 1,
            "is_mkdir": 1,
            "is_rmdir": 1,
            "is_rename": 1,
            "is_chmod": 1,
            "is_chown": 1,
            "is_link": 1,
            "black_exts": config["default_black_exts"],
            "white_files": config["default_white_files"],
            "white_dirs": config["default_white_dirs"],
            "white_exts": [],
            "unused_white_files": [],
            "unused_white_dirs": [],
            "unused_process_names": [],
            "ps": ps
        }

        # 添加到配置列表
        config["paths"].append(path_info)
        config["dir_ps_" + str(path_info["pid"])] = {}
        public.WriteLog('Tamper-proof for Enterprise', "Add directory config: {}".format(path))
        return True, path_info

    def get_frequent_process(self, args=None):
        config = self.read_config()
        res = config["frequent_process"]

        for i in res:
            if i["name"] in config["process_names"]:
                i["status"] = True
            else:
                i["status"] = False

        return res

    def search(self, args):
        content = None
        if args:
            if "search" in args:
                content = args.search
        if not content:
            public.returnMsg("False", "The search is empty")

        config = self.read_config()
        if not config.get("paths"):
            return []

        result = []
        for path_info in config["paths"]:
            path_info['total'] = self.get_path_total(path_id=path_info['pid'])
            result.append(path_info)
        for i in config["paths"]:
            dir_ps = "dir_ps_" + str(i["pid"])
            for j in range(len(i["white_dirs"])):
                if i["white_dirs"][j] in config[dir_ps]:
                    i["white_dirs"][j] = {
                        "dir": i["white_dirs"][j],
                        "ps": config[dir_ps][i["white_dirs"][j]],
                    }
                elif i["white_dirs"][j] in config["default_dir_ps"]:
                    i["white_dirs"][j] = {
                        "dir": i["white_dirs"][j],
                        "ps": config["default_dir_ps"][i["white_dirs"][j]].get("ps"),
                        "tip_msg": config["default_dir_ps"][i["white_dirs"][j]].get("tip_msg", None)
                    }
                else:
                    i["white_dirs"][j] = {
                        "dir": i["white_dirs"][j]
                    }

        result = []
        # public.print_log(config["paths"])
        for idx in range(len(config["paths"])):
            if content in config["paths"][idx]["ps"] or content in config["paths"][idx]["path"]:
                result.append(config["paths"][idx])

        return result

    def assign_rule_to_directory(self, args=None, path_id=None, rule_group_name=None):
        '''
        为目录指派规则组：读入/www/server/panel/plugin/tamper_core/rule.json 将其中由rule_group_name
        所指定的规则写入或覆盖/www/server/tamper/tamper.conf
        @path_id            /www/server/tamper/tamper.conf 中的paths的pid字段，用于唯一标识路径
        @rule_group_name    预设规则组的名称
        '''
        # public.print_log("Enter assign_rule_to_directory")

        if args:
            if 'path_id' in args: path_id = args.get('path_id')
            if 'rule_group_name' in args: rule_group_name = args.get('rule_group_name')
        if path_id == None: return public.returnMsg(False, "Parameter error")
        config = self.read_config()

        current_rule = None
        for i in config["paths"]:
            if i["pid"] == int(path_id):
                current_rule = i
                break
        if not current_rule:
            return public.returnMsg(False, "The specified directory configuration does not exist")

        rule_groups = None  # 包含所有预设规则组
        rule_group = None  # 包含所指派的规则组
        with open(self.__rule_group_file, "r") as f:
            rule_groups = json.load(f)  # rule_groups 是一个列表
        for r in rule_groups:  # r是一个directory
            if r["name"] == rule_group_name:
                rule_group = r  # 获得所指派的规则组
                break
        if not rule_group:
            return public.returnMsg(False, "Specifies that the rule name does not exist")

        # public.print_log(current_rule)
        # public.print_log(rule_group)

        # 保留用户自定义的白名单目录
        old_white_dirs = []
        for i in current_rule["white_dirs"]:
            if not i in self.default_white_dirs:
                old_white_dirs.append(i)
        current_rule["white_dirs"].extend(rule_group["white_dirs"])
        current_rule["white_dirs"] = list(set(current_rule["white_dirs"]))

        # 保留用户自定义的白名单文件
        current_rule["white_files"].extend(rule_group["white_files"])
        current_rule["white_files"] = list(set(current_rule["white_files"]))

        # 保留用户自定义的受保护文件后缀
        old_black_exts = []
        for i in current_rule["black_exts"]:
            if not i in self.default_black_exts:
                old_black_exts.append(i)
        current_rule["black_exts"].extend(rule_group["black_exts"])
        current_rule["black_exts"] = list(set(current_rule["black_exts"]))

        # 保存规则名称
        current_rule["rule_ps"] = rule_group["name"]

        # public.print_log(current_rule)
        # public.print_log(config)
        self.save_config(config)  # 保存该配置文件的同时，会自动创建tips.pl文件

    def get_rule_list(self, args=None):
        '''
        从/www/server/panel/plugin/tamper_core/rule.json中读入所有的规则名称
        @return list, 规则名称的列表
        '''
        rule_groups = []
        rule_list = []
        try:
            with open(self.__rule_group_file, "r") as f:
                rule_groups = json.load(f)

            for r in rule_groups:
                rule_list.append(r["name"])
        except:
            pass

        return rule_list

    def push_white_list(self, args=None, path_id=None, date=None, type=None, content=None, user=None, process=None):
        '''
            @brief 将误报的操作的文件夹或者文件拉入白名单
            @param path_id<string> /www/server/tamper/tamper.conf 中的paths的pid字段，用于唯一标识路径
            @param date<string> 防篡改触发时间
            @param type<string> 防篡改类型
            @param content<string> 白名单路径
            @param user<string> 防篡改触发用户
            @param process<string> 防篡改触发进程
            @return  成功则返回: 将最近上级子目录拉入白名单成功. 如果是文件，则将其加入文件白名单
        '''

        path = None
        webpath = None
        if args:
            if 'path_id' in args: path_id = args.get('path_id')
            if 'date' in args: data = args.get('data')
            if 'type' in args: type = args.get('type')
            if 'content' in args: content = args.get('content')
            if 'user' in args: user = args.get('user')
            if 'process' in args: process = args.get('process')

        # 检查必选项参数是否为空
        if path_id == None or type == None or content == None:
            return public.returnMsg(False, "Parameter error")

        tamper_paths = self.get_tamper_paths()

        '''
        根据所传入的path_id, 在所有保护路径中找到对应的路径名
        '''
        for p in tamper_paths:
            if p["pid"] == int(path_id):
                path = p["path"]

        if path == None:
            return public.returnMsg(False, "Path configuration not found")

        # 获取web根目录
        path_list = content.split('/')
        webpath = '/' + path_list[1] + '/' + path_list[2] + '/' + path_list[3] + '/'

        if os.path.isfile(content):
            self.add_white_files(None, path_id, webpath, path_list[-1])
        elif os.path.isdir(content):
            # 目录后面加一个/
            if content[-1] != '/':
                content = content + '/'
            self.add_white_dirs(None, path_id, webpath, content)
        else:
            return public.returnMsg(False, "The file or directory does not exist")

        return public.returnMsg(True, "Join whitelist successfully")

    def get_tamper_processes(self, args=None):
        '''
            @brief 获取进程配置列表
            @return list
        '''
        tamper_config = self.read_config()
        if 'processes' not in tamper_config:
            return []
        return tamper_config['processes']

    def get_tamper_process_by_pid(self, args=None):
        '''
            @brief 根据传入的关联的pid获取对应的进程配置
            @param pid<int> 关联路径ID
            @return list
        '''
        pid = -1
        if args:
            if 'pid' in args: pid = args.get('pid')
        if pid == -1:
            return public.returnMsg(False, "Error in passing parameters, The associated path does not exist")
        result = []
        tamper_config = self.read_config()
        if 'processes' not in tamper_config:
            return []

        for item in tamper_config['processes']:
            if item['pid'] == int(args.pid):
                result.append(item)

        return result

    def get_ppid(self, tamper_config):
        '''
            @brief 根据tamper.config中的已有的进程配置id获取一个新的ppid
            @param tamper_config<dict> 配置文件内容
            @return 新的ppid
        '''
        if 'processes' not in tamper_config:
            return 1

        max_ppid = 1
        for process_config in tamper_config['processes']:
            if max_ppid < process_config['ppid']:
                max_ppid = process_config['ppid']

        return max_ppid + 1

    def get_rid(self, process_config):
        '''
            @brief 根据进程配置中已有的规则获取一个新的rid
            @param process_config 进程配置
            @return 新的rid
        '''
        if len(process_config['rules']) == 0:
            return 1

        max_rid = 1
        for rule in process_config['rules']:
            if max_rid < rule['rid']:
                max_rid = rule['rid']

        return max_rid + 1

    def get_path_by_pid(self, tamper_config, pid):
        '''
            @brief 通过pid获得保护路径
            @param tamper_config<string> 配置文件内容
            @param pid<int> 路径ID
        '''
        if not pid:
            return None
        relevant_path = None
        for item in tamper_config['paths']:
            if pid == item['pid']:
                relevant_path = item['path']
                break
        return relevant_path

    def add_process_rule(self, args=None):
        '''
            @brief 添加高级配置的单项规则
            @param pattern<list> 子路径模式列表
            @param rule_type<int> 匹配模式 1. 匹配后缀 2. 匹配中间路径
            #param process<list> 受限进程列表
            @param pid<int> 关联保护路径
            @param is_read<int> 是否允许读 1. 不允许 0. 允许
            @param is_modify<int> 是否允许修改 1. 不允许 0. 允许
            @param is_chmod<int> 是否允许修改权限 1. 不允许 0. 允许
            @param is_chown<int> 是否允许修改拥有者 1. 不允许 0. 允许
            @param is_rename<int> 是否允许重命名  1. 不允许 0. 允许
            @param is_link<int> 是否允许创建软连接  1. 不允许 0. 允许
            @param ps<string> 规则备注
        '''
        ppid = None
        rid = None
        rule_type = None
        pattern = None
        process = None
        pid = None
        is_read = 1
        is_modify = 1
        is_chmod = 1
        is_chown = 1
        is_rename = 1
        is_link = 1
        ps = ""
        if args:
            if 'pattern' in args: pattern = json.loads(args.get('pattern'))
            if 'rule_type' in args: rule_type = int(args.get('rule_type'))
            if 'process' in args: process = json.loads(args.get('process'))
            if 'pid' in args: pid = int(args.get('pid'))
            if 'is_read' in args: is_read = int(args.get('is_read'))
            if 'is_modify' in args: is_modify = int(args.get('is_modify'))
            if 'is_chmod' in args: is_chmod = int(args.get('is_chmod'))
            if 'is_chown' in args: is_chown = int(args.get('is_chown'))
            if 'is_rename' in args: is_rename = int(args.get('is_rename'))
            if 'is_link' in args: is_link = int(args.get('is_link'))
            if 'ps' in args: ps = args.get('ps')

        if not pattern: return public.returnMsg(False, "Parameter error, The subpath does not exist")
        if not rule_type: return public.returnMsg(False, "Parameter error, The matching pattern is not specified")
        if not process: return public.returnMsg(False, "Parameter error, Restricted processes do not exist")
        if not pid: return public.returnMsg(False, "Parameter error, The associated path does not exist")

        tamper_config = self.read_config()

        # 判断关联的路径是否存在
        relevant_path = self.get_path_by_pid(tamper_config, pid)
        if (not relevant_path):
            return public.returnMsg(False, "The associated path does not exist")

            # 通过探查已有的ppid获取一个未被使用ppid
        ppid = self.get_ppid(tamper_config)
        # 由于只有一条规则，rid有且只有为1
        rid = 1

        process_rule = {
            "ppid": ppid,
            "process_id": 0,
            "process_name": process,
            "pid": pid,
            "status": 1,
            "rules": [
                {
                    "rid": rid,
                    "rule_type": rule_type,
                    "pattern": pattern,
                    "is_read": is_read,
                    "is_modify": is_modify,
                    "is_chown": is_chown,
                    "is_rename": is_rename,
                    "is_link": is_link
                }
            ],
            "ps": ps
        }
        if 'processes' not in tamper_config:
            tamper_config['processes'] = []
        tamper_config['processes'].append(process_rule)

        self.save_config(tamper_config)
        public.WriteLog('Tamper-proof for Enterprise',
                        "Add subdirectory configuration: Associated path: {} subdirectory: {} Constrained process: {}".format(
                            relevant_path, pattern, str(process)))
        return public.returnMsg(True, "The security rule was added successfully")

    def remove_process_rule(self, args=None):
        '''
            @brief 删除安全规则
            @param ppid<int> 规则标识符
        '''
        pid = None
        relevant_path = None
        ppid = None
        pattern = None
        process = None
        if args:
            if 'ppid' in args: ppid = int(args.get('ppid'))

        if not ppid: return public.returnMsg(False, "Parameter error, The rule identifier does not exist")

        tamper_config = self.read_config()

        new_processes = []

        for item in tamper_config['processes']:
            if item['ppid'] != ppid:
                new_processes.append(item)
            else:
                pid = item['pid']
                pattern = str(item['rules'][0]['pattern'])
                process = str(item['process_name'])

        relevant_path = self.get_path_by_pid(tamper_config, pid)

        tamper_config['processes'] = new_processes

        self.save_config(tamper_config)

        if relevant_path:
            public.WriteLog('Tamper-proof for Enterprise',
                            "Remove the subdirectory configuration: Associated path: {} subdirectory: {} Constrained process: {}".format(
                                relevant_path, pattern, process))
        return public.returnMsg(True, "Delete rule successfully")

    def modify_process_rule(self, args=None):
        '''
            @brief 修改安全规则
            @param ppid<int> 规则标识符
            @param pattern<list> 子路径模式列表
            @param rule_type<int> 匹配模式 1. 匹配后缀 2. 匹配中间路径
            #param process<list> 受限进程列表
            @param pid<int> 关联保护路径
            @param is_read<int> 是否允许读 1. 不允许 0. 允许
            @param is_modify<int> 是否允许修改 1. 不允许 0. 允许
            @param is_chmod<int> 是否允许修改权限 1. 不允许 0. 允许
            @param is_chown<int> 是否允许修改拥有者 1. 不允许 0. 允许
            @param is_rename<int> 是否允许重命名  1. 不允许 0. 允许
            @param is_link<int> 是否允许创建软连接  1. 不允许 0. 允许
            @param ps<string> 规则备注
        '''
        ppid = None
        rid = 1
        rule_type = None
        pattern = None
        process = None
        pid = None
        is_read = 1
        is_modify = 1
        is_chmod = 1
        is_chown = 1
        is_rename = 1
        is_link = 1
        ps = ""
        if args:
            if 'ppid' in args: ppid = int(args.get('ppid'))
            if 'pattern' in args: pattern = json.loads(args.get('pattern'))
            if 'rule_type' in args: rule_type = int(args.get('rule_type'))
            if 'process' in args: process = json.loads(args.get('process'))
            # if 'pid' in args: pid = args.get('pid')
            if 'is_read' in args: is_read = int(args.get('is_read'))
            if 'is_modify' in args: is_modify = int(args.get('is_modify'))
            if 'is_chmod' in args: is_chmod = int(args.get('is_chmod'))
            if 'is_chown' in args: is_chown = int(args.get('is_chown'))
            if 'is_rename' in args: is_rename = int(args.get('is_rename'))
            if 'is_link' in args: is_link = int(args.get('is_link'))
            if "ps" in args: ps = args.get('ps')

        if not ppid: return public.returnMsg(False, "Parameter error，The rule identifier does not exist")
        if not pattern: return public.returnMsg(False, "Parameter error, The subpath does not exist")
        if not rule_type: return public.returnMsg(False, "Parameter error, The matching pattern is not specified")
        if not process: return public.returnMsg(False, "Parameter error, Restricted processes do not exist")
        # if not pid: return public.returnMsg(False, "Parameter error, The associated path does not exist")

        rule = {
            'rid': rid,
            'rule_type': rule_type,
            'pattern': pattern,
            'is_read': is_read,
            'is_modify': is_modify,
            'is_chmod': is_chmod,
            'is_chown': is_chown,
            'is_rename': is_rename,
            'is_link': is_link
        }
        tamper_config = self.read_config()

        for item in tamper_config['processes']:
            if item['ppid'] == ppid:
                pid = item['pid']
                item['process_name'] = process
                item['rules'] = [
                    rule
                ]
                item['ps'] = ps

        relevant_path = self.get_path_by_pid(tamper_config, pid)

        self.save_config(tamper_config)
        public.WriteLog('Tamper-proof for Enterprise',
                        "Modify the subdirectory configuration: Associated path:{} subdirectory: {} Constrained process: {}".format(
                            relevant_path, pattern, process))
        return public.returnMsg(True, "The security rule was modified successfully")

    def modify_process_status(self, args=None):
        '''
            @brief 修改安全规则的状态 1. 开启防护 2. 关闭防护
            @param ppid<int> 规则标识符
            @param status<int> 规则状态
        '''
        ppid = None
        status = None
        if args:
            if 'ppid' in args: ppid = int(args.get('ppid'))
            if 'status' in args: status = int(args.get('status'))

        if not ppid: return public.returnMsg(False, "Parameter error，The rule identifier does not exist")

        tamper_config = self.read_config()

        for item in tamper_config['processes']:
            if item['ppid'] == ppid:
                item['status'] = status

        self.save_config(tamper_config)
        return public.returnMsg(True, "The security rule state was modified successfully")

    def set_temp_close(self, args=None):
        '''
            @brief 设置临时关闭
            @param expire<int> 过期时间
            @param unit<string> 单位(minute/hour/day)
            @return dict
        '''
        if not args: return public.returnMsg(False, 'Parameter error')
        if not 'expire' in args: return public.returnMsg(False, 'Missing expire parameter')
        if not 'unit' in args: return public.returnMsg(False, 'Missing unit parameter')

        unit = args.unit.strip()
        unit_dict = {
            'minute': 60,
            'hour': 3600,
            'day': 86400
        }
        if not unit in unit_dict.keys():
            return public.returnMsg(False, 'Error in the unit parameter range,Only support: minute/hour/day')

        try:
            expire = int(args.expire)
        except:
            public.returnMsg(False, 'The expire parameter must be an integer')

        end_time = int(time.time() + expire * unit_dict[unit])
        filename = "{}/close_temp.pl".format(self.__tamper_path)
        public.writeFile(filename, str(end_time))
        unit_dict_unit = {
            'minute': 'minute',
            'hour': 'hour',
            'day': 'day'
        }
        public.WriteLog('Tamper-proof for Enterprise',
                        "temporarily closed Tamper-proof: {}{}".format(expire, unit_dict_unit[unit]))
        return public.returnMsg(True,
                                'Tamper-proof has been temporarily turned off ，Protection will be automatically restored after {}{}'.format(
                                    expire, unit_dict_unit[unit]))

    def get_temp_close(self, args=None):
        '''
            @brief 获取临时关闭到期时间
            @return int 到期时间戳
        '''

        filename = "{}/close_temp.pl".format(self.__tamper_path)
        if not os.path.exists(filename):
            return 0

        close_time = public.readFile(filename)
        if not close_time: return 0
        return int(close_time)

    def del_temp_close(self, args=None):
        '''
            @brief 取消临时关闭
            @return dict
        '''
        filename = "{}/close_temp_del.pl".format(self.__tamper_path)
        public.writeFile(filename, '-1')
        public.WriteLog('Tamper-proof for Enterprise', 'Cancels the last temporary tamper proofing operation!')
        return public.returnMsg(True, 'Reactivate protection, effective!')

    def export_config(self, get=None):
        '''
            @brief 导出防篡改配置
            @return dict
        '''
        ps_path = "{}/config_ps.json".format(self.__tamper_path)
        export_path = "/tmp/tamper.conf"

        data = self.read_config()
        if not os.path.exists(ps_path):
            return public.returnMsg(False, 'The specified target configuration does not exist')
        ps_data = public.readFile(ps_path)
        data['ps_data'] = json.loads(ps_data)
        public.writeFile(export_path, json.dumps(data))
        public.WriteLog('Tamper-proof for Enterprise', 'Export the tamper-proof configuration!')
        return public.returnMsg(True, export_path)

    def import_config(self, get):
        '''
            @name 导入配置
            @author law<2023-11-13>
            @param  args
            @return
        '''
        try:
            data_path = "/tmp/tamper.conf"
            if not hasattr(get, 'type'):
                return public.returnMsg(False, 'Parameter error')
            from files import files
            fileObj = files()
            ff = fileObj.upload(get)
            try:
                data = json.loads(public.readFile(data_path))
                if not data:
                    return public.returnMsg(False, 'The import failed and the configuration file is empty！')
            except:
                return public.returnMsg(False, 'The import failed, please do not modify the configuration file！')
            config = self.read_config()
            if ff["status"]:
                types = json.loads(get.type)
                for i in types:
                    if i == "basics":
                        config["is_create"] = data["is_create"]
                        config["is_modify"] = data["is_modify"]
                        config["is_unlink"] = data["is_unlink"]
                        config["is_mkdir"] = data["is_mkdir"]
                        config["is_rmdir"] = data["is_rmdir"]
                        config["is_rename"] = data["is_rename"]
                        config["is_chmod"] = data["is_chmod"]
                        config["is_chown"] = data["is_chown"]
                        config["is_link"] = data["is_link"]
                    elif i == "servername":
                        if "process_names" in types:
                            continue
                        server_list = ["BT-Panel", "pure-ftpd", "sftp-server"]
                        for j in server_list:
                            if j not in config["process_names"] and i in data["process_names"]:
                                config["process_names"].append(i)
                    else:
                        config[i] = data[i]
                self.save_config(config)
                public.writeFile(self.__config_ps_file, json.dumps(data["ps_data"]))
                public.WriteLog('Tamper-proof for Enterprise', 'Import the tamper-proof configuration!')
                return public.returnMsg(True, 'Import successfully')
            return public.returnMsg(False, 'Import failure')
        except Exception as e:
            return public.returnMsg(False, "Import failed, error details:" + str(e))

    ##验证
    def get_tamper_core(self):
        from BTPanel import session, cache
        import requests
        import panelAuth
        if self.__session_name in session: return session[self.__session_name]
        cloudUrl = 'https://brandnew.aapanel.com/api/panel/getSoftList'
        pdata = panelAuth.panelAuth().create_serverid(None)
        url_headers = {}
        if 'token' in pdata:
            url_headers = {"authorization": "bt {}".format(pdata['token'])}
        pdata['environment_info'] = json.dumps(public.fetch_env_info())
        ret = requests.post(cloudUrl, params=pdata, headers=url_headers).json()
        # ret = public.httpPost(cloudUrl, pdata)
        if not ret:
            if not self.__session_name in session: session[self.__session_name] = 1
            return 1
        try:
            for i in ret["list"]:
                if i['name'] == 'tamper_core':
                    if i['endtime'] >= 0:
                        if not self.__session_name in session: session[self.__session_name] = 2;
                        return 2
            if not self.__session_name in session: session[self.__session_name] = 0;
            return 0
        except:
            if not self.__session_name in session: session[self.__session_name] = 1;
            return 1


def _random_name():
    from uuid import uuid4
    return uuid4().hex[::4]
