# coding: utf-8
# +-------------------------------------------------------------------
# | aaPanelLinux面板 x3
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 aaPanel软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: hwliang <hwl@bt.cn>
# +-------------------------------------------------------------------
import json
import re
# +--------------------------------------------------------------------
# |   aaPanel任务管理器
# +--------------------------------------------------------------------
import sys
import traceback
from typing import List, Dict

if not 'class/' in sys.path:
    sys.path.append('class/')
import psutil, os, time, public

try:
    from BTPanel import cache
except:
    import cachelib

    cache = cachelib.SimpleCache()


class task_manager_main:
    Pids = None
    __cpu_time = None
    new_info = {}
    old_info = {}
    new_net_info = {}
    old_net_info = {}
    old_path = '/tmp/bt_task_old.json'
    old_net_path = '/tmp/bt_network_old.json'
    panel_pid = None
    task_pid = None
    __process_net_list = {}

    # 获取当前网络连接信息
    def get_network_list(self, get):
        netstats = psutil.net_connections()
        networkList = []
        for netstat in netstats:
            tmp = {}
            if netstat.type == 1:
                tmp['type'] = 'tcp'
            else:
                tmp['type'] = 'udp'
            tmp['family'] = netstat.family
            tmp['laddr'] = netstat.laddr
            tmp['raddr'] = netstat.raddr
            tmp['status'] = netstat.status
            p = psutil.Process(netstat.pid)
            tmp['process'] = p.name()
            if tmp['process'] in ['BT-Panel', 'gunicorn', 'baota_coll', 'baota_client']: continue
            tmp['pid'] = netstat.pid
            networkList.append(tmp)
            del (p)
            del (tmp)
        networkList = sorted(networkList, key=lambda x: x['status'], reverse=True)
        data = {}
        data['list'] = networkList
        data['state'] = self.get_network()
        if hasattr(get, 'search'):
            if get.search != '':
                data['list'] = self.search_network(data['list'], get.search)
        return data

    # 查询网络
    def search_network(self, data, search):
        try:
            ldata = []
            for i in data:
                if search in i['process'] or search in i['status'] or search in str(i['pid']) or search in i['laddr'][
                    0] or search in str(
                    i['laddr'][1]):
                    ldata.append(i)
                    continue
                if i['raddr'] != 'NONE':
                    for j in i['raddr']:
                        if search in str(j):
                            ldata.append(i)
            return ldata
        except:
            return data

    # get_network_list ——>引用get_network
    def get_network(self):
        try:
            self.get_net_old()
            networkIo = psutil.net_io_counters()[:4]
            self.new_net_info['upTotal'] = networkIo[0]
            self.new_net_info['downTotal'] = networkIo[1]
            self.new_net_info['upPackets'] = networkIo[2]
            self.new_net_info['downPackets'] = networkIo[3]
            self.new_net_info['time'] = time.time()

            if not self.old_net_info: self.old_net_info = {}
            if not 'upTotal' in self.old_net_info:
                time.sleep(0.1)
                networkIo = psutil.net_io_counters()[:4]
                self.old_net_info['upTotal'] = networkIo[0]
                self.old_net_info['downTotal'] = networkIo[1]
                self.old_net_info['upPackets'] = networkIo[2]
                self.old_net_info['downPackets'] = networkIo[3]
                self.old_net_info['time'] = time.time()

            s = self.new_net_info['time'] - self.old_net_info['time']
            networkInfo = {}
            networkInfo['upTotal'] = networkIo[0]
            networkInfo['downTotal'] = networkIo[1]
            networkInfo['up'] = round((float(networkIo[0]) - self.old_net_info['upTotal']) / s, 2)
            networkInfo['down'] = round((float(networkIo[1]) - self.old_net_info['downTotal']) / s, 2)
            networkInfo['downPackets'] = networkIo[3]
            networkInfo['upPackets'] = networkIo[2]
            networkInfo['downPackets_s'] = int((networkIo[3] - self.old_net_info['downPackets']) / s)
            networkInfo['upPackets_s'] = int((networkIo[2] - self.old_net_info['upPackets']) / s)
            cache.set(self.old_net_path, self.new_net_info, 600)
            return networkInfo
        except:
            return None

    # 获取用户列表  从/etc/passwd文件中读取
    def get_user_list(self, get):
        tmpList = public.readFile('/etc/passwd').split("\n")
        userList = []
        self.groupList = self.get_group_list(get)
        for ul in tmpList:
            tmp = ul.split(':')
            if len(tmp) < 6: continue
            userInfo = {}
            userInfo['username'] = tmp[0]
            userInfo['uid'] = tmp[2]
            userInfo['gid'] = tmp[3]
            userInfo['group'] = self.get_group_name(tmp[3])
            userInfo['ps'] = self.get_user_ps(tmp[0], tmp[4])
            userInfo['home'] = tmp[5]
            userInfo['login_shell'] = tmp[6]
            userList.append(userInfo)
        if hasattr(get, 'search'):
            if get.search != '':
                userList = self.search_user(userList, get.search)
        return userList

    # 查询用户
    def search_user(self, data, search):
        try:
            ldata = []
            for i in data:
                if search in i['username'] or search in i['ps'] or search in i['login_shell'] or search in i[
                    'home'] or search in i['group']:
                    ldata.append(i)
            return ldata
        except:
            public.print_log(traceback.format_exc())
            return data

    # 用户名注释：ps   get_user_list——>引用get_user_ps
    def get_user_ps(self, name, ps):
        userPs = {'www': 'aaPanel [www] user', 'root': 'Super administrator', 'mysql': 'The user used to run MySQL',
                  'mongo': 'The user used to run MongoDB',
                  'git': 'git user', 'mail': 'mail', 'nginx': 'Third-party nginx installation package user', 'postfix': 'postfix post office user',
                  'lp': 'Print service account',
                  'daemon': 'System account that controls background processes', 'nobody': 'Anonymous account', 'bin': 'Manage accounts for most commands',
                  'adm': 'Manage some accounts for managing files', 'smtp': 'smtp user'}
        if name in userPs: return userPs[name]
        if not ps: return name
        return ps

    # 外部接口，删除用户，不能删除系统运行环境用户
    def remove_user(self, get):
        users = ['www', 'root', 'mysql', 'shutdown', 'postfix', 'smmsp', 'sshd', 'systemd-network', 'systemd-bus-proxy',
                 'avahi-autoipd', 'mail', 'sync', 'lp', 'adm', 'bin', 'mailnull', 'ntp', 'daemon', 'sys'];
        if get.user in users: return public.returnMsg(False, 'Cannot delete system and environment users!')
        r = public.ExecShell("userdel " + get.user)
        if r[1].find('process') != -1:
            try:
                pid = r[1].split()[-1]
                p = psutil.Process(int(pid))
                pname = p.name()
                p.kill()
                public.ExecShell("pkill -9 " + pname)
                r = public.ExecShell("userdel " + get.user)
            except:
                pass
        if r[1].find('userdel:') != -1: return public.returnMsg(False, r[1]);
        return public.returnMsg(True, 'Successfully deleted!')

    # 获取用户组处理函数  get_user_list——>引用get_group_name
    def get_group_name(self, gid):
        for g in self.groupList:
            if g['gid'] == gid: return g['group']
        return ''

    # 获取服务器的组名和id，从/etc/group中读取。存储到self.groupList,get_user_list——>引用get_group_list
    def get_group_list(self, get):
        tmpList = public.readFile('/etc/group').split("\n")
        groupList = []
        for gl in tmpList:
            tmp = gl.split(':')
            if len(tmp) < 3: continue
            groupInfo = {}
            groupInfo['group'] = tmp[0]
            groupInfo['gid'] = tmp[2]
            groupList.append(groupInfo)
        return groupList;

    # 外部接口 查询服务启动级别 /etc/init.d/
    def get_service_list(self, get):
        init_d = '/etc/init.d/'
        serviceList = []
        for sname in os.listdir(init_d):
            try:
                if str(oct(os.stat(init_d + sname).st_mode)[-3:]) == '644': continue
                serviceInfo = {}
                runlevels = self.get_runlevel(sname)
                serviceInfo['name'] = sname
                serviceInfo['runlevel_0'] = runlevels[0]
                serviceInfo['runlevel_1'] = runlevels[1]
                serviceInfo['runlevel_2'] = runlevels[2]
                serviceInfo['runlevel_3'] = runlevels[3]
                serviceInfo['runlevel_4'] = runlevels[4]
                serviceInfo['runlevel_5'] = runlevels[5]
                serviceInfo['runlevel_6'] = runlevels[6]
                serviceInfo['ps'] = self.get_run_ps(sname)
                serviceList.append(serviceInfo)
            except:
                continue

        data = {}
        data['runlevel'] = self.get_my_runlevel()
        data['serviceList'] = sorted(serviceList, key=lambda x: x['name'], reverse=False)
        data['serviceList'] = self.get_systemctl_list(data['serviceList'], data['runlevel'])
        if hasattr(get, 'search'):
            if get.search != '':
                data['serviceList'] = self.search_service(data['serviceList'], get.search)
        return data

    def search_service(self, data, search):
        try:
            ldata = []
            for i in data:
                if search in i['name'] or search in i['ps']:
                    ldata.append(i)
            return ldata
        except:
            return data

    # 获取系统服务运行级别   get_service_list——>引用get_systemctl_list
    def get_systemctl_list(self, serviceList, runlevel):
        systemctl_user_path = '/usr/lib/systemd/system/'
        systemctl_run_path = '/etc/systemd/system/multi-user.target.wants/'
        if not os.path.exists(systemctl_user_path) or not os.path.exists(systemctl_run_path): return serviceList
        r = '.service'
        for d in os.listdir(systemctl_user_path):
            if d.find(r) == -1: continue;
            if not self.cont_systemctl(d): continue;
            isrun = '<span style="color:red;" title="Click to enable">OFF</span>'
            serviceInfo = {}
            serviceInfo['name'] = d.replace(r, '')
            serviceInfo['runlevel_0'] = isrun
            serviceInfo['runlevel_1'] = isrun
            serviceInfo['runlevel_2'] = isrun
            serviceInfo['runlevel_3'] = isrun
            serviceInfo['runlevel_4'] = isrun
            serviceInfo['runlevel_5'] = isrun
            serviceInfo['runlevel_6'] = isrun
            if os.path.exists(systemctl_run_path + d):
                isrun = '<span style="color:green;" title="Click to disable">ON</span>'
                serviceInfo['runlevel_' + runlevel] = isrun
                serviceInfo['runlevel_3'] = isrun
                serviceInfo['runlevel_5'] = isrun

            serviceInfo['ps'] = self.get_run_ps(serviceInfo['name'])
            serviceList.append(serviceInfo)
        return serviceList

    # 检查服务是否为系统服务get_systemctl_list——>引用cont_systemctl
    def cont_systemctl(self, name):
        conts = ['systemd', 'rhel', 'plymouth', 'rc-', '@', 'init', 'ipr', 'dbus', '-local']
        for c in conts:
            if name.find(c) != -1: return False
        return True

    # 外部接口，设置软件运行环境，不能设置0，6
    def set_runlevel_state(self, get):
        if get.runlevel == '0' or get.runlevel == '6': return public.returnMsg(False,
                                                                               'For safety reasons, this run level cannot be modified directly through the panel')
        systemctl_user_path = '/usr/lib/systemd/system/'
        systemctl_run_path = '/etc/systemd/system/multi-user.target.wants/'
        if os.path.exists(systemctl_user_path + get.serviceName + '.service'):
            runlevel = public.ExecShell('runlevel')[0].split()[1]
            if get.runlevel != runlevel: return public.returnMsg(False,
                                                                 'The service managed by Systemctl cannot be set to a state other than the current run level')
            action = 'enable'
            if os.path.exists(systemctl_run_path + get.serviceName + '.service'): action = 'disable'
            public.ExecShell('systemctl ' + action + ' ' + get.serviceName + '.service')
            return public.returnMsg(True, 'Set successfully!')

        rc_d = '/etc/rc' + get.runlevel + '.d/'
        import shutil;
        for d in os.listdir(rc_d):
            if d[3:] != get.serviceName: continue
            sfile = rc_d + d
            c = 'S'
            if d[:1] == 'S': c = 'K'
            dfile = rc_d + c + d[1:]
            shutil.move(sfile, dfile)
            return public.returnMsg(True, 'Set successfully!')
        return public.returnMsg(False, 'Set failed!')

    # 获取name服务的运行级别 get_service_list ——>引用get_runlevel
    def get_runlevel(self, name):
        rc_d = '/etc/'
        runlevels = []
        for i in range(7):
            isrun = '<span style="color:red;" title="Click to enable">OFF</span>'
            for d in os.listdir(rc_d + 'rc' + str(i) + '.d'):
                if d[3:] == name:
                    if d[:1] == 'S': isrun = '<span style="color:green;" title="Click to disable">ON</span>'
            runlevels.append(isrun)
        return runlevels

    # 外部接口，删除服务。不能删除bt
    def remove_service(self, get):
        if get.serviceName == 'bt': return public.returnMsg(False, 'Cannot end the aaPanel service through the panel!')
        systemctl_user_path = '/usr/lib/systemd/system/'
        if os.path.exists(systemctl_user_path + get.serviceName + '.service'):  return public.returnMsg(False,
                                                                                                        'Services hosted by Systemctl cannot be deleted through the panel');
        public.ExecShell('service ' + get.serviceName + ' stop')
        if os.path.exists('/usr/sbin/update-rc.d'):
            public.ExecShell('update-rc.d ' + get.serviceName + ' remove')
        elif os.path.exists('/usr/sbin/chkconfig'):
            public.ExecShell('chkconfig --del ' + get.serviceName)
        else:
            public.ExecShell("rm -f /etc/rc0.d/*" + get.serviceName)
            public.ExecShell("rm -f /etc/rc1.d/*" + get.serviceName)
            public.ExecShell("rm -f /etc/rc2.d/*" + get.serviceName)
            public.ExecShell("rm -f /etc/rc3.d/*" + get.serviceName)
            public.ExecShell("rm -f /etc/rc4.d/*" + get.serviceName)
            public.ExecShell("rm -f /etc/rc5.d/*" + get.serviceName)
            public.ExecShell("rm -f /etc/rc6.d/*" + get.serviceName)
        filename = '/etc/init.d/' + get.serviceName
        if os.path.exists(filename): os.remove(filename)
        return public.returnMsg(True, 'Successfully deleted!')

    # 外部接口，结束进程，pid30以上
    def kill_process(self, get):
        pid = int(get.pid)
        if pid < 30: return public.returnMsg(False, 'Unable to end the critical process of the system!')
        if not pid in psutil.pids(): return public.returnMsg(False, 'The specified process does not exist!')
        if not 'killall' in get:
            p = psutil.Process(pid)
            if self.is_panel_process(pid): return public.returnMsg(False, 'Unable to end the panel service process')
            p.kill()
            return public.returnMsg(True, 'Process has ended')
        return self.kill_process_all(pid)

    # 结束进程树 kill_process——>引用kill_process_all
    def kill_process_all(self, pid):
        public.print_log(pid)
        if pid < 30: return public.returnMsg(True, 'This process tree has ended!')
        if self.is_panel_process(pid): return public.returnMsg(False, 'Unable to end the panel service process')
        try:
            if not pid in psutil.pids(): public.returnMsg(True, 'This process tree has ended!')
            p = psutil.Process(pid)
            ppid = p.ppid()
            name = p.name()
            p.kill()
            public.ExecShell('pkill -9 ' + name)
            if name.find('php-') != -1:
                public.ExecShell("rm -f /tmp/php-cgi-*.sock")
            elif name.find('mysql') != -1:
                public.ExecShell("rm -f /tmp/mysql.sock")
            elif name.find('nginx') != -1:
                public.ExecShell("rm -f /tmp/mysql.sock")
            self.kill_process_lower(pid)
            if ppid: return self.kill_process_all(ppid)
        except:
            pass
        return public.returnMsg(True, 'This process tree has ended!')

    # 遍历结束pid的子进程 kill_process_all——>引用kill_process_lower
    def kill_process_lower(self, pid):
        pids = psutil.pids()
        for lpid in pids:
            if lpid < 30: continue
            if self.is_panel_process(lpid): continue
            p = psutil.Process(lpid)
            ppid = p.ppid()
            if ppid == pid:
                p.kill()
                return self.kill_process_lower(lpid)
        return True

    # 是否为面板进程
    def is_panel_process(self, pid):
        if not self.panel_pid:
            self.panel_pid = os.getpid()
        if pid == self.panel_pid: return True
        if not self.task_pid:
            try:
                self.task_pid = int(
                    public.ExecShell("ps aux | grep 'python task.py'|grep -v grep|head -n1|awk '{print $2}'")[0])
            except:
                self.task_pid = -1
        if pid == self.task_pid: return True
        return False

    # 外部接口 强制结束会话
    def pkill_session(self, get):
        public.ExecShell("pkill -kill -t " + get.pts)
        return public.returnMsg(True, 'The session was forcibly ended[' + get.pts + ']')

    # 获取启动项
    def get_run_list(self, get):
        runFile = ['/etc/rc.local', '/etc/profile', '/etc/inittab', '/etc/rc.sysinit']
        runList = []
        for rfile in runFile:
            if not os.path.exists(rfile): continue
            bodyR = self.clear_comments(public.readFile(rfile))
            if not bodyR: continue
            stat = os.stat(rfile)
            accept = str(oct(stat.st_mode)[-3:])
            if accept == '644': continue
            tmp = {}
            tmp['name'] = rfile
            tmp['srcfile'] = rfile
            tmp['size'] = os.path.getsize(rfile)
            tmp['access'] = accept
            tmp['ps'] = self.get_run_ps(rfile)
            # tmp['body'] = bodyR
            runList.append(tmp)
        runlevel = self.get_my_runlevel()
        runPath = ['/etc/init.d', '/etc/rc' + runlevel + '.d']
        tmpAll = []
        islevel = False
        for rpath in runPath:
            if not os.path.exists(rpath): continue
            if runPath[1] == rpath: islevel = True
            for f in os.listdir(rpath):
                if f[:1] != 'S': continue
                filename = rpath + '/' + f
                if not os.path.exists(filename): continue
                if os.path.isdir(filename): continue
                if os.path.islink(filename):
                    flink = os.readlink(filename).replace('../', '/etc/')
                    if not os.path.exists(flink): continue
                    filename = flink
                tmp = {}
                tmp['name'] = f
                if islevel: tmp['name'] = f[3:]
                if tmp['name'] in tmpAll: continue
                stat = os.stat(filename)
                accept = str(oct(stat.st_mode)[-3:])
                if accept == '644': continue
                tmp['srcfile'] = filename
                tmp['access'] = accept
                tmp['size'] = os.path.getsize(filename)
                tmp['ps'] = self.get_run_ps(tmp['name'])
                runList.append(tmp)
                tmpAll.append(tmp['name'])
        data = {}
        data['run_list'] = runList
        data['run_level'] = runlevel
        if hasattr(get, 'search'):
            if get.search != '':
                data['run_list'] = self.search_run(data['run_list'], get.search)
        return data

    # 启动项查询
    def search_run(self, data, search):
        try:
            ldata = []
            for i in data:
                if search in i['name'] or search in i['srcfile'] or search in i['ps']:
                    ldata.append(i)
            return ldata
        except:
            return data

    # 服务注释 get_service_list——>引用 get_run_ps
    def get_run_ps(self, name):
        runPs = {'netconsole': 'Web console log', 'network': 'Internet service', 'jexec': 'JAVA', 'tomcat8': 'Apache Tomcat',
                 'tomcat7': 'Apache Tomcat', 'mariadb': 'Mariadb',
                 'tomcat9': 'Apache Tomcat', 'tomcat': 'Apache Tomcat', 'memcached': 'Memcached',
                 'php-fpm-53': 'PHP-5.3', 'php-fpm-52': 'PHP-5.2',
                 'php-fpm-54': 'PHP-5.4', 'php-fpm-55': 'PHP-5.5', 'php-fpm-56': 'PHP-5.6', 'php-fpm-70': 'PHP-7.0',
                 'php-fpm-71': 'PHP-7.1',
                 'php-fpm-72': 'PHP-7.2', 'rsync_inotify': 'rsync', 'pure-ftpd': 'FTP service',
                 'mongodb': 'MongoDB', 'nginx': 'Webserver(Nginx)',
                 'httpd': 'Webserver(Apache)', 'bt': 'aaPanel', 'mysqld': 'MySQL', 'rsynd': 'rsync',
                 'php-fpm': 'PHPservice', 'systemd': 'System core service',
                 '/etc/rc.local': 'User-defined startup script', '/etc/profile': 'Global user environment variables',
                 '/etc/inittab': 'Used to customize the system run level', '/etc/rc.sysinit': 'Script called when the system is initialized',
                 'sshd': 'SSH service', 'crond': 'Plan task service', 'udev-post': 'Equipment management system', 'auditd': 'Audit daemon',
                 'rsyslog': 'rsyslog log service', 'sendmail': 'Mail delivery service', 'blk-availability': 'lvm 2 related',
                 'local': 'User-defined startup script', 'netfs': 'Network file system', 'lvm2-monitor': 'lvm 2 related',
                 'xensystem': 'xen cloud platform related', 'iptables': 'iptables', 'ip6tables': 'iptables for IPv6',
                 'firewalld': 'firewall'}
        if name in runPs: return runPs[name]
        return name

    # 清除注释
    def clear_comments(self, body):
        bodyTmp = body.split("\n")
        bodyR = ""
        for tmp in bodyTmp:
            if tmp.startswith('#'): continue
            if tmp.strip() == '': continue
            bodyR += tmp
        return bodyR

    # 外部接口，获取启动项的文件
    def get_file_body(self, get):
        get.path = get.path.encode('utf-8')
        if not os.path.exists(get.path): return public.returnMsg(False, 'FILE_NOT_EXISTS')
        if os.path.getsize(get.path) > 2097152: return public.returnMsg(False, 'Cannot access file content larger than 2 MB online!')
        return self.clear_comments(public.readFile(get.path))

    # 外部接口，获取计划任务列表
    def get_cron_list(self, get):
        filename = self.get_cron_file()
        tmpList = public.readFile(filename).split("\n")
        cronList = []
        for c in tmpList:
            c = c.strip()
            if c.startswith('#'): continue
            tmp = c.split(' ')
            if len(tmp) < 6: continue
            cronInfo = {}
            cronInfo['cycle'] = self.decode_cron_cycle(tmp)
            if not cronInfo['cycle']: continue
            ctmp = self.decode_cron_connand(tmp)
            cronInfo['command'] = c
            cronInfo['ps'] = ctmp[1]
            cronInfo['exe'] = ctmp[2]
            cronInfo['test'] = ctmp[0]
            cronList.append(cronInfo)
        if hasattr(get, 'search'):
            if get.search != '':
                cronList = self.search_cron(cronList, get.search)
        return cronList

    def search_cron(self, data, search):
        try:
            ldata = []
            for i in data:
                if search in i['command'] or search in i['cycle'] or search in i['ps']:
                    ldata.append(i)
            return ldata
        except:
            return data

    # 外部接口，删除计划任务
    def remove_cron(self, get):
        index = int(get.index)
        cronList = self.get_cron_list(get)
        if index > len(cronList) + 1: return public.returnMsg(False, 'Specified task does not exist!')
        toCron = []
        for i in range(len(cronList)):
            if i == index: continue
            toCron.append(cronList[i]['command'])
        cronStr = "\n".join(toCron) + "\n\n"
        filename = self.get_cron_file()
        public.writeFile(filename, cronStr)
        public.ExecShell("chmod 600 " + filename)
        self.CrondReload()
        return public.returnMsg(True, 'successfully deleted!')

    # 重启cron服务
    def CrondReload(self):
        if os.path.exists('/etc/init.d/crond'):
            public.ExecShell('/etc/init.d/crond reload')
        elif os.path.exists('/etc/init.d/cron'):
            public.ExecShell('service cron restart')
        else:
            public.ExecShell("systemctl reload crond")

    # 添加计划任务备注
    def decode_cron_connand(self, tmp):
        command = ''
        for i in range(len(tmp)):
            if i < 5: continue
            command += tmp[i] + ' '
        ps = 'Unknown task'
        if command.find('/www/server/cron') != -1:
            ps = 'Scheduled tasks added through the aaPanel'
        elif command.find('.acme.sh') != -1:
            ps = 'Let\'s Encrypt certificate renewal task based on acme.sh'
        elif command.find('certbot-auto renew') != -1:
            ps = 'Let\'s Encrypt certificate renewal task based on certbot'

        tmpScript = command.split('>')[0].strip()
        filename = tmpScript.replace('"', '').split()[0]
        # if not os.path.exists(filename): filename = '';
        return command.strip(), ps, filename

    # 解析计划任务执行周期
    def decode_cron_cycle(self, tmp):
        if not tmp[4]: tmp[4] = '*'
        if tmp[4] != '*':
            cycle = 'Every ' + self.toWeek(int(tmp[4])) + ' at ' + tmp[1] + ':' + tmp[0]
        elif tmp[2] != '*':
            if tmp[2].find('*') == -1:
                # cycle = '每月的' + tmp[2] + '日,' + tmp[1] + '时' + tmp[0] + '分';
                cycle = '{hour}:{min} on the {day}th of each month'.format(hour=tmp[1],min=tmp[0],day=tmp[2])
            else:
                # cycle = '每隔' + tmp[2].split('/')[1] + '天' + tmp[1] + '时' + tmp[0] + '分'
                cycle = 'Every {day} days at {hour}:{min}'.format(day=tmp[2].split('/')[1],hour=tmp[1],min=tmp[0])
        elif tmp[1] != '*':
            if tmp[1].find('*') == -1:
                # cycle = '每天的' + tmp[1] + '时' + tmp[0] + '分';
                cycle = '{}:{} every day'.format(tmp[1],tmp[0])
            else:
                # cycle = '每隔' + tmp[1].split('/')[1] + '小时'+ tmp[0] + '分钟';
                cycle = 'Every {} hours and {} minutes'.format(tmp[1].split('/')[1],tmp[0])
        elif tmp[0] != '*':
            if tmp[0].find('*') == -1:
                # cycle = '每小时的第' + tmp[0] + '分钟';
                cycle = '{} minute of every hour'.format(tmp[0])
            else:
                # cycle = '每隔' + tmp[0].split('/')[1] + '分钟';
                cycle = 'Every {} minutes'.format(tmp[0].split('/')[1])
        else:
            return None
        return cycle

    # 数转周
    def toWeek(self, num):
        if num > 6: return ''
        wheres = {
            0: public.getMsg('CRONTAB_SUNDAY'),
            1: public.getMsg('CRONTAB_MONDAY'),
            2: public.getMsg('CRONTAB_TUESDAY'),
            3: public.getMsg('CRONTAB_WEDNESDAY'),
            4: public.getMsg('CRONTAB_THURSDAY'),
            5: public.getMsg('CRONTAB_FRIDAY'),
            6: public.getMsg('CRONTAB_SATURDAY')
        }

        return wheres[num]

    # 获取存放计划任务的路径
    def get_cron_file(self):
        filename = '/var/spool/cron/crontabs/root'
        if os.path.exists(filename): return filename
        filename = '/var/spool/cron/root'
        if not os.path.exists(filename):
            public.writeFile(filename, "")
        return filename

    # ？？？
    def get_exp_user(self, get):
        exp = {}
        exp['bash_profile'] = self.clear_comments(public.readFile('/root/.bash_profile'))
        exp['bash_logout'] = self.clear_comments(public.readFile('/root/.bash_logout'))
        return exp

    # 获取当前会话
    def get_who(self, get):
        whoTmp = public.ExecShell('who')[0]
        tmpList = whoTmp.split("\n")
        whoList = []
        for w in tmpList:
            tmp = w.split()
            if len(tmp) < 5: continue
            whoInfo = {}
            whoInfo['user'] = tmp[0]
            whoInfo['pts'] = tmp[1]
            whoInfo['date'] = tmp[2] + ' ' + tmp[3]
            whoInfo['ip'] = tmp[4].replace('(', '').replace(')', '')
            if len(tmp) > 5:
                whoInfo['date'] = tmp[2] + ' ' + tmp[3] + ' ' + tmp[4]
                whoInfo['ip'] = tmp[5].replace('(', '').replace(')', '')
            whoList.append(whoInfo)
        if hasattr(get, 'search'):
            if get.search != '':
                whoList = self.search_who(whoList, get.search)
        return whoList

    def search_who(self, data, search):
        try:
            ldata = []
            for i in data:
                if search in i['user'] or search in i['ip'] or search in i['date']:
                    ldata.append(i)
            return ldata
        except:
            return data

    # 获取python的路径
    def get_python_bin(self):
        bin_file = '/www/server/panel/pyenv/bin/python'
        if os.path.exists(bin_file):
            return bin_file
        return '/usr/bin/python'

    # 检查process_network_total.py是否运行
    def check_process_net_total(self):
        '''
            @name 检查网络监控进程是否运行
            @author hwliang<2021-09-13>
            @return void
        '''
        _pid_file = '/www/server/panel/logs/process_network_total.pid'
        if os.path.exists(_pid_file):
            pid = public.readFile(_pid_file)
            if os.path.exists('/proc/' + pid): return True

        cmd_file = '/www/server/panel/plugin/task_manager/process_network_total.py'
        python_bin = self.get_python_bin()
        _cmd = 'nohup {} {} 600 &> /tmp/net.log &'.format(python_bin, cmd_file)
        public.ExecShell(_cmd)

    last_net_process = None
    last_net_process_time = 0

    def get_process_net_list(self):
        w_file = '/dev/shm/bt_net_process'
        if not os.path.exists(w_file): return
        self.last_net_process = cache.get('net_process')
        self.last_net_process_time = cache.get('last_net_process')
        net_process_body = public.readFile(w_file)
        if not net_process_body: return
        net_process = net_process_body.split('\n')
        for np in net_process:
            if not np: continue
            tmp = {}
            np_list = np.split()
            if len(np_list) < 5: continue
            tmp['pid'] = int(np_list[0])
            tmp['down'] = int(np_list[1])
            tmp['up'] = int(np_list[2])
            tmp['down_package'] = int(np_list[3])
            tmp['up_package'] = int(np_list[4])
            self.__process_net_list[tmp['pid']] = tmp
        cache.set('net_process', self.__process_net_list, 600)
        cache.set('last_net_process', time.time(), 600)

    def get_process_network(self, pid):
        '''
            @name 获取进程网络流量
            @author hwliang<2021-09-13>
            @param pid<int> 进程ID
            @return tuple
        '''
        if not self.__process_net_list:
            self.get_process_net_list()
        if not self.last_net_process_time: return 0, 0, 0, 0
        if not pid in self.__process_net_list: return 0, 0, 0, 0

        if not pid in self.last_net_process:
            return self.__process_net_list[pid]['up'], self.__process_net_list[pid]['up_package'], \
                self.__process_net_list[pid]['down'], self.__process_net_list[pid]['down_package']

        up = int((self.__process_net_list[pid]['up'] - self.last_net_process[pid]['up']) / (
                time.time() - self.last_net_process_time))
        down = int((self.__process_net_list[pid]['down'] - self.last_net_process[pid]['down']) / (
                time.time() - self.last_net_process_time))
        up_package = int((self.__process_net_list[pid]['up_package'] - self.last_net_process[pid]['up_package']) / (
                time.time() - self.last_net_process_time))
        down_package = int(
            (self.__process_net_list[pid]['down_package'] - self.last_net_process[pid]['down_package']) / (
                    time.time() - self.last_net_process_time))
        return up, up_package, down, down_package

    def get_process_name(self, pid):
        '''
            @name 获取进程名称
            @author hwliang<2021-09-13>
            @param pid<str> 进程ID
            @return str
        '''
        pid_path = '/proc/' + str(pid) + '/comm'
        if not os.path.exists(pid_path): return ''
        pid_file = open(pid_path, 'rb')
        pid_name = pid_file.read().decode('utf-8').strip()
        pid_file.close()
        return pid_name

    # 获取进程信息
    def get_process_list(self, get):
        self.check_process_net_total()
        self.Pids = psutil.pids()
        processList = []
        if type(self.new_info) != dict: self.new_info = {}
        self.new_info['cpu_time'] = self.get_cpu_time()
        self.new_info['time'] = time.time()
        self.get_process_net_list()
        if not 'sortx' in get: get.sortx = 'all'
        info = {}
        info['activity'] = 0
        info['cpu'] = 0.00
        info['mem'] = 0
        info['disk'] = 0
        status_ps = {'sleeping': 'sleeping', 'running': 'running'}
        for pid in self.Pids:
            tmp = {}
            try:
                p = psutil.Process(pid)
                with p.oneshot():
                    p_mem = p.memory_full_info()
                    if p_mem.rss == 0: continue
                    pio = p.io_counters()
                    p_cpus = p.cpu_times()
                    p_state = p.status()
                    if p_state == 'running': info['activity'] += 1
                    if p_state in status_ps: p_state = status_ps[p_state]
                    tmp['exe'] = p.exe()
                    tmp['name'] = p.name()
                    tmp['pid'] = pid
                    tmp['ppid'] = p.ppid()
                    # tmp['create_time'] = int(p.create_time())
                    tmp['status'] = p_state
                    tmp['user'] = p.username()
                    tmp['memory_used'] = p_mem.uss
                    tmp['cpu_percent'] = self.get_cpu_percent(str(pid), p_cpus, self.new_info['cpu_time'])
                    if tmp['name'] == 'BT-Panel' and tmp['cpu_percent'] > 1:
                        tmp['cpu_percent'] = round(tmp['cpu_percent'] % 1, 2)
                    tmp['io_write_bytes'] = pio.write_bytes
                    tmp['io_read_bytes'] = pio.read_bytes
                    tmp['io_write_speed'] = self.get_io_write(str(pid), pio.write_bytes)
                    tmp['io_read_speed'] = self.get_io_read(str(pid), pio.read_bytes)
                    tmp['connects'] = self.get_connects(pid)
                    tmp['threads'] = p.num_threads()
                    tmp['ps'] = self.get_process_ps(tmp['name'], pid, tmp['exe'], p)
                    tmp['up'], tmp['up_package'], tmp['down'], tmp['down_package'] = self.get_process_network(pid)
                    if tmp['cpu_percent'] > 100: tmp['cpu_percent'] = 0.1
                    info['cpu'] += tmp['cpu_percent']
                    info['disk'] += tmp['io_write_speed'] + tmp['io_read_speed']
                processList.append(tmp)
                del (p)
                del (tmp)
            except:
                continue
        cache.set(self.old_path, self.new_info, 600)
        processList = self.__pro_s_s(processList)
        res = True
        if get.sortx == 'status': res = False
        if 'reverse' in get:
            if get.reverse in ['undefined', 'null']:
                get.reverse = 'True'
                get.sortx = 'all'
            if not get.reverse in ['True', 'False']: get.reverse = 'True'
            res_list = {'True': True, 'False': False}
            res = res_list[get.reverse]
        else:
            get.reverse = True
        if get.reverse in ['undefined', 'null']:
            get.reverse = 'True'
            get.sortx = 'all'
        if get.sortx not in ['all']:
            processList = sorted(processList, key=lambda x: x[get.sortx], reverse=res)
        else:
            processList = sorted(processList, key=lambda x: [x['cpu_percent'], x['up'], x['down'], x['io_write_speed'],
                                                             x['io_read_speed'], x['connects'], x['threads'],
                                                             x['memory_used']], reverse=res)
        info['load_average'] = self.get_load_average()
        data = {}
        data['process_list'] = processList
        info['cpu'] = round(info['cpu'], 2)
        info['mem'] = self.get_mem_info()
        data['info'] = info
        if hasattr(get, 'search'):
            if get.search != '':
                data['process_list'] = self.search_pro(data['process_list'], get.search)
        public.writeFile('/jupyter/data.json', json.dumps(data))
        return data

    def get_mem_info(self, get=None):
        mem = psutil.virtual_memory()
        memInfo = {'memTotal': mem.total, 'memFree': mem.free, 'memBuffers': mem.buffers, 'memCached': mem.cached}
        memInfo['memRealUsed'] = memInfo['memTotal'] - memInfo['memFree'] - memInfo['memBuffers'] - memInfo['memCached']
        return memInfo['memRealUsed']

    # 进程备注，name,pid,启动命令
    def get_process_ps(self, name, pid, p_exe=None, p=None):
        processPs = {'mysqld': 'MySQL service',
                     'php-fpm': 'PHP child process',
                     'php-cgi': 'PHP-CGI process',
                     'nginx': 'Nginx service',
                     'httpd': 'Apache service',
                     'sshd': 'SSH service',
                     'pure-ftpd': 'FTP service',
                     'sftp-server': 'SFTP service',
                     'mysqld_safe': 'MySQL service',
                     'firewalld': 'firewalld',
                     'BT-Panel': 'aaPanel',
                     'BT-Task': 'aaPanel',
                     'NetworkManager': 'NetworkManager',
                     'svlogd': 'log daemon',
                     'memcached': 'Memcached',
                     'gunicorn': "gunicorn",
                     "BTPanel": 'aaPanel',
                     'baota_coll': "Baota Cloud Control-Main Control",
                     'baota_client': "Baota Cloud Control-the accused terminal",
                     'node': 'Node.js',
                     'supervisord': 'Supervisor',
                     'rsyslogd': 'rsyslog',
                     'crond': 'cron task',
                     'cron': 'cron task',
                     'rsync': 'rsync',
                     'ntpd': 'Network Time Service',
                     'rpc.mountd': 'NFS mount service',
                     'sendmail': 'sendmail',
                     'postfix': 'postfix',
                     'npm': 'Node.js NPM',
                     'PM2': 'Node.js PM2',
                     'htop': 'htop',
                     'btpython': 'aaPanel btpython',
                     'btappmanagerd': 'btappmanagerd',
                     'dockerd': 'Docker',
                     'docker-proxy': 'Docker',
                     'sleep': 'sleep process'
                     }
        if p_exe:
            if name == 'php-fpm':
                try:
                    php_version = '.'.join(p_exe.split('/')[-3])
                    return 'PHP ' + php_version + ' process'
                except:
                    pass
            elif name == 'python':
                p_exe_arr = p_exe.split('/')
                if p_exe_arr[-1] in ['BT-Task', 'task.py']:
                    return 'aaPanel-task process'
                elif p_exe_arr[-1] in ['BT-Panel', 'runserver.py']:
                    return 'aaPanel-main process'
                elif p_exe.find('process_network_total') != -1:
                    return 'aaPanel-Network '
                if p:
                    cmdline = ' '.join(p.cmdline()).strip()
                    cmdline_arr = cmdline.split('/')
                    if cmdline.find('process_network_total') != -1:
                        return 'aaPanel-Network'
                    if cmdline_arr[-1] in ['BT-Task', 'task.py']:
                        return 'aaPanel-task process'
                    elif cmdline_arr[-1] in ['BT-Panel', 'runserver.py']:
                        return 'aaPanel-main process'
                    elif cmdline.find('process_network_total') != -1:
                        return 'aaPanel-Network'
                    elif cmdline.find('tamper_proof_service') != -1:
                        return 'aaPanel-tamper proof'
                    elif cmdline.find('syssafe') != -1:
                        return 'aaPanel-System hardening'
                    elif cmdline.find('btwaf') != -1:
                        return 'aaPanel-WAF'
                    elif cmdline.find('acme') != -1:
                        return 'aaPanel-Renew SSL'
                    elif cmdline.find('psync') != -1:
                        return 'aaPanel-One-click migration'
                    elif cmdline.find('/panel/plugin') != -1:
                        return 'aaPanel-plugin process'
                    elif cmdline.find('/www/server/cron/') != -1:
                        return 'aaPanel-cron'
            elif name == 'nginx':
                if p.username() == 'www':
                    return 'Nginx child process'
                else:
                    return 'Nginx main process'
            elif p_exe == '/usr/bin/bash':
                cmdline = ' '.join(p.cmdline()).strip()
                if cmdline.find('/www/server/cron/') != -1:
                    return 'aaPanel-cron'
                elif cmdline.find('/www/server/panel/plugin') != -1:
                    return 'aaPanel-plugin'

        if name in processPs: return processPs[name]
        if name == 'python':
            if self.is_panel_process(pid): return 'aaPanel'

        if p_exe:
            exe_keys = {
                '/www/server/panel/pyenv/': 'aaPanel-plugin',
                '/www/server/cron/': 'aaPanel-cron ',
                'pm2': 'PM2',
                'PM2': 'PM2',
                'nvm': 'NVM Node.js',
                'npm': 'NPM Node.js'
            }

            for k in exe_keys.keys():
                if p_exe.find(k) != -1: return exe_keys[k]
                if name.find(k) != -1: return exe_keys[k]

        return name

    def __get_children(self, pid: int) -> List:
        try:
            p = psutil.Process(pid)  # pid为指定进程的进程号
            children = p.children(recursive=True)  # 获取指定进程的所有子进程
            pids = []
            for child in children:
                pids.append(child.pid)
            return pids
        except:
            return []

    # 获取平均负载
    def get_load_average(self):
        c = os.getloadavg()
        data = {}
        data['1'] = float(c[0])
        data['5'] = float(c[1])
        data['15'] = float(c[2])
        return data

    # 获取当前运行级别  get_service_list ——> 引用get_my_runlevel
    def get_my_runlevel(self):
        try:
            runlevel = public.ExecShell('runlevel')[0].split()[1]
        except:
            runlevel_dict = {"multi-user.target": '3', 'rescue.target': '1', 'poweroff.target': '0',
                             'graphical.target': '5', "reboot.target": '6'}
            r_tmp = public.ExecShell('systemctl get-default')[0].strip()
            if r_tmp in runlevel_dict:
                runlevel = runlevel_dict[r_tmp]
            else:
                runlevel = '3'
        return runlevel

    # 获取进程的详细信息
    def get_process_info(self, get):
        pid = int(get.pid)
        try:
            p = psutil.Process(pid)
            processInfo = {}
            p_mem = self.object_to_dict(p.memory_full_info())
            pio = p.io_counters()
            # p_cpus= p.cpu_times()
            processInfo['exe'] = p.exe()
            processInfo['name'] = p.name();
            processInfo['pid'] = pid;
            processInfo['ppid'] = p.ppid()
            processInfo['pname'] = 'sys'
            if processInfo['ppid'] != 0: processInfo['pname'] = psutil.Process(processInfo['ppid']).name()
            processInfo['comline'] = p.cmdline()
            processInfo['create_time'] = int(p.create_time())
            processInfo['open_files'] = self.list_to_dict(p.open_files())
            processInfo['status'] = p.status();
            processInfo['user'] = p.username();
            processInfo['memory_full'] = p_mem
            processInfo['io_write_bytes'] = pio.write_bytes;
            processInfo['io_read_bytes'] = pio.read_bytes;
            processInfo['connects'] = self.get_connects(pid)
            processInfo['threads'] = p.num_threads()
            processInfo['ps'] = self.get_process_ps(processInfo['name'], pid, processInfo['exe'], p)
        except:
            return public.returnMsg(False, 'The specified process is closed!')
        return processInfo

    # 获取进程连接数
    def get_connects(self, pid):
        connects = 0
        try:
            if pid == 1: return connects
            tp = '/proc/' + str(pid) + '/fd/'
            if not os.path.exists(tp): return connects
            for d in os.listdir(tp):
                fname = tp + d
                if os.path.islink(fname):
                    l = os.readlink(fname)
                    if l.find('socket:') != -1: connects += 1
        except:
            pass
        return connects

    # 获取进程io写
    def get_io_write(self, pid, io_write):
        self.get_old()
        disk_io_write = 0
        if not self.old_info: self.old_info = {}
        if not pid in self.old_info:
            self.new_info[pid]['io_write'] = io_write
            return disk_io_write
        if not 'time' in self.old_info: self.old_info['time'] = self.new_info['time']
        io_end = (io_write - self.old_info[pid]['io_write'])
        if io_end > 0:
            disk_io_write = io_end / (time.time() - self.old_info['time'])
        self.new_info[pid]['io_write'] = io_write
        if disk_io_write > 0: return int(disk_io_write)
        return 0

    # 获取io读
    def get_io_read(self, pid, io_read):
        self.get_old()
        disk_io_read = 0
        if not self.old_info: self.old_info = {}
        if not pid in self.old_info:
            self.new_info[pid]['io_read'] = io_read
            return disk_io_read
        if not 'time' in self.old_info: self.old_info['time'] = self.new_info['time']
        io_end = (io_read - self.old_info[pid]['io_read'])
        if io_end > 0:
            disk_io_read = io_end / (time.time() - self.old_info['time'])
        self.new_info[pid]['io_read'] = io_read
        if disk_io_read > 0: return int(disk_io_read)
        return 0

    # 获取cpu使用率
    def get_cpu_percent(self, pid, cpu_times, cpu_time):
        self.get_old()
        percent = 0.00
        process_cpu_time = self.get_process_cpu_time(cpu_times)
        if not self.old_info: self.old_info = {}
        if not pid in self.old_info:
            self.new_info[pid] = {}
            self.new_info[pid]['cpu_time'] = process_cpu_time
            return percent
        percent = round(
            100.00 * (process_cpu_time - self.old_info[pid]['cpu_time']) / (cpu_time - self.old_info['cpu_time']), 2)
        self.new_info[pid] = {}
        self.new_info[pid]['cpu_time'] = process_cpu_time
        if percent > 0: return percent
        return 0.00

    def get_old(self):
        if self.old_info: return True
        # if not os.path.exists(self.old_path): return False
        data = cache.get(self.old_path)
        if not data: return False
        # data = json.loads(data)
        if not data: return False
        self.old_info = data
        del (data)
        return True

    def get_net_old(self):
        if self.old_net_info: return True
        # if not os.path.exists(self.old_net_path): return False
        data = cache.get(self.old_net_path)
        if not data: return False
        # data = json.loads(data)
        if not data: return False
        self.old_net_info = data
        del (data)
        return True

    def get_process_cpu_time(self, cpu_times):
        cpu_time = 0.00
        for s in cpu_times: cpu_time += s
        return cpu_time

    def get_cpu_time(self):
        if self.__cpu_time: return self.__cpu_time
        self.__cpu_time = 0.00
        s = psutil.cpu_times()
        self.__cpu_time = s.user + s.system + s.nice + s.idle
        return self.__cpu_time

    def to_size(self, size):
        d = ('b', 'KB', 'MB', 'GB', 'TB')
        s = d[0]
        for b in d:
            if size < 1024: return size, b
            size = size / 1024
            s = b
        return size, b

    def GoToProcess(self, name):
        ps = ['sftp-server', 'login', 'nm-dispatcher', 'irqbalance', 'qmgr', 'wpa_supplicant', 'lvmetad', 'auditd',
              'master', 'dbus-daemon',
              'tapdisk', 'sshd', 'init', 'ksoftirqd', 'kworker', 'kmpathd', 'kmpath_handlerd', 'python', 'kdmflush',
              'bioset', 'crond', 'kthreadd',
              'migration', 'rcu_sched', 'kjournald', 'iptables', 'systemd', 'network', 'dhclient', 'systemd-journald',
              'NetworkManager', 'systemd-logind',
              'systemd-udevd', 'polkitd', 'tuned', 'rsyslogd']
        return name in ps

    def object_to_dict(self, obj):
        result = {}
        for name in dir(obj):
            value = getattr(obj, name)
            if not name.startswith('__') and not callable(value) and not name.startswith('_'): result[name] = value
        return result

    def list_to_dict(self, data):
        result = []
        for s in data:
            result.append(self.object_to_dict(s))
        return result

    # 添加进程查找
    def search_pro(self, data, search):
        try:
            ldata = []
            for i in data:
                if search in i['name'] or search in i['exe'] or search in i['ps'] or search in i[
                    'user'] or search in str(i['pid']) or search in i['status']:
                    ldata.append(i)
                elif hasattr(i, 'children'):
                    for k in i['children']:
                        if search in k['name'] or search in k['exe'] or search in k['ps'] or search in k[
                            'user'] or search in str(k['pid']):
                            ldata.append(i)
            return ldata
        except:
            public.print_log(traceback.format_exc())
            return data

    # 进程折叠，将子进程折叠到父进程下，并将使用资源累加。
    def __pro_s_s(self, data: List) -> List:
        """
        将子进程合并到父进程中
        :param data:进程列表
        :return:合并后的进程列表增加children字段
        """
        data1 = []
        children_set = {'childrens': []}
        for i in data:
            if i['pid'] > 30 and i['ppid'] == 1:
                children = self.__get_children(i['pid'])
                if children != []: children_set[i['pid']] = children
                children_set['childrens'] += children
        for i in data:
            if i['pid'] in children_set:
                i['children'] = []
                for j in data:
                    if j['pid'] in children_set[i['pid']]:
                        i['children'].append(j)
                        i['memory_used'] += j['memory_used']
                        i['cpu_percent'] = round(i['cpu_percent'] + j['cpu_percent'], 2)
                        i['io_write_bytes'] += j['io_write_bytes']
                        i['io_read_bytes'] += j['io_read_bytes']
                        i['io_write_speed'] += j['io_write_speed']
                        i['io_read_speed'] += j['io_read_speed']
                        i['connects'] += j['connects']
                        i['threads'] += j['threads']
                        i['up'] += j['up']
                        i['up_package'] += j['up_package']
                        i['down'] += j['down']
                        i['down_package'] += j['down_package']
                data1.append(i)
            elif i['pid'] not in children_set['childrens']:
                data1.append(i)
        return data1

