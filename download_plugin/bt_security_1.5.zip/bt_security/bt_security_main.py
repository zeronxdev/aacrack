# coding: utf-8
# +-------------------------------------------------------------------
# | aaPanel x3
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2017 aaPanel(https://aapanel.com) All rights reserved.
# +-------------------------------------------------------------------
# | Author: lkq <lkq@bt.com>
# +-------------------------------------------------------------------
# +--------------------------------------------------------------------
# |   宝塔防提权
# +--------------------------------------------------------------------
import sys, os
if sys.version_info[0] == 2:
    reload(sys)
    sys.setdefaultencoding('utf-8')
os.chdir('/www/server/panel')
sys.path.append("class/")
import public, json,time,re
if __name__ != '__main__':
    from panelAuth import panelAuth

class bt_security_main:
    __session_name = None
    __etc='/usr/local/usranalyse/etc/usranalyse.ini'
    __lib='/usr/local/usranalyse/lib/libusranalyse.so'
    __disable='/usr/local/usranalyse/sbin/usranalyse-disable'
    __ensable='/usr/local/usranalyse/sbin/usranalyse-enable'
    __log='/usr/local/usranalyse/logs/'
    __security_path='/www/server/panel/plugin/bt_security'
    __user_data=None
    __bt_security='/etc/ld.so.preload'
    __to_msg='/www/server/panel/plugin/bt_security/msg.conf'

    def __init__(self):
        pass

    '''判断是否存在日志目录'''
    def check_log_file(self,get):
        if not os.path.exists(self.__log+'log/root'):
            public.ExecShell('mkdir -p %s && chmod 777 %s'%(self.__log+'log/root',self.__log+'log'))
            public.ExecShell('chmod 700 %s' % (self.__log + 'log/root'))
        data=self.system_user(get)
        for i in data:
            if i[0]=='mysql' or i[0]=='www' or i[0]=='redis':
                if not os.path.exists(self.__log+'log/'+i[0]):
                    public.ExecShell('mkdir -p %s && chmod 777 %s ' % (self.__log+'log/'+i[0], self.__log+'log/'+i[0]))
        if not os.path.exists(self.__log + 'total/root'):
            public.ExecShell('mkdir -p %s && chmod 777 %s' % (self.__log + 'total/root', self.__log + 'total'))
            public.ExecShell('chmod 700 %s' % (self.__log + 'total/root'))
        data = self.system_user(get)
        for i in data:
            if i[0] == 'mysql' or i[0] == 'www' or i[0] == 'redis':
                if not os.path.exists(self.__log + 'total/' + i[0]):
                    public.ExecShell('mkdir -p %s && chmod 777 %s ' % (self.__log + 'total/' + i[0], self.__log + 'total/' + i[0]))
        for i in self.system_user(get):
            self.mkdir_user_path(i[0])
        return True

    '''建立用户的统计目录和日志记录'''
    def mkdir_user_path(self,user):
        if not os.path.exists(self.__log+'/log/'+user):
            public.ExecShell('mkdir -p %s && chmod 777 %s'%(self.__log+'/log/'+user,self.__log+'/log/'+user))
        if not os.path.exists(self.__log+'/total/'+user):
            public.ExecShell('mkdir -p %s && chmod 777 %s' % (self.__log + '/total/' + user, self.__log + '/total/' + user))

    #验证文件的完整性
    def check_file(self):
        if os.path.exists(self.__etc) and os.path.exists(self.__lib) and os.path.exists(self.__disable) and os.path.exists(self.__ensable):
            return True
        return False

    '''
    验证是否购买, 2为购买 1 为需要再次确认 0 未购买 
    '''
    def get_bt_security_drive(self):
        import requests
        import panelAuth
        from BTPanel import session
        if self.__session_name in session: return session[self.__session_name]
        cloudUrl = 'https://brandnew.aapanel.com/api/panel/getSoftList'
        pdata = panelAuth.panelAuth().create_serverid(None)
        url_headers = {}
        if 'token' in pdata:
            url_headers = {"authorization": "bt {}".format(pdata['token'])}
        pdata['environment_info'] = json.dumps(public.fetch_env_info())
        ret = requests.post(cloudUrl, params=pdata, headers=url_headers).json()
        # ret = public.httpPost(cloudUrl, pdata)
        if not ret:
            if not self.__session_name in session: session[self.__session_name] = 1
            return 1
        try:
            for i in ret["list"]:
                if i['name'] == 'bt_security':
                    if i['endtime'] >= 0:
                        if not self.__session_name in session: session[self.__session_name] = 2;
                        return 2
            if not self.__session_name in session: session[self.__session_name] = 0;
            return 0
        except:
            if not self.__session_name in session: session[self.__session_name] = 1;
            return 1

    '''读取用户信息'''
    def system_user(self,get):
        if not os.path.exists('/etc/passwd'):return  []
        user_data=open('/etc/passwd','r')
        ret=[]
        for i in user_data:
            if i:
                i=i.strip().split(':')
                if len(i)<4:continue
                ret2=[]
                ret2.append(i[0])
                ret2.append(i[2])
                ret2.append(i[-1])
                ret.append(ret2)
        return  ret

    '''查看天数跟总的次数'''
    def get_day(self,get):
        try:
            if not  os.path.exists(self.__security_path+'/day.json'):
                public.writeFile(self.__security_path + '/day.json', {"day": int(time.time())})
                day=0
            else:
                day=json.loads(public.ReadFile(self.__security_path+'/day.json'))['day']
                day=int((int(time.time())-day)/86400)
        except:
            public.writeFile(self.__security_path+'/day.json',{"day":int(time.time())})
            day=0
        #获取总的次数
        if os.path.exists(self.__log+'total/total.txt'):
            ret=public.ReadFile(self.__log+'total/total.txt')
            data=re.findall('total=(\d+)',ret)
            if not data:totla=0
            try:
                totla=int(data[0])
            except:
                totla = 0
        else:
            totla=0
        return {'day':day,'totla':totla}

    '''判断这个用户是否开启'''
    def check_open_user(self,uid):
        if not os.path.exists(self.__etc):return False
        user_etc=public.ReadFile(self.__etc)
        if re.search('\nuserstop_chain = "stop_uid:(.+)"', user_etc):
            user_data=re.search('\nuserstop_chain = "stop_uid:(.+)"', user_etc).group(1).split(',')

            if uid in user_data:return True
        else:
            if  re.search('\nuserstop_chain = "stop_uid:"', user_etc):return False
            #获取不到。说明配置文件有问题
            user_etc=re.sub('\noutput = file:/usr/local/usranalyse/logs','\noutput = file:/usr/local/usranalyse/logs\nuserstop_chain = "stop_uid:www,redis,mysql"\n',user_etc)
            public.ReadFile(self.__etc,user_etc)
            if uid in ['www','mysql','redis']: return True
        return False

    '''统计用户'''
    def get_user_totla(self,uid,day):
        ret={'totla':0,"day_totla":0}
        if not os.path.exists(self.__log+'total/'+uid):return ret
        if not os.path.exists(self.__log+'total/'+uid+'/total.txt'):
            return ret
        else:
            ret3 = public.ReadFile(self.__log+'total/'+uid+'/total.txt')
            data = re.findall('total=(\d+)', ret3)
            if not data: totla = 0
            try:
                totla = int(data[0])
            except:
                totla = 0
        if not os.path.exists(self.__log + 'total/' + uid + '/'+day+'.txt'):
            day_totla=0
        else:
            ret2 = public.ReadFile(self.__log + 'total/' + uid + '/'+day+'.txt')
            data = re.findall('total=(\d+)', ret2)
            if not data: day_totla = 0
            try:
                day_totla = int(data[0])
            except:
                day_totla = 0
        ret = {'totla': totla, "day_totla": day_totla}
        return ret

    '''处理时间'''
    def check_day(self,day):
        day=day.split('-')
        if day[1][0]=='0':
            day[1]=day[1][1]
        if day[2][0]=='0':
            day[2]=day[2][1]
        return '-'.join(day)

    '''查看用户是否开启日志'''
    def _check_user_log(self,uid):
        if not os.path.exists(self.__etc): return True
        user_etc = public.ReadFile(self.__etc)
        if re.search('\nfilter_chain = ".+;exclude_uid:(.+)"', user_etc):
            user_data = re.search('\nfilter_chain = ".+;exclude_uid:(.+)"', user_etc).group(1).split(',')
            if uid in user_data: return False
        else:
            if re.search('\nfilter_chain = ".+;exclude_uid:"', user_etc):
                return True
        return True

    '''判断是否存在这个uid'''
    def _check_uid(self,uid):
        for i in self.system_user(None):
            if i[1]==uid:return True
        return False

    '''获取日志列表 and  获取禁止的列表'''
    def get_exid_expr(self,user_etc):
        ex_pr = []
        ex_id=[]
        if not re.search('\nfilter_chain = "exclude_spawns_of:.+',user_etc):
            user_etc2 = re.sub('\noutput = file:/usr/local/usranalyse/logs',
                              '\noutput = file:/usr/local/usranalyse/logs\nfilter_chain = "exclude_spawns_of:crond;exclude_uid:"\n',
                              user_etc)
            public.writeFile(self.__etc, user_etc2)
            return {"ex_id":ex_id,"ex_pr":ex_pr,"user_etc":user_etc2}
        if re.search('\nfilter_chain = "exclude_spawns_of:(.+);exclude_uid:',user_etc):
            ex_pr=re.search('\nfilter_chain = "exclude_spawns_of:(.+);exclude_uid:', user_etc).group(1).split(',')
        else:
            if re.search('\nfilter_chain = "exclude_spawns_of:;exclude_uid:', user_etc):
                ex_pr=[]
        if re.search('\nfilter_chain = "exclude_spawns_of:.+;exclude_uid:(.+)"',user_etc):
            ex_id=re.search('\nfilter_chain = "exclude_spawns_of:.+;exclude_uid:(.+)"', user_etc).group(1).split(',')

        if re.search('\nfilter_chain = "exclude_spawns_of:;exclude_uid:(.+)"', user_etc):
            ex_id = re.search('\nfilter_chain = "exclude_spawns_of:;exclude_uid:(.+)"', user_etc).group(1).split(',')

        if re.search('\nfilter_chain = "exclude_spawns_of:.+;exclude_uid:"', user_etc):
            ex_id = []
        if re.search('\nfilter_chain = "exclude_spawns_of:;exclude_uid:"', user_etc):
            ex_id = []
        return {"ex_id":ex_id,"ex_pr":ex_pr,"user_etc":user_etc}

    '''关闭用户日志'''
    def stop_user_log(self,get):
        '''参数一个 uid'''
        if not 'uid' in get:return public.returnMsg(False,'Missing parameter [ uid ]')
        uid=get.uid.strip()
        if not self._check_uid(uid):return public.returnMsg(False,'This UID does not exist')
        if not os.path.exists(self.__etc): return public.returnMsg(False,'Configuration file does not exist')
        user_etc = public.ReadFile(self.__etc)
        user_data=self.get_exid_expr(user_etc)
        user_data2=[]
        if uid in user_data['ex_id']:return public.returnMsg(False,'Already exists, please do not submit again')
        [user_data2.append(x) for x in user_data['ex_id']]
        user_data2.append(uid)
        user_data['user_etc'] = re.sub('\nfilter_chain = "exclude_spawns_of:%s;exclude_uid:%s"' %(','.join(user_data['ex_pr']),','.join(user_data['ex_id'])),
                          '\nfilter_chain = "exclude_spawns_of:%s;exclude_uid:%s"' %(','.join(user_data['ex_pr']),','.join(user_data2)), user_data['user_etc'])
        public.writeFile(self.__etc, user_data['user_etc'])
        return public.returnMsg(True, 'Setup successfully!')

    '''开启用户日志'''
    def start_user_log(self,get):
        '''uid'''
        if not 'uid' in get:return public.returnMsg(False,'Missing parameter [ uid ]')
        uid=get.uid.strip()
        if not self._check_uid(uid):return public.returnMsg(False,'This UID does not exist')
        if not os.path.exists(self.__etc): return public.returnMsg(False,'Configuration file does not exist')
        user_etc = public.ReadFile(self.__etc)
        user_data=self.get_exid_expr(user_etc)
        user_data2=[]
        if not uid in user_data['ex_id']: return public.returnMsg(False, 'Already exists, please do not submit again')
        for i in user_data['ex_id']:
            if i == uid: continue
            user_data2.append(i)
        user_data['user_etc'] = re.sub('\nfilter_chain = "exclude_spawns_of:%s;exclude_uid:%s"' %(','.join(user_data['ex_pr']),','.join(user_data['ex_id'])),
                          '\nfilter_chain = "exclude_spawns_of:%s;exclude_uid:%s"' %(','.join(user_data['ex_pr']),','.join(user_data2)), user_data['user_etc'])
        public.writeFile(self.__etc, user_data['user_etc'])
        return public.returnMsg(True, 'Setup successfully!')

    def ps(self,uid):
        if uid[0]=='root':return 'Administrator (can login)'
        if uid[1]=='0':return 'Administrator (can login)'
        if uid[0]=='www':return 'Web user(nologin)'
        if uid[0] == 'mysql': return 'Mysql user(nologin)'
        if uid[0] == 'redis': return 'Redis user(nologin)'
        if uid[2] =='/bin/bash':return '%s (can login)'%uid[0]
        else:
            return '%s (nologin)' % uid[0]

    '''每个用户的总次数/每日次数'''
    def user_totla(self,get):
        if not 'day' in get: get.day = time.strftime("%Y-%m-%d", time.localtime())
        system_user=self.system_user(get)
        for i in system_user:
            data=self.get_user_totla(i[0],self.check_day(get.day))
            i.append(self.check_open_user(i[0]))
            i.append(data)
            i.append(self._check_user_log(i[1]))
            i.append(self.ps(i))

        return sorted(system_user, key=lambda x: x[4]['totla'], reverse=True)

    '''查看是否开启防提权'''
    def get_bt_security(self,get):
        data=public.ReadFile(self.__bt_security)
        if re.search(self.__lib,data):
            return True
        return False

    '''关闭防提权'''
    def stop_bt_security(self,get):
        if not os.path.exists(self.__lib):return public.returnMsg(False, 'Lib file is missing, please reinstall and try')
        data = public.ReadFile(self.__bt_security)
        if not re.search(self.__lib, data):
            self.__write_log('Turn off the anti-intrusion master switch successfully')
            return public.returnMsg(True, 'Closed successfully')
        if os.path.exists(self.__disable):
            public.ExecShell(self.__disable)
            if not re.search(self.__lib, data):
                self.__write_log('Turn off the anti-intrusion master switch successfully')
                return public.returnMsg(True, 'Closed successfully')
            else:
                data=re.sub(self.__lib,'',data)
                public.writeFile(self.__bt_security,data)
                self.__write_log('Turn off the anti-intrusion master switch successfully')
                return public.returnMsg(True, 'Closed successfully')
        else:
            data=re.sub(self.__lib, '', data)
            public.writeFile(self.__bt_security, data)
            self.__write_log('Turn off the anti-intrusion master switch successfully')
            return public.returnMsg(True, 'Closed successfully')

    '''开启防提权'''
    def start_bt_security(self,get):
        from BTPanel import session, cache
        '''
        if not self.__session_name in session:
            ret = self.get_bt_security_drive()
            if ret == 0:
                self.stop_bt_security(get)
                return public.returnMsg(False, 'Plugin not purchased or expired!')
        '''
        if not os.path.exists(self.__lib):return public.returnMsg(False, 'Lib file is missing, please reinstall and try')
        data2 = public.ReadFile(self.__bt_security)
        if re.search(self.__lib, data2):
            self.__write_log('Turn on the anti-intrusion master switch successfully')
            return public.returnMsg(True, 'Open successfully')
        if os.path.exists(self.__ensable):
            public.ExecShell(self.__ensable)
            data = public.ReadFile(self.__bt_security)
            if re.search(self.__lib, data):
                self.__write_log('Turn on the anti-intrusion master switch successfully')
                return public.returnMsg(True, 'Open successfully')
            else:
                public.writeFile(self.__bt_security,self.__lib)
                self.__write_log('Turn on the anti-intrusion master switch successfully')
                return public.returnMsg(True, 'Open successfully')
        else:
            public.writeFile(self.__bt_security, self.__lib)
            self.__write_log('Turn on the anti-intrusion master switch successfully')
            return public.returnMsg(True, 'Open successfully')
    '''
    显示统计/每天/总/日志
    '''
    def get_total_all(self,get):
        from BTPanel import session, cache
        '''
        if not self.__session_name in session:
            ret = self.get_bt_security_drive()
            if ret == 0:
                self.stop_bt_security(get)
                return public.returnMsg(False, 'Plugin not purchased or expired!')
        '''

        if not self.check_file():return  {"status":False,"msg":"This plugin has not been installed successfully, please reinstall"}
        self.check_log_file(get)
        if not 'day' in get:get.day=time.strftime("%Y-%m-%d", time.localtime())
        ret={}
        ret['totla_days']=self.get_day(get)['day']
        ret['totla_times'] = self.get_day(get)['totla']
        ret['system_user']=self.user_totla(get)
        ret['open']=self.get_bt_security(get)
        ret['status']=True
        return ret

    '''获取当前用户的日志日期'''
    def get_logs_list(self, get):
        path = '/usr/local/usranalyse/logs/log/'+get.user
        if not os.path.exists(path):return []
        data = []
        for fname in os.listdir(path):
            if re.search('(\d+-\d+-\d+).txt$',fname):
                tmp = fname.replace('.txt', '')
                data.append(tmp)
        return sorted(data, reverse=True)

    '''获取用户的日志'''
    def get_safe_logs(self, path,p=1,num=11):
        try:
            import cgi
            pythonV = sys.version_info[0]
            if not os.path.exists(path): return '111';
            start_line = (p - 1) * num
            count = start_line + num
            fp = open(path, 'rb')
            buf = ""
            try:
                fp.seek(-1, 2)
            except:
                return []
            if fp.read(1) == "\n": fp.seek(-1, 2)
            data = []
            b = True
            n = 0
            for i in range(count):
                while True:
                    newline_pos = str.rfind(buf, "\n")
                    pos = fp.tell()
                    if newline_pos != -1:
                        if n >= start_line:
                            line = buf[newline_pos + 1:]
                            try:
                                tmp_data = json.loads(cgi.escape(line))
                                data.append(tmp_data)
                            except:
                                pass
                        buf = buf[:newline_pos]
                        n += 1
                        break
                    else:
                        if pos == 0:
                            b = False
                            break
                        to_read = min(4096, pos)
                        fp.seek(-to_read, 1)
                        t_buf = fp.read(to_read)
                        if pythonV == 3: t_buf = t_buf.decode('utf-8')
                        buf = t_buf + buf
                        fp.seek(-to_read, 1)
                        if pos - to_read == 0:
                            buf = "\n" + buf
                if not b: break;
            fp.close()
        except:
            data = []
        return data

    def get_user_log(self,get):
        '''
        四个参数 user  day
        user --> 用户
        day---> 时间  2020-06-01
        p ---> 页数
        num -->数量
        '''
        if not 'day' in get: get.day = time.strftime("%Y-%m-%d", time.localtime())
        user=get.user.strip()
        path=self.__log+'log/'+user+'/'+self.check_day(get.day)+'.txt'
        if not os.path.exists(path):
            return []
        if not 'p' in get:get.p=1
        if not 'num'in get:get.num=10
        return self.get_safe_logs(path=path,p=int(get.p),num=int(get.num))



    '''验证用户是否是root'''
    def _check_user(self,user):
        system_user = self.system_user(None)
        for i in system_user:
            if i[0] == user:
                if i[1]=='0':return True
        return False

    '''用户开启防提权'''
    def start_user_security(self,get):
        '''
        参数一个
        用户名-->user
        '''
        user_data2=[]
        if not 'user' in get:return  public.returnMsg(False,'Please select a user')
        if get.user.strip()=='root':return  public.returnMsg(False,'The root user does not need to enable anti-intrusion, the log is recorded by default')
        if self._check_user(get.user.strip()):return  public.returnMsg(False,'The root user does not need to enable anti-intrusion, the log is recorded by default')
        user_etc = public.ReadFile(self.__etc)
        if re.search('\nuserstop_chain = "stop_uid:(.+)"', user_etc):
            user_data = re.search('\nuserstop_chain = "stop_uid:(.+)"', user_etc).group(1).split(',')
            if get.user.strip() in user_data:return  public.returnMsg(False,'This user has turned on anti-intrusion')
            [user_data2.append(x) for x in user_data]
            user_data2.append(get.user.strip())
            user_etc=re.sub('\nuserstop_chain = "stop_uid:%s"'%','.join(user_data),'\nuserstop_chain = "stop_uid:%s"'%','.join(user_data2),user_etc)
            public.writeFile(self.__etc,user_etc)

            return public.returnMsg(True, 'Setup successfully')
        else:
            if not re.search('\noutput = file:/usr/local/usranalyse/logs',user_etc):return  public.returnMsg(False,'Configuration file error, please reinstall this plugin')
            if re.search('\nuserstop_chain = "stop_uid:"', user_etc):
                user_etc = re.sub('\nuserstop_chain = "stop_uid:"',
                                  '\nuserstop_chain = "stop_uid:%s"' %get.user.strip(), user_etc)
                public.writeFile(self.__etc, user_etc)
                return public.returnMsg(True, 'Setup successfully')
            else:
                user_etc = re.sub('\noutput = file:/usr/local/usranalyse/logs',
                                  '\noutput = file:/usr/local/usranalyse/logs\nuserstop_chain = "stop_uid:www,redis,mysql%s"\n'%get.user.strip(),
                                  user_etc)
                public.writeFile(self.__etc, user_etc)
                self.__write_log('Turn on anti-intrusion successfully')
                return public.returnMsg(True, 'Setup successfully')

    '''关闭防提权'''
    def stop_user_security(self,get):
        '''
        用户名-->user
        '''
        user_data2 = []
        if not 'user' in get: return public.returnMsg(False, 'Please select a user')
        if get.user.strip() == 'root': return public.returnMsg(False, 'The root user does not need to enable anti-intrusion, the log is recorded by default')
        if self._check_user(get.user.strip()): return public.returnMsg(False, 'The root user does not need to enable anti-intrusion, the log is recorded by default')
        user_etc = public.ReadFile(self.__etc)
        if re.search('\nuserstop_chain = "stop_uid:(.+)"', user_etc):
            user_data = re.search('\nuserstop_chain = "stop_uid:(.+)"', user_etc).group(1).split(',')
            if not get.user.strip() in user_data:return  public.returnMsg(False,'Anti-intrusion is not enabled for the current user')
            for i in user_data:
                if i==get.user.strip():continue
                user_data2.append(i)
            user_etc=re.sub('\nuserstop_chain = "stop_uid:%s"'%','.join(user_data),'\nuserstop_chain = "stop_uid:%s"'%','.join(user_data2),user_etc)
            public.writeFile(self.__etc,user_etc)
            return public.returnMsg(True, 'Setup successfully')
        else:
            if not re.search('\noutput = file:/usr/local/usranalyse/logs',user_etc):return  public.returnMsg(False,'Configuration file error, please reinstall this plugin')
            if re.search('\nuserstop_chain = "stop_uid:"', user_etc):
                return public.returnMsg(True, 'Setup successfully')
            else:
                user_etc = re.sub('\noutput = file:/usr/local/usranalyse/logs',
                                  '\noutput = file:/usr/local/usranalyse/logs\nuserstop_chain = "stop_uid:www,redis,mysql%s"\n'%get.user.strip(),
                                  user_etc)
                public.writeFile(self.__etc, user_etc)
                self.__write_log('Turn off anti-intrusion successfully')
                return public.returnMsg(True, 'Setup successfully')

    '''过滤进程记录'''
    def porcess_set_up_log(self,get):
        user_etc = public.ReadFile(self.__etc)
        user_data = self.get_exid_expr(user_etc)
        return user_data['ex_pr']

    '''添加进程'''
    def add_porcess_log(self,get):
        if not 'cmd' in get: return public.returnMsg(False, 'Please enter the process name you want to add')
        cmd = get.cmd.strip()
        user_data2 = []
        user_etc = public.ReadFile(self.__etc)
        user_data=self.get_exid_expr(user_etc)
        if cmd in user_data['ex_pr']:return public.returnMsg(False,'Already exists, please do not submit again')
        [user_data2.append(x) for x in user_data['ex_pr']]
        user_data2.append(cmd)
        user_data['user_etc'] = re.sub('\nfilter_chain = "exclude_spawns_of:%s;exclude_uid:%s"' %(','.join(user_data['ex_pr']),','.join(user_data['ex_id'])),
                          '\nfilter_chain = "exclude_spawns_of:%s;exclude_uid:%s"' %(','.join(user_data2),','.join(user_data['ex_id'])), user_data['user_etc'])
        public.writeFile(self.__etc, user_data['user_etc'])
        self.__write_log('Add process %s successfully' % cmd)
        return public.returnMsg(True, 'Setup successfully')


    '''删除进程'''
    def del_porcess_log(self,get):
        if not 'cmd' in get: return public.returnMsg(False, 'Please enter the process name you want to add')
        cmd=get.cmd.strip()
        user_data2 = []
        user_etc = public.ReadFile(self.__etc)
        user_data=self.get_exid_expr(user_etc)
        if not  cmd in user_data['ex_pr']:return public.returnMsg(False,'Process does not exist')
        for i in user_data['ex_pr']:
            if i == cmd: continue
            user_data2.append(i)
        user_data['user_etc'] = re.sub('\nfilter_chain = "exclude_spawns_of:%s;exclude_uid:%s"' %(','.join(user_data['ex_pr']),','.join(user_data['ex_id'])),
                          '\nfilter_chain = "exclude_spawns_of:%s;exclude_uid:%s"' %(','.join(user_data2),','.join(user_data['ex_id'])), user_data['user_etc'])
        public.writeFile(self.__etc, user_data['user_etc'])
        self.__write_log('Deleting process %s succeeded'%cmd)
        return public.returnMsg(True, 'Successfully deleted')

    '''报警开关'''
    def get_send_status(self,get):
        if not os.path.exists(self.__to_msg):
            public.writeFile(self.__to_msg, json.dumps({"open":False,'to_mail':False}))
            return {"open":False,'to_mail':False}
        try:
            msg_conf=json.loads(public.ReadFile(self.__to_msg))
            return public.returnMsg(True,msg_conf)
        except:
            public.writeFile(self.__to_msg,json.dumps({"open":False,'to_mail':False}))
            return {"open":False,'to_mail':False}

    '''报警设置'''
    def set_mail_to(self,get):
        public.writeFile(self.__to_msg, json.dumps({"open": True, 'to_mail': 'mail'}))
        self.__write_log('Email alert enabled successfully')
        return public.returnMsg(True, 'Setup successfully')

    '''TG'''
    def set_dingding(self,get):
        public.writeFile(self.__to_msg, json.dumps({"open": True, 'to_mail': 'telegram'}))
        self.__write_log('Telegram alert enabled successfully')
        return public.returnMsg(True, 'Setup successfully')

    def check_status(self,get):
        '验证是否拦截'
        www_path='/usr/local/usranalyse/logs/total/www/total.txt'
        if not os.path.exists(www_path):
            www_coun=0
        else:
            ret2 = public.ReadFile('/usr/local/usranalyse/logs/total/www/total.txt')
            if not re.search('total=(\d+)', ret2):www_coun = 0
            data = re.findall('total=(\d+)', ret2)
            if not data:
                www_coun = 0
            try:
                www_coun = int(data[0])
            except:
                www_coun = 0
        public.ExecShell('cd /tmp && whoami',user='www')
        if os.path.exists('/usr/local/usranalyse/logs/total/www/total.txt'):
            www_coun2=0
        ret = public.ReadFile('/usr/local/usranalyse/logs/total/www/total.txt')
        if not ret:return public.returnMsg(False,'The test failed, it may be that the main protection switch has been closed or the www user switch has been closed')
        if not re.search('total=(\d+)', ret): www_coun = 0
        data = re.findall('total=(\d+)', ret)
        if not data: www_coun2 = 0
        try:
            www_coun2 = int(data[0])
        except:
            www_coun2 = 0
        if www_coun2==www_coun:
            self.__write_log('The test failed, it may be that the main protection switch has been closed or the www user switch has been closed')
            return public.returnMsg(False,'The test failed, it may be that the main protection switch has been closed or the www user switch has been closed')
        self.__write_log('The protection is successful, the www user (nologin) executes the command, and the record is added')
        return public.returnMsg(True,'The protection is successful, the www user (nologin) executes the command, and the record is added')

    def __write_log(self, msg):
        public.WriteLog('Anti-intrusion', msg)

    #报警日志
    def get_log_send(self,get):
        import page
        page = page.Page()
        count = public.M('logs').where('type=?', (u'Anti-intrusion alarm',)).count()
        limit = 12
        info = {}
        info['count'] = count
        info['row'] = limit
        info['p'] = 1
        if hasattr(get, 'p'):
            info['p'] = int(get['p'])
        info['uri'] = get
        info['return_js'] = ''
        if hasattr(get, 'tojs'):
            info['return_js'] = get.tojs
        data = {}
        # 获取分页数据
        data['page'] = page.GetPage(info, '1,2,3,4,5,8')
        data['data'] = public.M('logs').where('type=?', (u'Anti-intrusion alarm',)).order('id desc').limit(
            str(page.SHIFT) + ',' + str(page.ROW)).field('log,addtime').select();
        return data

    #报警日志
    def get_log(self,get):
        import page
        page = page.Page()
        count = public.M('logs').where('type=?', (u'Anti-intrusion',)).count()
        limit = 12
        info = {}
        info['count'] = count
        info['row'] = limit
        info['p'] = 1
        if hasattr(get, 'p'):
            info['p'] = int(get['p'])
        info['uri'] = get
        info['return_js'] = ''
        if hasattr(get, 'tojs'):
            info['return_js'] = get.tojs
        data = {}
        # 获取分页数据
        data['page'] = page.GetPage(info, '1,2,3,4,5,8')
        data['data'] = public.M('logs').where('type=?', (u'Anti-intrusion',)).order('id desc').limit(
            str(page.SHIFT) + ',' + str(page.ROW)).field('log,addtime').select()
        return data