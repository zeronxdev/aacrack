#!/bin/bash
PATH=/www/server/panel/pyenv/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
install_tmp='/tmp/bt_install.pl'
pluginPath=/www/server/panel/plugin/gdrive
#public_file=/www/server/panel/install/public.sh
#if [ ! -f $public_file ];then
#	wget -O $public_file https://node.aapanel.com/install/public.sh -T 5;
#fi
#. $public_file
#
#download_Url=$NODE_URL
install_tmp='/tmp/bt_install.pl'

Install_GDrive() {

  tmp_ping=$(ping -c 1 -w 1 google.com 2>&1)
  echo $?
  if [ $? -eq 0 ]; then
    tmp=$(python -V 2>&1 | awk '{print $2}')
    pVersion=${tmp:0:3}
    if [ -f "/usr/bin/btpip" ]; then
      tmp=$(btpip list | grep google-api-python-client | awk '{print $2}')
      if [[ $tmp != '1.6.0' ]]; then
        btpip install google-api-python-client==1.6.0
      fi
      tmp=$(btpip list | grep google-auth-httplib2 | awk '{print $2}')
      if [[ $tmp != '0.1.0' ]]; then
        btpip install google-auth-httplib2==0.1.0
      fi
      tmp=$(btpip list | grep google-auth-oauthlib | awk '{print $2}')
      if [[ $tmp != '0.5.0' ]]; then
        btpip install google-auth-oauthlib==0.5.0
      fi
      tmp=$(btpip list | grep -E '^httplib2' | awk '{print $2}')
      if [[ $tmp != '0.15.0' ]]; then
        btpip install httplib2==0.15.0
      fi

      # btpip uninstall requests -y && btpip install -I requests==2.27

    else
      pip install pyOpenSSL
      pip install google-api-python-client==1.6 google-auth-httplib2==0.1.0 google-auth-oauthlib==0.5.0 -i https://pypi.Python.org/simple
      pip install httplib2==0.15.0 -i https://pypi.Python.org/simple
      # btpip uninstall requests -y && btpip install -I requests==2.27
    fi

    echo 'Installing the script file...' >$install_tmp

#    \cp -rp /www/server/panel/plugin/gdrive/credentials.json /root/credentials.json
#    \cp -rp /www/server/panel/plugin/gdrive/icon.png /www/server/panel/BTPanel/static/img/soft_ico/ico-gdrive.png
#    ln -sf /www/server/panel/plugin/gdrive/credentials.json /root/credentials.json




#	#线上用
#  wget --no-check-certificate -O /tmp/gdrive.zip $download_Url/install/plugin/gdrive_en/gdrive.zip -T 5

	#测试用
#	cp -arpf gdrive.zip /tmp/gdrive.zip

#  unzip -o /tmp/gdrive.zip -d /www/server/panel/plugin/
#  rm -f /tmp/gdrive.zip


  ln -sf /www/server/panel/plugin/gdrive/credentials.json /root/credentials.json

  echo 'Installation complete' >$install_tmp
  else
    echo 'Unable to connect to Google server! installation failed!' >$install_tmp
    exit 1
  fi

}

Uninstall_GDrive() {
  rm -rf /www/server/panel/plugin/gdrive
  rm -f /www/server/panel/script/backup_gdrive.py
  echo 'Uninstall completed' >$install_tmp
}

action=$1
if [ "${1}" == 'install' ]; then
  Install_GDrive
  echo '1' >/www/server/panel/data/reload.pl
else
  Uninstall_GDrive
fi
