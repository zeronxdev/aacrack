#!/bin/bash
PATH=/www/server/panel/pyenv/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#public_file=/www/server/panel/install/public.sh
#. $public_file
#download_Url=$NODE_URL
#
pluginPath=/www/server/panel/plugin/file_hash_check
rm -f $pluginPath/*cpython-36m*.so
rm -f $pluginPath/*cpython-37m*.so
rm -f $pluginPath/*_main.so
python_bin='python'
if [ -f /www/server/panel/pyenv/bin/python ];then
    python_bin='/www/server/panel/pyenv/bin/python'
fi

Install_file_hash_check()
{
	mkdir -p $pluginPath

#	wget -O $pluginPath/file_hash_check.zip $download_Url/install/plugin/file_hash_check_en/file_hash_check.zip -T 5
#	cd $pluginPath
#	unzip -o file_hash_check.zip -d /www/server/panel/plugin/
#
#	rm -f file_hash_check.zip


	initSh=/etc/init.d/bt_hashcheck
	\cp -f $pluginPath/init.sh $initSh
	chmod +x $initSh
	if [ -f "/usr/bin/apt-get" ];then
		sudo update-rc.d bt_hashcheck defaults
	else
		chkconfig --add bt_hashcheck
		chkconfig --level 2345 bt_hashcheck on
	fi
	if [ ! -f $pluginPath/check_list.json ];then
		echo '[]' > $pluginPath/check_list.json
	fi
	$initSh stop
	$initSh start

	echo 'Successify'
}

Uninstall_file_hash_check()
{
	initSh=/etc/init.d/bt_hashcheck
	$initSh stop
	chkconfig --del bt_hashcheck
	rm -rf $pluginPath
	rm -f $initSh
}


action=$1
if [ "${1}" == 'install' ];then
	Install_file_hash_check
elif ["${1}" == 'uninstall' ];then
	Uninstall_file_hash_check
else
    echo "Usage: {install|uninstall}"
fi
